---
name: monolitika-design
description: Use this skill to generate well-branded interfaces and assets for «Монолитика» (TDM) — B2B-аналитика продаж и ЛК менеджера, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the readme.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key rules: русскоязычный UI; Inter с tabular-nums для чисел; стеклянный флэт — фирменный синий градиент фона --bg-app + морозные стеклянные карточки (--surface-card + --glass-blur + --glass-border), primary-кнопки — градиент --grad-brand; компактные таблицы 34px; семантические цвета только для статусов; тёмная тема через <html data-theme="dark"> (tokens/theme-dark.css); анимации панелей — var(--anim-duration) 280ms + var(--anim-ease).
