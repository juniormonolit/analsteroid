import React from 'react';
import {FormatNum} from '../core/Num.jsx';
const fmt=(v)=>FormatNum(v);
export function LineChart({values=[],labels=[],height=220,area=true,smooth=true,showDots=false,color='var(--interactive)',valueFormat=fmt,style}){
const W=600,H=height,padL=44,padB=labels.length?22:8,padT=10,padR=8;
const max=Math.max(...values,1),min=0;
const iw=W-padL-padR,ih=H-padT-padB;
const pt=(v,i)=>[padL+(values.length<2?iw/2:i*(iw/(values.length-1))),padT+ih-((v-min)/(max-min))*ih];
const pts=values.map(pt);
let d='';
if(smooth&&pts.length>2){
d=`M ${pts[0][0]} ${pts[0][1]}`;
for(let i=1;i<pts.length;i++){const [x0,y0]=pts[i-1],[x1,y1]=pts[i];const cx=(x0+x1)/2;d+=` C ${cx} ${y0}, ${cx} ${y1}, ${x1} ${y1}`;}
}else d='M '+pts.map(p=>p.join(' ')).join(' L ');
const ticks=[0,.25,.5,.75,1];
return <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',height:'auto',display:'block',fontFamily:'var(--font-ui)',...style}}>
{ticks.map((t,i)=>{const y=padT+ih-t*ih;return <g key={i}>
<line x1={padL} x2={W-padR} y1={y} y2={y} stroke="var(--gray-200)" strokeDasharray="3 4" strokeWidth="1"/>
<text x={padL-8} y={y+3.5} textAnchor="end" fontSize="10" fill="var(--gray-400)" style={{fontVariantNumeric:'tabular-nums'}}>{valueFormat(min+t*(max-min))}</text>
</g>;})}
{area&&<path d={d+` L ${pts[pts.length-1][0]} ${padT+ih} L ${pts[0][0]} ${padT+ih} Z`} fill={color} opacity=".1"/>}
<path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round"/>
{showDots&&pts.map((p,i)=><circle key={i} cx={p[0]} cy={p[1]} r="3" fill="#fff" stroke={color} strokeWidth="2"/>)}
{labels.map((l,i)=>{const x=pt(0,i)[0];return <text key={i} x={x} y={H-6} textAnchor="middle" fontSize="10" fill="var(--gray-400)">{l}</text>;})}
</svg>;
}
