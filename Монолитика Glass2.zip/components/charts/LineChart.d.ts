/** Линейный график: тонкая синяя линия 2px, заливка 10 % прозрачности, пунктирная сетка. Минимум декора. */
export interface LineChartProps {
  values: number[];
  labels?: string[];
  height?: number;
  /** Заливка под линией */
  area?: boolean;
  smooth?: boolean;
  showDots?: boolean;
  color?: string;
  valueFormat?: (v: number) => string;
  style?: React.CSSProperties;
}
