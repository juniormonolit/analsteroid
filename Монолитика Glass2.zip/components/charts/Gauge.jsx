import React from 'react';
export function Gauge({percent=0,label,size=220,segments=24,style}){
const W=size,H=size*0.62,cx=W/2,cy=H*0.94,R=W/2-10,inner=R*0.62;
const n=segments,fill=Math.round((percent/100)*n);
const bars=Array.from({length:n},(_,i)=>{
const a=Math.PI-(i+0.5)*(Math.PI/n);
const x1=cx+Math.cos(a)*inner,y1=cy-Math.sin(a)*inner;
const x2=cx+Math.cos(a)*R,y2=cy-Math.sin(a)*R;
const on=i<fill;
const t=n<=1?0:i/(n-1);
const col=on?(t<0.5?'var(--blue-600)':'var(--blue-500)'):'var(--blue-100)';
return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={col} strokeWidth={Math.max(5,size*0.038)} strokeLinecap="round"/>;
});
return <div style={{display:'flex',flexDirection:'column',alignItems:'center',width:W,fontFamily:'var(--font-ui)',...style}}>
<svg width={W} height={H} style={{display:'block'}}>{bars}</svg>
<div style={{textAlign:'center',marginTop:6}}>
<div style={{fontSize:size*0.13,fontWeight:600,fontVariantNumeric:'tabular-nums',lineHeight:1}}>{percent.toLocaleString('ru-RU')}%</div>
{label&&<div style={{fontSize:'var(--text-xs)',color:'var(--text-secondary)',marginTop:'3px'}}>{label}</div>}
</div>
</div>;
}
