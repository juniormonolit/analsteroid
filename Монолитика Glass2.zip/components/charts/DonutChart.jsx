import React from 'react';
const DEF=['var(--chart-1)','var(--chart-2)','var(--chart-3)','var(--chart-4)','var(--chart-5)','var(--chart-6)'];
export function DonutChart({segments=[],size=180,thickness=22,centerValue,centerLabel,showLegend=true,style}){
const total=segments.reduce((a,s)=>a+s.value,0)||1;
const r=(size-thickness)/2,c=size/2,circ=2*Math.PI*r;
let acc=0;
return <div style={{display:'flex',alignItems:'center',gap:'20px',fontFamily:'var(--font-ui)',...style}}>
<div style={{position:'relative',width:size,height:size,flex:'none'}}>
<svg width={size} height={size} style={{transform:'rotate(-90deg)'}}>
{segments.map((s,i)=>{
const frac=s.value/total,off=acc;acc+=frac;
return <circle key={i} cx={c} cy={c} r={r} fill="none" stroke={s.color||DEF[i%DEF.length]} strokeWidth={thickness}
strokeDasharray={`${Math.max(frac*circ-2,0.01)} ${circ}`} strokeDashoffset={-off*circ} strokeLinecap="butt"/>;
})}
</svg>
{(centerValue||centerLabel)&&<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center'}}>
<span style={{fontSize:size*0.16,fontWeight:600,fontVariantNumeric:'tabular-nums',lineHeight:1.1}}>{centerValue}</span>
{centerLabel&&<span style={{fontSize:'var(--text-xs)',color:'var(--text-secondary)'}}>{centerLabel}</span>}
</div>}
</div>
{showLegend&&<div style={{display:'flex',flexDirection:'column',gap:'8px'}}>
{segments.map((s,i)=><div key={i} style={{display:'flex',alignItems:'center',gap:'8px',fontSize:'var(--text-sm)'}}>
<span style={{width:'8px',height:'8px',borderRadius:'50%',background:s.color||DEF[i%DEF.length],flex:'none'}}></span>
<span style={{color:'var(--text-secondary)'}}>{s.label}</span>
<span style={{fontWeight:600,fontVariantNumeric:'tabular-nums',marginLeft:'auto',paddingLeft:'12px'}}>{Math.round(s.value/total*100)}%</span>
</div>)}
</div>}
</div>;
}
