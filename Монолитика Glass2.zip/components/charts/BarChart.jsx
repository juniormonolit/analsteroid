import React from 'react';
export function BarChart({values=[],labels=[],height=220,activeIndex,color='var(--interactive)',mutedColor='var(--gray-100)',valueFormat,onBarClick,style}){
const W=600,H=height,padL=valueFormat?44:8,padB=labels.length?22:8,padT=10,padR=8;
const max=Math.max(...values,1);
const iw=W-padL-padR,ih=H-padT-padB;
const bw=Math.min(48,iw/values.length*0.62);
const ticks=[0,.5,1];
return <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',height:'auto',display:'block',fontFamily:'var(--font-ui)',...style}}>
{valueFormat&&ticks.map((t,i)=>{const y=padT+ih-t*ih;return <g key={i}>
<line x1={padL} x2={W-padR} y1={y} y2={y} stroke="var(--gray-200)" strokeDasharray="3 4" strokeWidth="1"/>
<text x={padL-8} y={y+3.5} textAnchor="end" fontSize="10" fill="var(--gray-400)" style={{fontVariantNumeric:'tabular-nums'}}>{valueFormat(t*max)}</text>
</g>;})}
{values.map((v,i)=>{
const x=padL+i*(iw/values.length)+(iw/values.length-bw)/2;
const bh=(v/max)*ih;
const act=activeIndex==null||activeIndex===i;
return <g key={i} onClick={onBarClick?()=>onBarClick(i):undefined} style={{cursor:onBarClick?'pointer':'default'}}>
<rect x={x} y={padT+ih-bh} width={bw} height={bh} rx="6" fill={act?color:mutedColor}/>
{labels[i]!=null&&<text x={x+bw/2} y={H-6} textAnchor="middle" fontSize="10" fill={activeIndex===i?'var(--gray-700)':'var(--gray-400)'} fontWeight={activeIndex===i?600:400}>{labels[i]}</text>}
</g>;})}
</svg>;
}
