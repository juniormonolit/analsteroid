/** Полукруглый gauge из радиальных штрихов (стиль Boltshift): заполненные — синие, остальные — blue-100. */
export interface GaugeProps {
  /** 0–100 */
  percent: number;
  /** Подпись под процентом: «выполнение плана» */
  label?: string;
  size?: number;
  segments?: number;
  style?: React.CSSProperties;
}
