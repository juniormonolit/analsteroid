/** Столбчатый график; с activeIndex активный столбец синий, остальные серые (стиль Boltshift). */
export interface BarChartProps {
  values: number[];
  labels?: string[];
  height?: number;
  /** Подсветить один столбец, остальные — приглушить */
  activeIndex?: number;
  color?: string;
  mutedColor?: string;
  /** Включает ось Y с подписями */
  valueFormat?: (v: number) => string;
  onBarClick?: (index: number) => void;
  style?: React.CSSProperties;
}
