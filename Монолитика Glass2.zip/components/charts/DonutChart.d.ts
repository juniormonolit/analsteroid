/** Donut: сегменты оттенками синего (blue-700→blue-100), крупное значение в центре, легенда справа. */
export interface DonutChartProps {
  segments: Array<{ value: number; label: string; color?: string }>;
  size?: number;
  thickness?: number;
  centerValue?: string;
  centerLabel?: string;
  showLegend?: boolean;
  style?: React.CSSProperties;
}
