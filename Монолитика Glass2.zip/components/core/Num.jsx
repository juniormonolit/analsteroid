import React from 'react';
const trim=(x,d)=>x.toLocaleString('ru-RU',{maximumFractionDigits:d});
export function FormatNum(v,{unit='',compact=true,digits=1}={}){
if(v==null||isNaN(v))return '—';
const neg=v<0,a=Math.abs(v);
let s;
if(compact&&a>=1e9)s=trim(a/1e9,digits)+' млрд';
else if(compact&&a>=1e6)s=trim(a/1e6,digits)+' млн';
else if(compact&&a>=1e4)s=trim(a/1e3,digits)+' тыс';
else s=trim(a,a<10?digits:0);
return (neg?'−':'')+s+(unit?' '+unit:'');
}
export function Num({value,unit='',money=false,compact=true,digits=1,style}){
return <span className="tnum" style={{fontVariantNumeric:'tabular-nums',...style}}>{FormatNum(value,{unit:money?'₽':unit,compact,digits})}</span>;
}
