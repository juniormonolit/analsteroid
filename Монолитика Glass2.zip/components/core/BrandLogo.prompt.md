Логотип приложения — скопирован 1:1 из components/ui/BrandLogo.tsx кодовой базы. Не перерисовывать, пропорции 6:3:17:10 не менять.

```jsx
<BrandLogo size={20}/>
<BrandLogo size={22} withWordmark/>  // шапка сайдбара
```
