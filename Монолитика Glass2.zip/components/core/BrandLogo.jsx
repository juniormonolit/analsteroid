import React from 'react';
// Знак «Монолитика» — «М-барчарт» из кодовой базы (components/ui/BrandLogo.tsx, 1:1):
// три pill-столбика в цветах стадий сделок: продажи (синий) / отказы (красный) / отгрузки (зелёный).
export function BrandLogo({size=20,withWordmark=false,style}){
const h=size,w=(size*24)/17;
const svg=<svg width={w} height={h} viewBox="0 0 24 17" fill="none" aria-hidden="true" style={withWordmark?undefined:style}>
<rect x="0" y="0" width="6" height="17" rx="3" fill="var(--entity-sales,#3b82f6)"/>
<rect x="9" y="7" width="6" height="10" rx="3" fill="var(--entity-refusals,#ef4444)"/>
<rect x="18" y="0" width="6" height="17" rx="3" fill="var(--entity-shipments,#22c55e)"/>
</svg>;
if(!withWordmark)return svg;
return <span style={{display:'inline-flex',alignItems:'center',gap:Math.round(size*0.45),...style}}>
{svg}<span style={{fontFamily:'var(--font-ui)',fontSize:size*0.9,fontWeight:700,color:'var(--text-primary)',letterSpacing:'-0.02em',lineHeight:1}}>Монолитика</span>
</span>;
}
