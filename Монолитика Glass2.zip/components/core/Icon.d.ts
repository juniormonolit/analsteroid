/** Иконка из кураторского поднабора Lucide (линия 2px). */
export interface IconProps {
  /** Имя: home, dashboard, chart, users, settings, bell, search, chevron-down/up/right/left, calendar, x, check, plus, filter, download, wallet, gift, trophy, bag, package, file, alert, info, trend-up, trend-down, more, inbox, arrow-up-right, sparkles, logout */
  name: string;
  /** Размер в px, по умолчанию 16 */
  size?: number;
  /** Цвет обводки, по умолчанию currentColor */
  color?: string;
  strokeWidth?: number;
  style?: React.CSSProperties;
}
