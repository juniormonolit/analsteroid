Линейная иконка (поднабор Lucide, 2px stroke) — единственный источник глифов в системе; эмодзи и unicode-иконки запрещены.

```jsx
<Icon name="chart" size={16} />
<Icon name="bell" size={18} color="var(--text-secondary)" />
```

Наследует цвет текста (currentColor). Размеры: 14–16 в тексте и кнопках, 18–20 в навигации.
