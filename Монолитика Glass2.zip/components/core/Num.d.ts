/** Число с автосокращением до «тыс / млн / млрд» (русские единицы, не K/M/B). Полные значения — только в таблицах и итогах. */
export interface NumProps {
  value: number;
  /** Единица после числа: «₽», «шт» */
  unit?: string;
  /** Короткая запись unit="₽" */
  money?: boolean;
  /** false — полное число с разрядами */
  compact?: boolean;
  /** Знаков после запятой в сокращённой форме, по умолчанию 1 */
  digits?: number;
  style?: React.CSSProperties;
}
