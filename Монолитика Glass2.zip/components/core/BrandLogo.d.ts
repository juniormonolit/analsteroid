/** Знак «Монолитика» («М-барчарт», 1:1 из кодовой базы): три pill-столбика в цветах стадий — продажи/отказы/отгрузки. */
export interface BrandLogoProps {
  /** Высота знака в px, по умолчанию 20 */
  size?: number;
  /** Знак + надпись «Монолитика» */
  withWordmark?: boolean;
  style?: React.CSSProperties;
}
