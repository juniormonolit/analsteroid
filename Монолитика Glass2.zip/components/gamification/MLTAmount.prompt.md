Сумма MLT в балансе, таблицах, наградах квестов.

```jsx
<MLTAmount value={1250}/>
<MLTAmount value={50} delta showUnit={false}/> — «+50» за квест
```
