import React from 'react';
import {MLTAmount} from './MLTAmount.jsx';
const TIERS={
bronze:{label:'Бронза',bg:'var(--tier-bronze)',grad:'linear-gradient(135deg,#C9A76C 0%,#B08D57 60%,#8C6E3F 100%)',glow:'none'},
silver:{label:'Серебро',bg:'var(--tier-silver)',grad:'linear-gradient(135deg,#C3CCD6 0%,#9AA5B1 60%,#78848F 100%)',glow:'none'},
gold:{label:'Золото',bg:'var(--tier-gold)',grad:'var(--grad-gold)',glow:'var(--glow-gold)'},
platinum:{label:'Платина',bg:'var(--tier-platinum)',grad:'var(--grad-platinum)',glow:'var(--glow-rare)'},
};
export function RewardCard({tier='bronze',title,description,price,image,action,style}){
const t=TIERS[tier]||TIERS.bronze;
const [hov,setHov]=React.useState(false);
return <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
style={{width:'220px',background:'var(--surface-card)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',border:'1px solid var(--glass-border)',borderRadius:'var(--radius-xl)',overflow:'hidden',fontFamily:'var(--font-ui)',boxShadow:hov?`var(--shadow-hover)${t.glow!=='none'?', '+t.glow:''}`:t.glow!=='none'?t.glow:'var(--shadow-card)',transition:'box-shadow var(--transition-normal), transform var(--transition-normal)',transform:hov?'translateY(-2px)':'none',...style}}>
<div style={{height:'110px',background:t.grad,display:'flex',alignItems:'center',justifyContent:'center',position:'relative'}}>
{image}
<span style={{position:'absolute',top:'8px',left:'8px',fontSize:'11px',fontWeight:600,color:'#fff',background:'rgba(0,0,0,.22)',padding:'2px 8px',borderRadius:'999px',letterSpacing:'.02em'}}>{t.label}</span>
</div>
<div style={{padding:'12px 14px',display:'flex',flexDirection:'column',gap:'6px'}}>
<span style={{fontSize:'var(--text-base)',fontWeight:600}}>{title}</span>
{description&&<span style={{fontSize:'var(--text-xs)',color:'var(--text-secondary)'}}>{description}</span>}
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:'4px'}}>
{price!=null?<MLTAmount value={price}/>:<span></span>}
{action}
</div>
</div>
</div>;
}
