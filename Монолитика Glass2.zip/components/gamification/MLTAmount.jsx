import React from 'react';
import {MLTCoin} from './MLTCoin.jsx';
export function MLTAmount({value,delta=false,size='md',showUnit=true,style}){
const s={sm:{coin:14,fs:'var(--text-sm)'},md:{coin:16,fs:'var(--text-base)'},lg:{coin:20,fs:'var(--text-md)'}}[size];
return <span style={{display:'inline-flex',alignItems:'center',gap:'6px',fontFamily:'var(--font-ui)',fontSize:s.fs,fontWeight:600,fontVariantNumeric:'tabular-nums',color:'var(--text-primary)',...style}}>
<MLTCoin size={s.coin}/>
{delta&&value>=0?'+':''}{value.toLocaleString('ru-RU')}
{showUnit&&<span style={{color:'var(--text-secondary)',fontWeight:500,fontSize:'0.85em'}}>MLT</span>}
</span>;
}
