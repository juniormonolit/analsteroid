/** Монета MLT: <48px — плоская упрощённая (без «MLT» и ромбов), ≥48px — объёмная для витрины/гачи. */
export interface MLTCoinProps {
  /** Рекомендуемый ряд: 16 / 20 / 24 / 48+ */
  size?: number;
  /** Принудительно объёмная/плоская; по умолчанию — авто по размеру */
  detailed?: boolean;
  style?: React.CSSProperties;
}
