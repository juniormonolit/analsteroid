/** Карточка награды/товара магазина: градиентная шапка тира, glow у золота и платины. Только для разделов геймификации. */
export interface RewardCardProps {
  tier?: 'bronze' | 'silver' | 'gold' | 'platinum';
  title: string;
  description?: string;
  /** Цена в MLT */
  price?: number;
  /** Контент шапки: монета, изображение приза */
  image?: React.ReactNode;
  /** Обычно <Button size="sm">Купить</Button> */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
