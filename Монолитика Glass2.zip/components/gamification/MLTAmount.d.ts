/** Инлайн-сумма в MLT: плоская монета + число tabular-nums + «MLT». */
export interface MLTAmountProps {
  value: number;
  /** Начисление: показывает знак «+» */
  delta?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showUnit?: boolean;
  style?: React.CSSProperties;
}
