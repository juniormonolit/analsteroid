/**
 * Плашка квеста (1:1 из QuestsTab кодовой базы): тир-бейдж, слот, таймер, прогресс, награда «+N MLT · +M XP», реролл.
 * @startingPoint section="Геймификация" subtitle="Карточка квеста с тиром и прогрессом" viewport="700x620"
 */
export interface QuestCardProps {
  /** Тир сложности: white=Обычный, green=Необычный, blue=Редкий, epic=Эпический, legendary=Легендарный */
  tier?: 'white' | 'green' | 'blue' | 'epic' | 'legendary';
  /** «Дневной» / «Недельный» / «Месячный» / «Доп. квест» / «Контракт» */
  slot?: string;
  title: string;
  progress?: number;
  target?: number;
  rewardMlt?: number;
  rewardXp?: number;
  status?: 'active' | 'done' | 'failed';
  /** Текст таймера: «ещё 3 дн.» / «до конца дня» */
  deadline?: string;
  /** Цена реролла — показывает кнопку «Заменить (N)» */
  rerollPrice?: number;
  onReroll?: () => void;
  format?: (v: number) => string;
  style?: React.CSSProperties;
}
