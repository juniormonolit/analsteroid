import React from 'react';
import {MLTCoin} from './MLTCoin.jsx';
// Плашка квеста (паттерн QuestsTab кодовой базы), переработана: таймер и шапка не
// ломаются на узких колонках, награда — чип с монетой, реролл — понятная кнопка
// «Заменить квест за N MLT» (что меняем, сколько стоит, в какой валюте).
const TIERS={
white:{label:'Обычный',color:'var(--quest-white,#9ca3af)'},
green:{label:'Необычный',color:'var(--quest-green,#2f9e44)'},
blue:{label:'Редкий',color:'var(--quest-blue,#1c7ed6)'},
epic:{label:'Эпический',color:'var(--quest-epic,#9c36b5)'},
legendary:{label:'Легендарный',color:'var(--quest-legendary,#e8590c)'},
};
const fmtN=(v)=>v>=10000?v.toLocaleString('ru-RU'):String(Math.round(v*10)/10);
export function QuestCard({tier='blue',slot='Дневной',title,progress=0,target=1,rewardMlt=0,rewardXp=0,status='active',deadline,rerollPrice,onReroll,format=fmtN,style}){
const t=TIERS[tier]||TIERS.blue;
const done=status==='done';
const color=done?'var(--quest-green,#2f9e44)':t.color;
const pct=Math.min(100,Math.round(progress/Math.max(target,1)*100));
return <div style={{display:'flex',flexDirection:'column',gap:10,padding:'14px 16px',borderRadius:'var(--radius-lg)',border:`1.5px solid color-mix(in srgb, ${color} 50%, transparent)`,background:`linear-gradient(color-mix(in srgb, ${color} 7%, transparent),color-mix(in srgb, ${color} 7%, transparent)),var(--surface-card)`,backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',boxShadow:'var(--shadow-card)',fontFamily:'var(--font-ui)',minWidth:0,...style}}>
<div style={{display:'flex',alignItems:'center',gap:8,minWidth:0}}>
<span style={{flex:'none',borderRadius:7,padding:'2px 7px',fontSize:10,fontWeight:700,letterSpacing:'.05em',textTransform:'uppercase',color:'#fff',background:t.color,whiteSpace:'nowrap'}}>{t.label}</span>
<span style={{fontSize:11,fontWeight:600,color:'var(--text-secondary)',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',minWidth:0}}>{slot}</span>
<span style={{marginLeft:'auto',flex:'none',fontSize:11,whiteSpace:'nowrap',color:done?'var(--success-text)':status==='failed'?'var(--text-tertiary)':'var(--text-secondary)',fontVariantNumeric:'tabular-nums',fontWeight:done?600:400}}>{done?'✅ выполнен':status==='failed'?'сгорел':deadline}</span>
</div>
<div style={{fontSize:14,fontWeight:700,color:'var(--text-primary)',lineHeight:1.35,overflowWrap:'break-word'}}>{title}</div>
<div style={{display:'flex',flexDirection:'column',gap:6}}>
<div style={{height:8,borderRadius:999,background:'var(--surface-sunken)',overflow:'hidden'}}>
<div style={{height:'100%',width:Math.max(pct,2)+'%',borderRadius:999,background:color,transition:'width var(--transition-normal)'}}></div>
</div>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:8,flexWrap:'wrap'}}>
<span style={{fontSize:11,fontVariantNumeric:'tabular-nums',color:'var(--text-secondary)',whiteSpace:'nowrap'}}>{format(progress)} из {format(target)}</span>
<span title={`Награда за выполнение: ${rewardMlt} MLT и ${rewardXp} XP`} style={{flex:'none',display:'inline-flex',alignItems:'center',gap:5,background:'var(--surface-selected)',borderRadius:999,padding:'3px 9px',fontSize:11,fontWeight:700,fontVariantNumeric:'tabular-nums',color:'var(--text-brand)',whiteSpace:'nowrap'}}><MLTCoin size={13}/>+{rewardMlt} MLT · +{rewardXp} XP</span>
</div>
</div>
{status==='active'&&rerollPrice!=null&&<button type="button" onClick={onReroll} title="Не подходит квест? Замените его на другой того же тира. Спишется указанная сумма MLT; максимум одна замена."
style={{display:'flex',alignItems:'center',justifyContent:'center',flexWrap:'wrap',gap:'2px 6px',width:'100%',minHeight:30,padding:'4px 8px',appearance:'none',border:'1px solid var(--border-strong)',background:'transparent',borderRadius:9,fontSize:12,fontWeight:600,fontFamily:'inherit',color:'var(--text-primary)',cursor:'pointer'}}>Заменить квест за <span style={{display:'inline-flex',alignItems:'center',gap:4,fontVariantNumeric:'tabular-nums'}}><MLTCoin size={13}/>{rerollPrice} MLT</span></button>}
</div>;
}
