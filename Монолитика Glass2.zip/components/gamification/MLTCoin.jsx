import React from 'react';
export function MLTCoin({size=20,detailed,style}){
const full=detailed??size>=48;
if(!full){
return <svg width={size} height={size} viewBox="0 0 24 24" style={{flex:'none',...style}} aria-label="MLT">
<circle cx="12" cy="12" r="12" fill="#005CA9"/>
<circle cx="12" cy="12" r="10.2" fill="#1B7FD4"/>
{size>=20&&<circle cx="12" cy="12" r="10.2" fill="none" stroke="#7FB9E8" strokeWidth=".8" strokeOpacity=".7"/>}
<text x="12" y="16.6" fontFamily="var(--font-coin,Georgia,serif)" fontSize="13" fontWeight="700" fill="#FFFFFF" textAnchor="middle">M</text>
</svg>;
}
const uid=React.useId().replace(/:/g,'');
return <svg width={size} height={size} viewBox="0 0 96 96" style={{flex:'none',...style}} aria-label="MLT">
<defs>
<linearGradient id={'r'+uid} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7FB9E8"/><stop offset=".5" stopColor="#1B7FD4"/><stop offset="1" stopColor="#004A8A"/></linearGradient>
<radialGradient id={'f'+uid} cx=".5" cy=".35" r=".8"><stop offset="0" stopColor="#4A9CDE"/><stop offset=".6" stopColor="#1B7FD4"/><stop offset="1" stopColor="#005CA9"/></radialGradient>
<linearGradient id={'m'+uid} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFFFFF"/><stop offset="1" stopColor="#D7E9F8"/></linearGradient>
</defs>
<circle cx="48" cy="48" r="47" fill={`url(#r${uid})`}/>
<circle cx="48" cy="48" r="45.2" fill="none" stroke="#D7E9F8" strokeOpacity=".55" strokeWidth="2.6" strokeDasharray="1.2 2.1"/>
<circle cx="48" cy="48" r="41" fill={`url(#f${uid})`}/>
<circle cx="48" cy="48" r="41" fill="none" stroke="#003563" strokeOpacity=".3"/>
<path id={'a'+uid} d="M 48 12.5 a 35.5 35.5 0 1 1 -0.02 0" fill="none"/>
<text fontFamily="var(--font-coin,Georgia,serif)" fontSize="5.4" fontWeight="700" fill="#fff" fillOpacity=".75" letterSpacing="1.6"><textPath href={`#a${uid}`}>MLT · MLT · MLT · MLT · MLT · MLT · MLT · MLT · MLT · MLT · MLT · MLT</textPath></text>
<path d="M 22.5 48 l 3.2 -3.2 3.2 3.2 -3.2 3.2 z" fill="#fff" fillOpacity=".9"/>
<path d="M 67.1 48 l 3.2 -3.2 3.2 3.2 -3.2 3.2 z" fill="#fff" fillOpacity=".9"/>
<text x="48" y="63.5" fontFamily="var(--font-coin,Georgia,serif)" fontSize="40" fontWeight="700" fill={`url(#m${uid})`} textAnchor="middle">M</text>
</svg>;
}
