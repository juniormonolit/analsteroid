import React from 'react';
export function Input({label,hint,error,icon,size='md',type='text',value,defaultValue,onChange,placeholder,disabled,style,...rest}){
const h={sm:'var(--control-h-sm)',md:'var(--control-h)',lg:'var(--control-h-lg)'}[size];
const [focus,setFocus]=React.useState(false);
return <label style={{display:'flex',flexDirection:'column',gap:'6px',fontFamily:'var(--font-ui)',fontSize:'var(--text-sm)',color:'var(--text-primary)',...style}}>
{label&&<span style={{fontWeight:500}}>{label}</span>}
<span style={{display:'flex',alignItems:'center',gap:'8px',height:h,padding:'0 12px',background:disabled?'var(--surface-sunken)':'var(--surface-card)',border:`1px solid ${error?'var(--danger)':focus?'var(--border-focus)':'var(--border-strong)'}`,borderRadius:'var(--radius-md)',boxShadow:focus?'var(--focus-ring)':'none',transition:'border-color var(--transition-fast), box-shadow var(--transition-fast)'}}>
{icon&&<span style={{color:'var(--text-tertiary)',display:'flex'}}>{icon}</span>}
<input type={type} value={value} defaultValue={defaultValue} onChange={onChange} placeholder={placeholder} disabled={disabled}
onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
style={{flex:1,border:'none',outline:'none',background:'transparent',font:'inherit',fontSize:'var(--text-base)',color:'inherit',minWidth:0}} {...rest}/>
</span>
{error?<span style={{color:'var(--danger-text)',fontSize:'var(--text-xs)'}}>{error}</span>:hint?<span style={{color:'var(--text-tertiary)',fontSize:'var(--text-xs)'}}>{hint}</span>:null}
</label>;
}
