Текстовое поле форм и тулбаров; фокус — синий бордер + мягкое кольцо blue-100.

```jsx
<Input label="Название клиента" placeholder="ООО «Стройторг»"/>
<Input icon={<Icon name="search" size={16}/>} placeholder="Поиск по товарам…" size="sm"/>
<Input label="Email" error="Неверный формат"/>
```
