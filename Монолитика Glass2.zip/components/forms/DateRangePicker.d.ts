/** Дейтпикер-диапазон с пресетами («Этот месяц», «Квартал»…) и одномесячным календарём. */
export interface DateRangePickerProps {
  label?: string;
  start?: Date;
  end?: Date;
  onChange?: (start: Date, end: Date) => void;
  size?: 'sm' | 'md' | 'lg';
  style?: React.CSSProperties;
}
