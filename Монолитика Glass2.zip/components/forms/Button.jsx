import React from 'react';
export function Button({variant='primary',size='md',icon,iconRight,children,disabled,fullWidth,style,onClick,...rest}){
const h={sm:'var(--control-h-sm)',md:'var(--control-h)',lg:'var(--control-h-lg)'}[size];
const fs={sm:'var(--text-sm)',md:'var(--text-base)',lg:'var(--text-md)'}[size];
const px={sm:'10px',md:'14px',lg:'18px'}[size];
const [hover,setHover]=React.useState(false);
const [press,setPress]=React.useState(false);
const v={
primary:{background:'var(--grad-brand)',filter:press?'brightness(.88)':hover?'brightness(1.1)':'none',color:'#fff',border:'1px solid rgba(255,255,255,.28)',boxShadow:'0 4px 14px rgba(0,92,169,.35)'},
secondary:{background:hover?'var(--gray-50)':'var(--surface-card)',color:'var(--text-primary)',border:'1px solid var(--border-strong)'},
ghost:{background:hover?'var(--gray-100)':'transparent',color:'var(--text-primary)',border:'1px solid transparent'},
danger:{background:'var(--danger-fill,#D93025)',filter:press?'brightness(.85)':hover?'brightness(1.1)':'none',color:'#fff',border:'1px solid transparent'},
}[variant];
return <button type="button" disabled={disabled} onClick={onClick}
onMouseEnter={()=>setHover(true)} onMouseLeave={()=>{setHover(false);setPress(false);}} onMouseDown={()=>setPress(true)} onMouseUp={()=>setPress(false)}
style={{display:'inline-flex',alignItems:'center',justifyContent:'center',gap:'8px',height:h,padding:`0 ${px}`,borderRadius:'var(--radius-md)',fontFamily:'var(--font-ui)',fontSize:fs,fontWeight:500,cursor:disabled?'not-allowed':'pointer',opacity:disabled?.5:1,transition:'background var(--transition-fast), filter var(--transition-fast)',width:fullWidth?'100%':undefined,...v,...style}} {...rest}>
{icon}{children}{iconRight}
</button>;
}
