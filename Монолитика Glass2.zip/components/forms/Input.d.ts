/** Текстовое поле с лейблом, подсказкой, ошибкой и иконкой-префиксом. */
export interface InputProps {
  label?: string;
  hint?: string;
  /** Текст ошибки; красит бордер в danger */
  error?: string;
  /** Иконка-префикс, обычно <Icon name="search"/> */
  icon?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg';
  type?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (e: any) => void;
  placeholder?: string;
  disabled?: boolean;
  style?: React.CSSProperties;
}
