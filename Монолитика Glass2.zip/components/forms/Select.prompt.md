Селект для фильтров отчётов и форм; активный пункт подсвечен blue-50 с галочкой.

```jsx
<Select label="Филиал" options={['Все филиалы','Москва','Казань']} value={v} onChange={setV}/>
<Select size="sm" options={[{value:'m',label:'Этот месяц'},{value:'q',label:'Квартал'}]} value="m"/>
```
