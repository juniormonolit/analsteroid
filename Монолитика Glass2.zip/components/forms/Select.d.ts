/** Выпадающий список; активный пункт — заливка blue-50 + синий текст. */
export interface SelectProps {
  label?: string;
  /** Строки или {value,label} */
  options: Array<string | { value: string; label: string }>;
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  style?: React.CSSProperties;
}
