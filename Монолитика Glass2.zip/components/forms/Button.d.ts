/**
 * Кнопка: primary — синяя заливка, secondary — белая с бордером, ghost — прозрачная.
 * @startingPoint section="Формы" subtitle="Кнопки: primary / secondary / ghost, три размера" viewport="700x340"
 */
export interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** sm=28px, md=36px, lg=44px */
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
  disabled?: boolean;
  fullWidth?: boolean;
  onClick?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
