Кнопка действия; primary — одна на экран (главное действие), secondary — рядом с ней, ghost — в тулбарах и таблицах.

```jsx
<Button icon={<Icon name="download" size={16}/>}>Экспорт</Button>
<Button variant="secondary">Отмена</Button>
<Button variant="ghost" size="sm">Фильтр</Button>
```

danger — только для разрушающих действий в модалках подтверждения.
