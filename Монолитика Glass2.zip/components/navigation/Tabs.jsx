import React from 'react';
export function Tabs({items=[],value,onChange,size='md',style}){
return <div style={{display:'flex',gap:'2px',borderBottom:'1px solid var(--border-default)',fontFamily:'var(--font-ui)',...style}}>
{items.map((it,i)=>{const v=it.value??it,l=it.label??it,act=v===value;
return <button key={i} type="button" onClick={()=>onChange&&onChange(v)}
style={{appearance:'none',background:'transparent',border:'none',borderBottom:`2px solid ${act?'var(--interactive)':'transparent'}`,marginBottom:'-1px',padding:size==='sm'?'8px 10px':'10px 14px',fontSize:size==='sm'?'var(--text-sm)':'var(--text-base)',fontFamily:'inherit',fontWeight:act?600:400,color:act?'var(--text-brand)':'var(--text-secondary)',cursor:'pointer',display:'flex',alignItems:'center',gap:'6px',transition:'color var(--transition-fast)'}}
onMouseEnter={e=>{if(!act)e.currentTarget.style.color='var(--text-primary)';}}
onMouseLeave={e=>{if(!act)e.currentTarget.style.color='var(--text-secondary)';}}>
{l}{it.count!=null&&<span style={{fontSize:'11px',fontWeight:600,fontVariantNumeric:'tabular-nums',background:act?'var(--blue-50)':'var(--gray-100)',color:act?'var(--blue-700)':'var(--text-secondary)',borderRadius:'999px',padding:'1px 7px'}}>{it.count}</span>}
</button>;})}
</div>;
}
