import React from 'react';
import {Icon} from '../core/Icon.jsx';
export function Pagination({page=1,pageCount=1,onChange,total,pageSize,style}){
const btn=(act,dis)=>({minWidth:'28px',height:'28px',padding:'0 6px',display:'inline-flex',alignItems:'center',justifyContent:'center',borderRadius:'var(--radius-sm)',border:'1px solid '+(act?'var(--interactive)':'transparent'),background:act?'var(--surface-selected)':'transparent',color:dis?'var(--text-tertiary)':act?'var(--text-brand)':'var(--text-primary)',fontSize:'var(--text-sm)',fontWeight:act?600:400,fontVariantNumeric:'tabular-nums',cursor:dis?'default':'pointer',fontFamily:'inherit'});
const pages=[];
const push=(p)=>pages.push(p);
if(pageCount<=7){for(let i=1;i<=pageCount;i++)push(i);}
else{push(1);if(page>3)push('…');for(let i=Math.max(2,page-1);i<=Math.min(pageCount-1,page+1);i++)push(i);if(page<pageCount-2)push('…');push(pageCount);}
return <div style={{display:'flex',alignItems:'center',gap:'4px',fontFamily:'var(--font-ui)',...style}}>
{total!=null&&<span style={{fontSize:'var(--text-sm)',color:'var(--text-secondary)',marginRight:'8px',fontVariantNumeric:'tabular-nums'}}>{(page-1)*pageSize+1}–{Math.min(page*pageSize,total)} из {total}</span>}
<button type="button" style={btn(false,page<=1)} disabled={page<=1} onClick={()=>onChange&&onChange(page-1)}><Icon name="chevron-left" size={15}/></button>
{pages.map((p,i)=>p==='…'?<span key={'d'+i} style={{...btn(false,true),border:'none'}}>…</span>:
<button key={p} type="button" style={btn(p===page,false)} onClick={()=>onChange&&onChange(p)}>{p}</button>)}
<button type="button" style={btn(false,page>=pageCount)} disabled={page>=pageCount} onClick={()=>onChange&&onChange(page+1)}><Icon name="chevron-right" size={15}/></button>
</div>;
}
