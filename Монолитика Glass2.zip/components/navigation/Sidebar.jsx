import React from 'react';
import {Icon} from '../core/Icon.jsx';
export function Sidebar({sections=[],activeId,onSelect,header,footer,width=232,style}){
const [openIds,setOpen]=React.useState(()=>new Set(sections.flatMap(s=>s.items.filter(i=>i.children&&i.children.some(c=>c.id===activeId)).map(i=>i.id))));
const toggle=(id)=>setOpen(p=>{const n=new Set(p);n.has(id)?n.delete(id):n.add(id);return n;});
const Item=({it,depth=0})=>{
const hasKids=it.children&&it.children.length>0;
const open=openIds.has(it.id);
const active=it.id===activeId;
const [hov,setHov]=React.useState(false);
return <div>
<div onClick={()=>hasKids?toggle(it.id):onSelect&&onSelect(it.id)}
onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
style={{display:'flex',alignItems:'center',gap:'10px',height:'34px',padding:`0 10px 0 ${10+depth*24}px`,margin:'1px 8px',borderRadius:'var(--radius-md)',cursor:'pointer',fontSize:'var(--text-base)',fontWeight:active?500:400,color:active?'var(--text-brand)':'var(--text-primary)',background:active?'var(--surface-selected)':hov?'var(--gray-100)':'transparent',transition:'background var(--transition-fast)'}}>
{it.icon&&<Icon name={it.icon} size={17} color={active?'var(--brand)':'var(--text-secondary)'}/>}
<span style={{flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{it.label}</span>
{it.badge!=null&&<span style={{fontSize:'11px',fontWeight:600,fontVariantNumeric:'tabular-nums',background:active?'var(--blue-100)':'var(--gray-100)',color:active?'var(--blue-700)':'var(--text-secondary)',borderRadius:'999px',padding:'1px 7px'}}>{it.badge}</span>}
{hasKids&&<Icon name="chevron-down" size={14} color="var(--text-tertiary)" style={{transform:open?'none':'rotate(-90deg)',transition:'transform var(--transition-fast)'}}/>}
</div>
{hasKids&&open&&it.children.map(c=><Item key={c.id} it={c} depth={depth+1}/>)}
</div>;
};
return <nav style={{width,flex:'none',display:'flex',flexDirection:'column',background:'var(--glass-side)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',borderRight:'1px solid var(--glass-border)',fontFamily:'var(--font-ui)',height:'100%',overflowY:'auto',...style}}>
{header&&<div style={{padding:'16px 18px 12px'}}>{header}</div>}
<div style={{flex:1,paddingBottom:'8px'}}>
{sections.map((s,i)=><div key={i}>
{s.title&&<div style={{padding:'14px 18px 4px',fontSize:'11px',fontWeight:600,letterSpacing:'.04em',textTransform:'uppercase',color:'var(--text-tertiary)'}}>{s.title}</div>}
{s.items.map(it=><Item key={it.id} it={it}/>)}
</div>)}
</div>
{footer&&<div style={{borderTop:'1px solid var(--border-default)',padding:'12px 16px'}}>{footer}</div>}
</nav>;
}
