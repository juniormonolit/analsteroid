/** Табы с нижним синим подчёркиванием; опциональный счётчик. */
export interface TabsProps {
  items: Array<string | { value: string; label: string; count?: number }>;
  value?: string;
  onChange?: (value: string) => void;
  size?: 'sm' | 'md';
  style?: React.CSSProperties;
}
