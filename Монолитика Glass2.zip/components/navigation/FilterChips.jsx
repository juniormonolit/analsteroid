import React from 'react';
import {Icon} from '../core/Icon.jsx';
export function FilterChips({items=[],value,values,onChange,multi=false,style}){
const sel=multi?(values||[]):[value];
const click=(v)=>{
if(!onChange)return;
if(multi){const n=sel.includes(v)?sel.filter(x=>x!==v):[...sel,v];onChange(n);}
else onChange(v);
};
return <div style={{display:'flex',gap:'8px',flexWrap:'wrap',fontFamily:'var(--font-ui)',...style}}>
{items.map((it,i)=>{const v=it.value??it,l=it.label??it,act=sel.includes(v);
return <button key={i} type="button" onClick={()=>click(v)}
style={{appearance:'none',display:'inline-flex',alignItems:'center',gap:'6px',height:'28px',padding:'0 12px',borderRadius:'var(--radius-full)',border:`1px solid ${act?'var(--interactive)':'var(--border-strong)'}`,background:act?'var(--surface-selected)':'var(--surface-card)',color:act?'var(--text-brand)':'var(--text-primary)',fontSize:'var(--text-sm)',fontFamily:'inherit',fontWeight:act?500:400,cursor:'pointer',transition:'all var(--transition-fast)'}}
onMouseEnter={e=>{if(!act)e.currentTarget.style.background='var(--gray-50)';}}
onMouseLeave={e=>{if(!act)e.currentTarget.style.background='var(--surface-card)';}}>
{l}{act&&multi&&<Icon name="x" size={12}/>}
</button>;})}
</div>;
}
