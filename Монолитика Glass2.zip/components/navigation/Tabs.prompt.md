Переключение видов внутри страницы (не заменяет сайдбар).

```jsx
<Tabs items={[{value:'q',label:'Квесты',count:3},{value:'r',label:'Награды'}]} value={tab} onChange={setTab}/>
```
