/** Пагинация с многоточием и счётчиком «1–50 из 169». */
export interface PaginationProps {
  page: number;
  pageCount: number;
  onChange?: (page: number) => void;
  /** Всего строк — включает счётчик слева */
  total?: number;
  pageSize?: number;
  style?: React.CSSProperties;
}
