/** Чипы-фильтры: одиночный или множественный выбор; активный — бордер и текст синие, заливка blue-50. */
export interface FilterChipsProps {
  items: Array<string | { value: string; label: string }>;
  /** Одиночный режим */
  value?: string;
  /** Множественный режим (multi) */
  values?: string[];
  multi?: boolean;
  onChange?: (v: string | string[]) => void;
  style?: React.CSSProperties;
}
