/**
 * Светлая боковая навигация: секции + 2 уровня вложенности; активный пункт — заливка blue-50 и синий текст.
 * @startingPoint section="Навигация" subtitle="Сайдбар с секциями и вложенностью" viewport="700x400"
 */
export interface SidebarProps {
  sections: Array<{
    title?: string;
    items: Array<{
      id: string;
      label: string;
      /** Имя из Icon */
      icon?: string;
      badge?: string | number;
      children?: Array<{ id: string; label: string; badge?: string | number }>;
    }>;
  }>;
  activeId?: string;
  onSelect?: (id: string) => void;
  /** Верх: логотип. Низ: блок пользователя */
  header?: React.ReactNode;
  footer?: React.ReactNode;
  width?: number;
  style?: React.CSSProperties;
}
