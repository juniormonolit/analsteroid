Боковая навигация приложения (светлая, 232px): секции с капс-заголовками, пункты с иконками и бейджами, раскрывающиеся подпункты.

```jsx
<Sidebar activeId="dash" onSelect={setScreen}
 header={<img src="assets/logo-tdm.png" height="24"/>}
 sections={[{title:'Аналитика',items:[
  {id:'dash',label:'Дашборд',icon:'dashboard'},
  {id:'rep',label:'Отчёты',icon:'file',children:[{id:'rep-plan',label:'План/факт'}]},
 ]}]}/>
```
