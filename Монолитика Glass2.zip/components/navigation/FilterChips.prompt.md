Быстрые фильтры над таблицами и списками.

```jsx
<FilterChips items={['Все','Просроченные','Выполненные']} value={f} onChange={setF}/>
<FilterChips multi items={['Москва','Казань','Пермь']} values={cities} onChange={setCities}/>
```
