Пояснение к иконкам и сокращениям.

```jsx
<Tooltip content="Выгрузить в Excel"><Button variant="ghost" icon={<Icon name="download" size={16}/>}/></Tooltip>
```
