import React from 'react';
import {Icon} from '../core/Icon.jsx';
export function Toast({status='info',title,description,onClose,style}){
const map={success:{i:'check',c:'var(--success)'},danger:{i:'alert',c:'var(--danger)'},warning:{i:'alert',c:'var(--warning)'},info:{i:'info',c:'var(--info)'}};
const m=map[status]||map.info;
const [hov,setHov]=React.useState(false);
return <div style={{display:'flex',alignItems:'flex-start',gap:'10px',width:'340px',padding:'12px 10px 12px 14px',color:'var(--text-primary)',background:'var(--surface-overlay)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',border:'1px solid var(--glass-border)',borderRadius:'var(--radius-lg)',boxShadow:'var(--shadow-toast)',fontFamily:'var(--font-ui)',boxSizing:'border-box',...style}}>
<span style={{width:'20px',height:'20px',borderRadius:'50%',flex:'none',display:'flex',alignItems:'center',justifyContent:'center',background:m.c,color:'#fff'}}><Icon name={m.i} size={12} strokeWidth={3}/></span>
<div style={{flex:1,minWidth:0}}>
<div style={{fontSize:'var(--text-base)',fontWeight:600,lineHeight:'20px',color:'var(--text-primary)'}}>{title}</div>
{description&&<div style={{fontSize:'var(--text-sm)',color:'var(--text-secondary)',lineHeight:'18px',marginTop:'2px'}}>{description}</div>}
</div>
{onClose&&<span onClick={onClose} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
style={{width:'20px',height:'20px',flex:'none',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',color:hov?'var(--text-primary)':'var(--text-tertiary)',background:hov?'var(--gray-100)':'transparent',borderRadius:'var(--radius-sm)',transition:'all var(--transition-fast)'}}><Icon name="x" size={13}/></span>}
</div>;
}
