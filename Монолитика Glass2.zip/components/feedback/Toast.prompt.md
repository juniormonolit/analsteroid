Тост после действий: сохранение, экспорт, ошибка.

```jsx
<Toast status="success" title="Отчёт выгружен" description="plan-fakt-iyul.xlsx" onClose={hide}/>
```
