Модалка подтверждений и форм. Закрытие панели с несохранённым черновиком — обязательный диалог «Есть несохранённые изменения» (Сохранить primary / Не сохранять ghost-danger / Отмена secondary). Для спесименов — проп `inline`.

```jsx
<Modal open={open} title="Удалить отчёт?" onClose={close}
 footer={<><Button variant="secondary" onClick={close}>Отмена</Button><Button variant="danger">Удалить</Button></>}>
 Действие нельзя отменить.
</Modal>
```
