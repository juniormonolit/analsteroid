/** Тост-уведомление: белая карточка, цветной круг-иконка статуса. Правый нижний угол экрана. */
export interface ToastProps {
  status?: 'success' | 'danger' | 'warning' | 'info';
  title: string;
  description?: string;
  onClose?: () => void;
  style?: React.CSSProperties;
}
