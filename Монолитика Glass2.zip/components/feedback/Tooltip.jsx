import React from 'react';
export function Tooltip({content,side='top',children,style}){
const [show,setShow]=React.useState(false);
const pos={
top:{bottom:'100%',left:'50%',transform:'translate(-50%,-6px)'},
bottom:{top:'100%',left:'50%',transform:'translate(-50%,6px)'},
left:{right:'100%',top:'50%',transform:'translate(-6px,-50%)'},
right:{left:'100%',top:'50%',transform:'translate(6px,-50%)'},
}[side];
return <span style={{position:'relative',display:'inline-flex',...style}}
onMouseEnter={()=>setShow(true)} onMouseLeave={()=>setShow(false)}>
{children}
{show&&<span style={{position:'absolute',...pos,background:'var(--gray-900)',color:'#fff',fontSize:'var(--text-xs)',fontFamily:'var(--font-ui)',fontWeight:500,padding:'5px 9px',borderRadius:'var(--radius-sm)',whiteSpace:'nowrap',zIndex:60,pointerEvents:'none'}}>{content}</span>}
</span>;
}
