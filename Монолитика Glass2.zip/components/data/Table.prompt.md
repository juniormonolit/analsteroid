Таблица отчётов (169+ строк — норма). Паттерны из ReportTable кодовой базы: ранговая тепловая карта, ин-селл бары, акцентная метрика, ховер строки с синей полоской слева.

```jsx
<Table maxHeight={420}
 columns={[
  {key:'name',label:'Клиент'},
  {key:'fact',label:'Факт, ₽',align:'right',bar:true},
  {key:'pct',label:'Выполнение, %',align:'right',heatmap:true},
  {key:'refusals',label:'Отказы',align:'right',heatmap:true,invert:true},
 ]}
 rows={data} totals={{fact:'11 902 118'}}/>
```

heatmap считает СРЕДНИЙ РАНГ значения в колонке (не min/max), числа парсятся из строк с пробелами. Полные значения в ячейках, сокращений нет.
