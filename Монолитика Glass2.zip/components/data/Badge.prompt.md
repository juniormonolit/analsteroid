Статус в таблицах и карточках.

```jsx
<Badge status="success" dot>Выполнен</Badge>
<Badge status="danger">Просрочен</Badge>
<Badge status="neutral">Черновик</Badge>
```
