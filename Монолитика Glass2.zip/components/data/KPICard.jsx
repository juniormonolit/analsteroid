import React from 'react';
import {Icon} from '../core/Icon.jsx';
export function KPICard({label,value,delta,deltaLabel,icon,accent=false,footer,style}){
const up=delta!=null&&delta>=0;
const [hov,setHov]=React.useState(false);
return <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
style={{background:accent?'var(--grad-brand)':'var(--surface-card)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',color:accent?'#fff':'var(--text-primary)',border:`1px solid ${accent?'rgba(255,255,255,.3)':'var(--glass-border)'}`,borderRadius:'var(--radius-xl)',padding:'var(--sp-5)',display:'flex',flexDirection:'column',gap:'6px',fontFamily:'var(--font-ui)',boxShadow:hov?'var(--shadow-hover)':'var(--shadow-card)',transition:'box-shadow var(--transition-normal)',...style}}>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:'8px'}}>
<span style={{fontSize:'var(--text-sm)',fontWeight:500,color:accent?'rgba(255,255,255,.85)':'var(--text-secondary)'}}>{label}</span>
{icon&&<span style={{width:'34px',height:'34px',borderRadius:'999px',display:'flex',alignItems:'center',justifyContent:'center',background:accent?'rgba(255,255,255,.18)':'var(--blue-50)',color:accent?'#fff':'var(--brand)'}}>{icon}</span>}
</div>
<div style={{display:'flex',alignItems:'baseline',gap:'10px',flexWrap:'wrap'}}>
<span className="tnum" style={{fontSize:'var(--kpi-size)',fontWeight:'var(--kpi-weight)',lineHeight:1.1,fontVariantNumeric:'tabular-nums',whiteSpace:'nowrap'}}>{value}</span>
{delta!=null&&<span style={{display:'inline-flex',alignItems:'center',gap:'3px',fontSize:'var(--text-xs)',fontWeight:600,fontVariantNumeric:'tabular-nums',padding:'2px 7px',borderRadius:'999px',background:accent?'rgba(255,255,255,.18)':up?'var(--success-bg)':'var(--danger-bg)',color:accent?'#fff':up?'var(--success-text)':'var(--danger-text)'}}>
<Icon name={up?'trend-up':'trend-down'} size={11}/>{up?'+':'−'}{Math.abs(delta).toLocaleString('ru-RU')}%</span>}
</div>
{(footer||deltaLabel)&&<span style={{fontSize:'var(--text-xs)',color:accent?'rgba(255,255,255,.75)':'var(--text-tertiary)',fontVariantNumeric:'tabular-nums'}}>{footer||deltaLabel}</span>}
</div>;
}
