/** Компактный бейдж сравнения (из ReportTable): значение + стрелка тренда; тултип «пред. X · +Δ / +Δ%»; «~» в пределах порога нейтральности. */
export interface TrendBadgeProps {
  value: number | null;
  /** Значение прошлого периода */
  prev: number | null;
  unit?: string;
  decimals?: number;
  /** Порог нейтральности в %, внутри — «~» */
  threshold?: number;
  style?: React.CSSProperties;
}
