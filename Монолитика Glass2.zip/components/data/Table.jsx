import React from 'react';
// Паттерны перенесены из ReportTable.tsx кодовой базы: тепловая карта по СРЕДНЕМУ РАНГУ
// значения (не по min/max), пастельные опорные цвета GS (red→yellow→green, tint 0.8),
// ин-селл бары, ховер всей строки + акцентная полоска слева у первой ячейки.
export function mixHex(hex,toHex,t){
const a=parseInt(hex.slice(1),16),b=parseInt(toHex.slice(1),16);
const ar=(a>>16)&255,ag=(a>>8)&255,ab=a&255,br=(b>>16)&255,bg=(b>>8)&255,bb=b&255;
return '#'+[Math.round(ar+(br-ar)*t),Math.round(ag+(bg-ag)*t),Math.round(ab+(bb-ab)*t)].map(v=>v.toString(16).padStart(2,'0')).join('');
}
const HEAT_RED='#ffcccc',HEAT_YELLOW='#ffffcc',HEAT_GREEN='#ccffcc';
const heatMix=(t)=>t<=0.5?mixHex(HEAT_RED,HEAT_YELLOW,t/0.5):mixHex(HEAT_YELLOW,HEAT_GREEN,(t-0.5)/0.5);
// Тёмная тема: доля подмеса меньше (как --color-highlight-pct 68%→32% в макете) —
// пастель подмешивается к тёмной карточке, текст остаётся светлым
const isDark=()=>typeof document!=='undefined'&&document.documentElement.getAttribute('data-theme')==='dark';
// Подписка на смену data-theme — heat-цвета пересчитываются синхронно с темой,
// а не «на рендер позади» (тема ставится в useEffect хоста после рендера)
function useThemeDark(){
const [dark,setDark]=React.useState(isDark);
React.useEffect(()=>{
const mo=new MutationObserver(()=>setDark(isDark()));
mo.observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
setDark(isDark());
return()=>mo.disconnect();
},[]);
return dark;
}
const heatBg=(t,dark)=>dark?mixHex('#16233A',heatMix(t),0.35):heatMix(t);
const heatFg=(dark)=>dark?'#e6e8ec':'#1A202C';
const toNum=(v)=>{if(typeof v==='number')return v;if(v==null)return null;const n=parseFloat(String(v).replace(/[\s\u00A0\u202F]/g,'').replace(',','.').replace(/[^0-9.\-]/g,''));return isNaN(n)?null:n;};
// Средний ранг значения в отсортированном массиве колонки (0..1) — как heatRankT в коде
function rankT(vals,value){
if(value==null||vals.length===0)return undefined;
if(vals.length===1||vals[0]===vals[vals.length-1])return 0.5;
let lo=0;while(lo<vals.length&&vals[lo]<value)lo++;
let hi=lo;while(hi<vals.length&&vals[hi]<=value)hi++;
return (lo+(hi-lo-1)/2)/(vals.length-1);
}
export function Table({columns=[],rows=[],totals,zebra=true,maxHeight,onRowClick,style}){
const [hoverIdx,setHoverIdx]=React.useState(null);
const dark=useThemeDark();
// Предрасчёт рангов для heatmap/bar-колонок
const stats=React.useMemo(()=>{
const s={};
for(const c of columns){
if(!c.heatmap&&!c.bar)continue;
s[c.key]=rows.map(r=>toNum(r[c.key])).filter(v=>v!=null).sort((a,b)=>a-b);
}
return s;
},[columns,rows]);
const cell=(c)=>({padding:'0 var(--table-cell-px)',textAlign:c.align||'left',fontVariantNumeric:'tabular-nums',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',maxWidth:c.width,width:c.width});
const cellDecor=(c,r)=>{
const out={};
if(c.accent){out.fontWeight=600;out.background='var(--surface-selected)';}
if(c.heatmap){
let t=rankT(stats[c.key]||[],toNum(r[c.key]));
if(t!==undefined){if(c.invert)t=1-t;out.background=heatBg(t,dark);out.color=heatFg(dark);out._heat=true;}
}
return out;
};
const barSpan=(c,r,content)=>{
if(!c.bar)return content;
const vals=stats[c.key]||[];
const v=toNum(r[c.key]),max=vals.length?vals[vals.length-1]:null;
const w=v!=null&&max?Math.max(2,Math.round(v/max*100)):0;
return <span style={{position:'relative',display:'inline-block',minWidth:'70%'}}>
<span style={{position:'absolute',inset:'-3px 0',[c.align==='right'?'right':'left']:'-4px',width:w+'%',background:'var(--blue-100)',borderRadius:'4px',opacity:.55}}></span>
<span style={{position:'relative'}}>{content}</span>
</span>;
};
return <div style={{border:'1px solid var(--glass-border)',borderRadius:'var(--radius-lg)',overflow:'hidden',fontFamily:'var(--font-ui)',background:'var(--surface-card)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',...style}}>
<div style={{maxHeight,overflowY:maxHeight?'auto':'visible'}}>
<table style={{width:'100%',borderCollapse:'collapse',fontSize:'var(--text-sm)'}}>
<thead><tr>
{columns.map((c,i)=><th key={i} style={{...cell(c),position:'sticky',top:0,zIndex:2,height:'36px',background:'var(--gray-50)',borderBottom:'1px solid var(--border-default)',boxShadow:'0 1px 0 0 var(--gray-50)',fontSize:'var(--text-xs)',fontWeight:600,color:c.accent?'var(--text-brand)':'var(--text-secondary)'}}>{c.label}</th>)}
</tr></thead>
<tbody>
{rows.map((r,ri)=>{
const hov=hoverIdx===ri;
const base=zebra&&ri%2?'var(--gray-50)':'var(--surface-card)';
return <tr key={ri} onClick={onRowClick?()=>onRowClick(r,ri):undefined}
onMouseEnter={()=>setHoverIdx(ri)} onMouseLeave={()=>setHoverIdx(null)}
style={{height:'var(--table-row-h)',cursor:onRowClick?'pointer':'default',borderBottom:zebra?'none':'1px solid var(--gray-100)'}}>
{columns.map((c,ci)=>{
const decor=cellDecor(c,r);
return <td key={ci} style={{...cell(c),color:'var(--text-primary)',...decor,
...(hov?{background:'var(--blue-50)',color:decor._heat?heatFg(dark):'var(--text-primary)',...(decor._heat?{background:decor.background}:{})}:decor.background?{}:{background:base}),
...(hov&&ci===0?{boxShadow:'inset 3px 0 0 0 var(--interactive)'}:{})}}>
{barSpan(c,r,c.render?c.render(r[c.key],r,ri):r[c.key])}
</td>;})}
</tr>;})}
</tbody>
{totals&&<tfoot><tr style={{height:'36px',position:'sticky',bottom:0}}>
{columns.map((c,i)=><td key={i} style={{...cell(c),background:'var(--blue-100)',borderTop:'1px solid var(--blue-200)',fontWeight:600,color:'var(--text-brand)'}}>{totals[c.key]??(i===0?'Итого':'')}</td>)}
</tr></tfoot>}
</table>
</div>
</div>;
}
