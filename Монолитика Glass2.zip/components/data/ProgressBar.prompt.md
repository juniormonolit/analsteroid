Прогресс план/факт (референс doc.track: «8 из 17 сегодня»).

```jsx
<ProgressBar label="Отгрузки сегодня" value={8} max={17} showValue caption="48 % дневного плана"/>
<ProgressBar value={82} color="var(--success)" height={6}/>
```
