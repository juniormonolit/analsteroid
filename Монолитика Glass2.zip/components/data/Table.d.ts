/**
 * Компактная таблица отчётов: строки 34px, sticky-шапка и итоги, зебра, ховер всей строки
 * с акцентной полоской слева (как в ReportTable). Колонки умеют heatmap (ранговая
 * тепловая карта, пастель красный→жёлтый→зелёный), bar (ин-селл бар) и accent.
 * @startingPoint section="Данные" subtitle="Плотная таблица: heatmap, бары, итоги" viewport="700x600"
 */
export interface TableProps {
  columns: Array<{
    key: string;
    label: string;
    align?: 'left' | 'right' | 'center';
    width?: number | string;
    render?: (value: any, row: any, rowIndex: number) => React.ReactNode;
    /** Ранговая тепловая карта по колонке (лучше = зеленее) */
    heatmap?: boolean;
    /** Инверсия шкалы heatmap: «меньше = лучше» */
    invert?: boolean;
    /** Горизонтальный бар за значением (доля от максимума колонки) */
    bar?: boolean;
    /** Акцентная колонка: жирный + заливка blue-50 */
    accent?: boolean;
  }>;
  rows: any[];
  totals?: Record<string, React.ReactNode>;
  zebra?: boolean;
  maxHeight?: number | string;
  onRowClick?: (row: any, index: number) => void;
  style?: React.CSSProperties;
}
