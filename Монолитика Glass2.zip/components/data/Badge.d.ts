/** Бейдж статуса — единственное место семантических цветов в таблицах. */
export interface BadgeProps {
  status?: 'success' | 'danger' | 'warning' | 'info' | 'neutral' | 'brand';
  /** Точка-индикатор слева */
  dot?: boolean;
  children: React.ReactNode;
  style?: React.CSSProperties;
}
