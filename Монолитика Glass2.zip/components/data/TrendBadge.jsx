import React from 'react';
import {Icon} from '../core/Icon.jsx';
// Компактный бейдж сравнения из ReportTable: значение + стрелка тренда, тултип
// «пред. X · +Δ / +Δ%». Порог нейтральности «~» — threshold (по умолчанию 0).
const fmt=(v,dp=0)=>v==null?'—':v.toLocaleString('ru-RU',{minimumFractionDigits:dp,maximumFractionDigits:dp});
export function TrendBadge({value,prev,unit='',decimals=0,threshold=0,style}){
const delta=value!=null&&prev!=null?value-prev:null;
const deltaPct=delta!=null&&prev?delta/prev*100:null;
const dir=deltaPct==null?null:deltaPct>threshold?'up':deltaPct<-threshold?'down':'flat';
const tip=deltaPct==null?undefined:`пред. ${fmt(prev,decimals)}${unit?' '+unit:''} · ${delta>0?'+':''}${fmt(delta,decimals)} / ${deltaPct>0?'+':''}${fmt(deltaPct,1)}%`;
return <span title={tip} style={{display:'inline-flex',alignItems:'center',gap:'4px',fontVariantNumeric:'tabular-nums',fontFamily:'var(--font-ui)',...style}}>
{fmt(value,decimals)}{unit&&<span style={{color:'var(--text-secondary)'}}>{unit}</span>}
{dir==='up'&&<Icon name="trend-up" size={12} color="var(--success)"/>}
{dir==='down'&&<Icon name="trend-down" size={12} color="var(--danger)"/>}
{dir==='flat'&&<span style={{fontSize:'10px',color:'var(--text-tertiary)'}}>~</span>}
</span>;
}
