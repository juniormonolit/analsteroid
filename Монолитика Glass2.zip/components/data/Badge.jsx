import React from 'react';
export function Badge({status='info',children,dot=false,style}){
const map={
success:{bg:'var(--success-bg)',fg:'var(--success-text)',d:'var(--success)'},
danger:{bg:'var(--danger-bg)',fg:'var(--danger-text)',d:'var(--danger)'},
warning:{bg:'var(--warning-bg)',fg:'var(--warning-text)',d:'var(--warning)'},
info:{bg:'var(--info-bg)',fg:'var(--info-text)',d:'var(--info)'},
neutral:{bg:'var(--gray-100)',fg:'var(--gray-600)',d:'var(--gray-400)'},
brand:{bg:'var(--blue-50)',fg:'var(--blue-700)',d:'var(--blue-500)'},
};
const c=map[status]||map.info;
return <span style={{display:'inline-flex',alignItems:'center',gap:'6px',padding:'2px 9px',borderRadius:'var(--radius-full)',background:c.bg,color:c.fg,fontSize:'var(--text-xs)',fontWeight:500,fontFamily:'var(--font-ui)',whiteSpace:'nowrap',...style}}>
{dot&&<span style={{width:'6px',height:'6px',borderRadius:'50%',background:c.d}}></span>}
{children}
</span>;
}
