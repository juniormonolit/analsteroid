/**
 * Карточка KPI: крупная цифра 32px semibold, подпись серым, дельта-чип. accent — одна синяя карточка среди белых.
 * @startingPoint section="Данные" subtitle="KPI-карточка с дельтой; вариант accent" viewport="700x600"
 */
export interface KPICardProps {
  label: string;
  /** Уже отформатированное число: «12 480 350 ₽» */
  value: string;
  /** Проценты изменения; знак определяет цвет и стрелку */
  delta?: number;
  deltaLabel?: string;
  icon?: React.ReactNode;
  /** Синяя брендовая карточка — максимум одна в ряду */
  accent?: boolean;
  footer?: string;
  style?: React.CSSProperties;
}
