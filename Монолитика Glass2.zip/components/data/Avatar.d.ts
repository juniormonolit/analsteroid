/** Аватар: фото или инициалы на синем/сером круге. */
export interface AvatarProps {
  /** «Алексей Иванов» → «АИ» */
  name: string;
  src?: string;
  size?: number;
  style?: React.CSSProperties;
}
