import React from 'react';
import {Icon} from '../core/Icon.jsx';
export function EmptyState({icon='inbox',title='Нет данных',description,action,style}){
return <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:'8px',padding:'var(--sp-10) var(--sp-6)',textAlign:'center',fontFamily:'var(--font-ui)',...style}}>
<span style={{width:'48px',height:'48px',borderRadius:'50%',background:'var(--gray-100)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--text-tertiary)'}}><Icon name={icon} size={22}/></span>
<span style={{fontSize:'var(--text-md)',fontWeight:600,color:'var(--text-primary)'}}>{title}</span>
{description&&<span style={{fontSize:'var(--text-sm)',color:'var(--text-secondary)',maxWidth:'360px'}}>{description}</span>}
{action&&<div style={{marginTop:'8px'}}>{action}</div>}
</div>;
}
