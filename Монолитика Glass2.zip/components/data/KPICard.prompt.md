KPI-карточка дашборда; в ряду из 4 одна может быть accent (синяя) — как в референсе Boltshift.

```jsx
<KPICard accent label="Выручка" value="12 480 350 ₽" delta={4.9} footer="Прошлый месяц: 11 897 020 ₽" icon={<Icon name="wallet" size={16}/>}/>
<KPICard label="Отгрузки" value="1 692" delta={-6.0}/>
```
