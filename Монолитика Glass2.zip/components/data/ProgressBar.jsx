import React from 'react';
export function ProgressBar({value=0,max=100,label,caption,color='var(--interactive)',track='var(--gray-100)',height=8,showValue=false,style}){
const pct=Math.max(0,Math.min(100,(value/max)*100));
return <div style={{display:'flex',flexDirection:'column',gap:'6px',fontFamily:'var(--font-ui)',...style}}>
{(label||showValue)&&<div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',fontSize:'var(--text-sm)'}}>
<span style={{color:'var(--text-secondary)',fontWeight:500}}>{label}</span>
{showValue&&<span style={{fontWeight:600,fontVariantNumeric:'tabular-nums'}}>{value.toLocaleString('ru-RU')} <span style={{color:'var(--text-tertiary)',fontWeight:400}}>из {max.toLocaleString('ru-RU')}</span></span>}
</div>}
<div style={{height,background:track,borderRadius:'999px',overflow:'hidden'}}>
<div style={{width:pct+'%',height:'100%',background:color,borderRadius:'999px',transition:'width var(--transition-normal)'}}></div>
</div>
{caption&&<span style={{fontSize:'var(--text-xs)',color:'var(--text-tertiary)',fontVariantNumeric:'tabular-nums'}}>{caption}</span>}
</div>;
}
