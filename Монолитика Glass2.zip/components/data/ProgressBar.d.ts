/** Прогресс-бар «план/факт»: подпись, значение «8 из 17», тонкая полоса с синей заливкой. */
export interface ProgressBarProps {
  value: number;
  max?: number;
  label?: string;
  /** Подпись снизу: «48 % дневного плана» */
  caption?: string;
  color?: string;
  track?: string;
  height?: number;
  /** Показать «value из max» справа от лейбла */
  showValue?: boolean;
  style?: React.CSSProperties;
}
