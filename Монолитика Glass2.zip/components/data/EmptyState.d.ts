/** Пустое состояние: иконка в сером круге, причина, действие. */
export interface EmptyStateProps {
  /** Имя из Icon, по умолчанию inbox */
  icon?: string;
  title?: string;
  description?: string;
  /** Обычно <Button variant="secondary"> */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
