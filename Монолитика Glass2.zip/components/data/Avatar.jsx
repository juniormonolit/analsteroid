import React from 'react';
const COLORS=['var(--blue-500)','var(--blue-700)','var(--info)','var(--gray-500)','var(--blue-400)'];
export function Avatar({name='',src,size=32,style}){
const initials=name.split(/\s+/).filter(Boolean).slice(0,2).map(w=>w[0].toUpperCase()).join('');
const hue=name.split('').reduce((a,c)=>a+c.charCodeAt(0),0);
return <span style={{width:size,height:size,borderRadius:'50%',flex:'none',display:'inline-flex',alignItems:'center',justifyContent:'center',overflow:'hidden',background:src?'var(--gray-100)':COLORS[hue%COLORS.length],color:'#fff',fontSize:size*0.38,fontWeight:600,fontFamily:'var(--font-ui)',letterSpacing:'.02em',...style}}>
{src?<img src={src} alt={name} style={{width:'100%',height:'100%',objectFit:'cover'}}/>:initials||'?'}
</span>;
}
