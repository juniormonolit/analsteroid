function ManagerScreen(){
const tasks=[
{t:'Согласовать спецификацию — ГК «Монолит»',time:'10:30',done:true},
{t:'Звонок: ООО «Кирпичный двор»',time:'12:00',done:true},
{t:'Отгрузка АО «БетонПлюс» — проверить документы',time:'14:15',done:false},
{t:'Подготовить КП для ТД «Уралстрой»',time:'16:00',done:false},
{t:'Обновить статусы сделок',time:'17:30',done:false},
];
return <div style={{display:'flex',flexDirection:'column',gap:16}}>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:16,flexWrap:'wrap'}}>
<div>
<h1 style={{margin:0,fontSize:24,fontWeight:600,color:'var(--text-on-app)'}}>Добрый день, Алексей</h1>
<div style={{fontSize:13,color:'var(--text-on-app-secondary)',marginTop:2}}>Понедельник, 3 августа · до конца месяца 20 рабочих дней</div>
</div>
<div style={{display:'flex',alignItems:'center',gap:12}}>
<div style={{display:'inline-flex',alignItems:'center',gap:8,background:'var(--surface-card)',border:'1px solid var(--border-default)',borderRadius:999,padding:'7px 14px'}}>
<MLTAmount value={1250}/>
</div>
<Avatar name="Алексей Иванов" size={38}/>
</div>
</div>
<div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:14}}>
<CardBox>
<ProgressBar label="Отгрузки сегодня" value={8} max={17} showValue caption="48% дневного плана" height={10}/>
</CardBox>
<CardBox>
<ProgressBar label="Личный план месяца" value={2412300} max={3400000} showValue={false} caption="2 412 300 ₽ из 3 400 000 ₽ · 71%" color="var(--success)" height={10}/>
</CardBox>
<CardBox>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
<div>
<div style={{fontSize:13,color:'var(--text-secondary)',fontWeight:500}}>Место в рейтинге</div>
<div style={{fontSize:28,fontWeight:600,fontVariantNumeric:'tabular-nums',lineHeight:1.2}}>3 <span style={{fontSize:14,color:'var(--text-tertiary)',fontWeight:400}}>из 24</span></div>
</div>
<span style={{width:40,height:40,borderRadius:999,background:'var(--blue-50)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--brand)'}}><Icon name="trophy" size={19}/></span>
</div>
</CardBox>
</div>
<div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:14}}>
<CardBox title="Моя выручка, последние 8 недель" extra={<Badge status="success" dot>+12% к прошлому периоду</Badge>}>
<LineChart height={190} values={[420,510,470,630,580,690,720,810]} labels={['нед 24','нед 25','нед 26','нед 27','нед 28','нед 29','нед 30','нед 31']} valueFormat={(v)=>Math.round(v)+' тыс'}/>
</CardBox>
<CardBox title="Задачи на сегодня" extra={<span style={{fontSize:13,color:'var(--text-secondary)',fontVariantNumeric:'tabular-nums'}}>2 из 5</span>}>
<div style={{display:'flex',flexDirection:'column',gap:2}}>
{tasks.map((t,i)=><div key={i} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 6px',borderRadius:8,background:'transparent'}}>
<span style={{width:18,height:18,flex:'none',borderRadius:999,display:'flex',alignItems:'center',justifyContent:'center',background:t.done?'var(--interactive)':'var(--surface-card)',border:t.done?'1px solid var(--interactive)':'1px solid var(--border-strong)',color:'#fff'}}>{t.done&&<Icon name="check" size={11} strokeWidth={3}/>}</span>
<span style={{flex:1,fontSize:13,color:t.done?'var(--text-tertiary)':'var(--text-primary)',textDecoration:t.done?'line-through':'none'}}>{t.t}</span>
<span style={{fontSize:12,color:'var(--text-tertiary)',fontVariantNumeric:'tabular-nums'}}>{t.time}</span>
</div>)}
</div>
</CardBox>
</div>
<div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
<CardBox title="Мои клиенты — риски">
<Table zebra={false} columns={[
{key:'name',label:'Клиент'},
{key:'plan',label:'План, ₽',align:'right'},
{key:'pct',label:'Выполнение',width:150,render:(v)=><PctCell pct={v}/>},
{key:'st',label:'Статус',width:120,render:(v)=><Badge status={v} dot>{ST_LABEL[v]}</Badge>},
]} rows={REPORT_ROWS.filter(r=>r.st==='danger'||r.st==='warning').slice(0,4)}/>
</CardBox>
<CardBox title="Структура моих продаж">
<DonutChart size={160} thickness={20} centerValue="46%" centerLabel="Кирпич" segments={[{value:46,label:'Кирпич'},{value:27,label:'Бетон и ЖБИ'},{value:17,label:'Сухие смеси'},{value:10,label:'Прочее'}]}/>
</CardBox>
</div>
</div>;
}
window.ManagerScreen=ManagerScreen;
