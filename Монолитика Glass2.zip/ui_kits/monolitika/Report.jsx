function ReportScreen(){
const [page,setPage]=React.useState(1);
const [chip,setChip]=React.useState('Все');
const [mgr,setMgr]=React.useState('Все менеджеры');
const filtered=REPORT_ROWS.filter(r=>{
if(chip==='Выполняют план')return r.pct>=100;
if(chip==='Отстают')return r.pct>=45&&r.pct<100;
if(chip==='Риск срыва')return r.pct<45;
return true;
}).filter(r=>mgr==='Все менеджеры'||r.mgr===mgr);
const PS=15;
const pageRows=filtered.slice((page-1)*PS,page*PS);
const sum=(k)=>fmtR(filtered.reduce((a,r)=>a+parseInt(String(r[k]).replace(/\s/g,'')),0));
return <div style={{display:'flex',flexDirection:'column',gap:14}}>
<div style={{display:'flex',alignItems:'flex-end',justifyContent:'space-between',gap:16,flexWrap:'wrap'}}>
<div>
<h1 style={{margin:0,fontSize:24,fontWeight:600,color:'var(--text-on-app)'}}>План/факт по клиентам</h1>
<div style={{fontSize:13,color:'var(--text-on-app-secondary)',marginTop:2}}>Июль 2026 · {filtered.length} строк</div>
</div>
<div style={{display:'flex',gap:10,alignItems:'center'}}>
<Select size="sm" options={['Все менеджеры',...MGRS]} value={mgr} onChange={(v)=>{setMgr(v);setPage(1);}} style={{width:170}}/>
<DateRangePicker size="sm" start={new Date(2026,6,1)} end={new Date(2026,6,31)}/>
<Tooltip content="Выгрузить в Excel"><Button variant="secondary" size="sm" icon={<Icon name="download" size={15}/>}>Экспорт</Button></Tooltip>
</div>
</div>
<FilterChips items={['Все','Выполняют план','Отстают','Риск срыва']} value={chip} onChange={(v)=>{setChip(v);setPage(1);}}/>
{filtered.length===0?
<CardBox><EmptyState title="Нет данных за выбранный период" description="Измените фильтры или период отчёта" action={<Button variant="secondary" size="sm" onClick={()=>{setChip('Все');setMgr('Все менеджеры');}}>Сбросить фильтры</Button>}/></CardBox>
:<React.Fragment>
<Table maxHeight={520} columns={[
{key:'name',label:'Клиент'},
{key:'mgr',label:'Менеджер',width:110},
{key:'city',label:'Филиал',width:80},
{key:'plan',label:'План, ₽',align:'right'},
{key:'fact',label:'Факт, ₽',align:'right',bar:true},
{key:'pct',label:'Выполнение',width:150,heatmap:true,render:(v)=><PctCell pct={v}/>},
{key:'ship',label:'Отгрузки',align:'right',width:80},
{key:'st',label:'Статус',width:125,render:(v)=><Badge status={v} dot>{ST_LABEL[v]}</Badge>},
]} rows={pageRows} totals={{plan:sum('plan'),fact:sum('fact')}}/>
<div style={{display:'flex',justifyContent:'flex-end'}}>
<Pagination page={page} pageCount={Math.max(1,Math.ceil(filtered.length/PS))} total={filtered.length} pageSize={PS} onChange={setPage}/>
</div>
</React.Fragment>}
</div>;
}
window.ReportScreen=ReportScreen;
