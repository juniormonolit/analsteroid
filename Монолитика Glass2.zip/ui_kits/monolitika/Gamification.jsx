function GamificationScreen(){
const QuestCard=window.DesignSystem_311945.QuestCard||window.QuestCardFallback;
const [tab,setTab]=React.useState('quests');
const [spin,setSpin]=React.useState(false);
const [prize,setPrize]=React.useState(null);
const BALANCE=1250;
// Квесты — слоты и тиры как в движке: 1 дневной + 2 недельных + 1 месячный; награда = база(5/15/60) × множитель тира (0.4/0.7/1/2/4), XP = 5 × MLT
const quests=[
{tier:'blue',slot:'Дневной',title:'Сделать 3 продажи сегодня',progress:2,target:3,rewardMlt:5,rewardXp:25,deadline:'до конца дня',rerollPrice:10},
{tier:'epic',slot:'Недельный',title:'Продать бетон 5 новым клиентам',progress:2,target:5,rewardMlt:30,rewardXp:150,deadline:'ещё 3 дн.',rerollPrice:20},
{tier:'green',slot:'Недельный',title:'7 повторных продаж за неделю',progress:7,target:7,rewardMlt:10,rewardXp:50,status:'done'},
{tier:'legendary',slot:'Месячный',title:'Выручка 4 200 000 ₽ за август',progress:2941000,target:4200000,rewardMlt:240,rewardXp:1200,deadline:'ещё 27 дн.',rerollPrice:50,format:(v)=>window.DesignSystem_311945.FormatNum(v)},
];
const contractsMine=[{tier:'blue',title:'Оживить 5 «спящих» клиентов',progress:3,target:5,deposit:15,rewardMlt:40,deadline:'ещё 9 дн.'}];
const contractsOpen=[
{tier:'green',title:'Собрать 4 отзыва клиентов',deposit:10,rewardMlt:25,days:14},
{tier:'epic',title:'Продать 3 позиции новой товарной группы',deposit:30,rewardMlt:90,days:30},
];
// Магазин — реальный каталог (миграция 118); эмодзи разрешены в геймификации
const shop={
'Нематериальные':[
{e:'👑',t:'Титул / кастомная рамка бейджа',d:'Заметный титул рядом с именем на месяц',p:50},
{e:'🕙',t:'Поздний старт +2 часа',d:'Прийти на 2 часа позже в согласованный день',p:100},
{e:'🧹',t:'Сброс мёртвых сделок',d:'До 10 сделок из воронки без штрафа по метрикам',p:150},
{e:'⚡',t:'Приоритет лидов на 1 день',d:'Первым в очереди распределения лидов',p:250},
{e:'🏖️',t:'Отгул',d:'Полный оплачиваемый день отдыха',p:500},
],
'Командные':[
{e:'🍕',t:'Пицца-день отдела',d:'Купон руководителю на пиццу для всех',p:800},
{e:'⏰',t:'Поздний старт всего отдела',d:'+1 час всем, согласование с РОПом',p:1500},
{e:'🚌',t:'Тимбилдинг / выезд отдела',d:'Крупный командный приз, одобрение сверху',p:5000},
],
'Материальные':[
{e:'☕',t:'Кофе за счёт компании',d:'Купон — показать руководителю',p:25},
{e:'🎁',t:'Фирменный мерч-бокс',d:'Набор фирменного мерча',p:300},
{e:'📱',t:'iPhone (актуальный)',d:'Флагман — топ-приз, остался 1 шт.',p:15000},
],
};
// Пул гачи — миграция 120 (сумма шансов = 100%), джекпот 0,006% + гарант
const pool=[
{e:'🪙',t:'+2 MLT',c:'39,49%'},{e:'💰',t:'+5 MLT',c:'25%'},{e:'🍀',t:'+10 MLT — крутка отбилась',c:'15%'},
{e:'☕',t:'Кофе за счёт компании',c:'8%'},{e:'🕙',t:'Поздний старт +2 часа',c:'8%'},{e:'🧹',t:'Сброс мёртвых сделок',c:'4%'},
{e:'🏖️',t:'Отгул',c:'0,25%',r:'rare'},{e:'🎁',t:'Фирменный мерч-бокс',c:'0,25%',r:'rare'},
{e:'📱',t:'ДЖЕКПОТ: iPhone',c:'0,006%',r:'jackpot'},
];
const doSpin=()=>{setSpin(true);setPrize(null);setTimeout(()=>{setSpin(false);setPrize({e:'☕',t:'Кофе за счёт компании'});},1200);};
const H3=({children,extra})=><div style={{display:'flex',alignItems:'baseline',gap:10,margin:'4px 2px'}}><span style={{fontSize:15,fontWeight:700,color:'var(--text-on-app)'}}>{children}</span>{extra&&<span style={{fontSize:11,color:'var(--text-on-app-secondary)'}}>{extra}</span>}</div>;
return <div style={{display:'flex',flexDirection:'column',gap:16}}>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:16,flexWrap:'wrap'}}>
<div>
<h1 style={{margin:0,fontSize:24,fontWeight:600,color:'var(--text-on-app)'}}>Мои награды</h1>
<div style={{fontSize:13,color:'var(--text-on-app-secondary)',marginTop:2}}>Выполняйте квесты, копите MLT, обменивайте на призы</div>
</div>
<div style={{display:'inline-flex',alignItems:'center',gap:8,background:'var(--surface-card)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',border:'1px solid var(--glass-border)',boxShadow:'var(--shadow-card)',borderRadius:999,padding:'8px 16px'}}>
<MLTAmount value={BALANCE} size="lg"/>
</div>
</div>
<Tabs items={[{value:'quests',label:'Квесты',count:4},{value:'shop',label:'Магазин'},{value:'gacha',label:'Гача'},{value:'inv',label:'Инвентарь',count:2}]} value={tab} onChange={setTab}/>
{tab==='quests'&&<React.Fragment>
<div style={{fontSize:12,color:'var(--text-on-app-secondary)',margin:'-6px 2px 0'}}>Личные миссии: цели — от вашей истории продаж (120% медианы), тир — сложность относительно медианного менеджера компании. Провалил — ничего не теряешь, квест сгорает. Замена и доп. квест — за MLT.</div>
<div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))',gap:14}}>
{quests.map((q,i)=><QuestCard key={i} {...q}/>)}
</div>
<Button variant="secondary" size="sm" style={{alignSelf:'flex-start'}} title="Дневной выполнен — можно докупить ещё один квест на сегодня"icon={<MLTCoin size={14}/>}>Купить доп. квест за 30 MLT</Button>
<CardBox title="📜 Доска контрактов" extra={<span style={{fontSize:11,color:'var(--text-secondary)'}}>общий пул: бери любой тир добровольно; депозит замораживается — выполнил: депозит назад + награда, провалил — сгорает</span>}>
<div style={{display:'flex',flexDirection:'column',gap:10}}>
{contractsMine.map((c,i)=><QuestCard key={'m'+i} tier={c.tier} slot="Мой контракт" title={c.title} progress={c.progress} target={c.target} rewardMlt={c.rewardMlt} rewardXp={c.rewardMlt*5} deadline={c.deadline}/>)}
<div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
{contractsOpen.map((c,i)=><div key={i} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 12px',borderRadius:12,border:'1px solid var(--border-strong)',fontSize:13}}>
<span style={{width:8,height:8,borderRadius:999,background:`var(--quest-${c.tier})`,flex:'none'}}></span>
<span style={{flex:1,fontWeight:600}}>{c.title}</span>
<span style={{fontSize:12,color:'var(--text-secondary)',fontVariantNumeric:'tabular-nums'}}>{c.days} дн. · +{c.rewardMlt} MLT</span>
<Button size="sm" variant="secondary" title={`Депозит ${c.deposit} MLT замораживается: выполнил — вернётся с наградой, провалил — сгорит`}>Взять · депозит {c.deposit} MLT</Button>
</div>)}
</div>
</div>
</CardBox>
</React.Fragment>}
{tab==='shop'&&<div style={{display:'flex',flexDirection:'column',gap:14}}>
{Object.entries(shop).map(([cat,items])=><React.Fragment key={cat}>
<H3 extra={cat==='Нематериальные'?'привилегии — самое ценное в каталоге':cat==='Командные'?'покупает любой, активирует руководитель':'выдача через руководителя'}>{cat}</H3>
<div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:14}}>
{items.map((s,i)=><CardBox key={i} style={{padding:16,gap:8}}>
<div style={{display:'flex',alignItems:'center',gap:12}}>
<span style={{width:46,height:46,borderRadius:14,flex:'none',display:'flex',alignItems:'center',justifyContent:'center',fontSize:26,background:'var(--surface-selected)'}}>{s.e}</span>
<div style={{minWidth:0}}>
<div style={{fontSize:14,fontWeight:700,lineHeight:1.25}}>{s.t}</div>
<div style={{fontSize:12,color:'var(--text-secondary)',marginTop:2}}>{s.d}</div>
</div>
</div>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:4}}>
<MLTAmount value={s.p}/>
<Button size="sm" variant={s.p<=BALANCE?'primary':'secondary'} disabled={s.p>BALANCE}>{s.p<=BALANCE?'Купить':'Не хватает'}</Button>
</div>
</CardBox>)}
</div>
</React.Fragment>)}
</div>}
{tab==='gacha'&&<div style={{display:'grid',gridTemplateColumns:'340px 1fr',gap:14,alignItems:'start'}}>
<div style={{borderRadius:'var(--radius-xl)',background:'var(--grad-gacha)',color:'#fff',padding:24,display:'flex',flexDirection:'column',alignItems:'center',gap:14,boxShadow:'var(--glow-rare)',border:'1px solid rgba(255,255,255,.25)'}}>
<div style={{animation:spin?'coin-spin 0.5s linear infinite':'none'}}><MLTCoin size={96}/></div>
<div style={{fontSize:18,fontWeight:600}}>Гача</div>
<div style={{fontSize:13,opacity:.85,textAlign:'center'}}>Серверный RNG. Каждая 100-я крутка без редкого приза гарантирует редкий (гарант-счётчик виден всем)</div>
{prize&&<div style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:12,background:'rgba(255,255,255,.16)',border:'1px solid rgba(255,255,255,.3)',fontWeight:600,width:'100%'}}><span style={{fontSize:22}}>{prize.e}</span>Выпало: {prize.t}</div>}
<Button variant="secondary" onClick={doSpin} disabled={spin} style={{width:'100%'}}>{spin?'Крутим…':'Крутить за 10 MLT'}</Button>
<div style={{fontSize:11,opacity:.7,fontVariantNumeric:'tabular-nums'}}>До гаранта: 37 круток</div>
</div>
<CardBox title="Призовой пул и шансы" extra={<span style={{fontSize:11,color:'var(--text-secondary)'}}>всё из гачи можно купить в магазине напрямую</span>}>
<div style={{display:'flex',flexDirection:'column'}}>
{pool.map((p,i)=><div key={i} style={{display:'flex',alignItems:'center',gap:12,padding:'8px 4px',borderBottom:i<pool.length-1?'1px solid var(--border-default)':'none',fontSize:13,background:p.r==='jackpot'?'linear-gradient(90deg,rgba(212,160,23,.12),transparent)':'transparent',borderRadius:p.r==='jackpot'?8:0}}>
<span style={{fontSize:20,width:28,textAlign:'center'}}>{p.e}</span>
<span style={{flex:1,fontWeight:p.r?700:400}}>{p.t}</span>
{p.r&&<Badge status={p.r==='jackpot'?'warning':'brand'}>{p.r==='jackpot'?'джекпот':'редкий'}</Badge>}
<span style={{fontVariantNumeric:'tabular-nums',fontWeight:600,width:64,textAlign:'right'}}>{p.c}</span>
</div>)}
</div>
</CardBox>
</div>}
{tab==='inv'&&<div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:14}}>
{[{e:'🕙',t:'Поздний старт +2 часа',d:'Куплен 1 августа · действует до 1 ноября',st:<Badge status="info" dot>Ожидает активации</Badge>},
{e:'☕',t:'Кофе за счёт компании',d:'Из гачи · 28 июля',st:<Badge status="success" dot>Использован</Badge>}].map((it,i)=>
<CardBox key={i} style={{padding:16,gap:8}}>
<div style={{display:'flex',alignItems:'center',gap:12}}>
<span style={{width:46,height:46,borderRadius:14,flex:'none',display:'flex',alignItems:'center',justifyContent:'center',fontSize:26,background:'var(--surface-selected)'}}>{it.e}</span>
<div><div style={{fontSize:14,fontWeight:700}}>{it.t}</div><div style={{fontSize:12,color:'var(--text-secondary)',marginTop:2}}>{it.d}</div></div>
</div>
{it.st}
</CardBox>)}
</div>}
</div>;
}
window.GamificationScreen=GamificationScreen;
