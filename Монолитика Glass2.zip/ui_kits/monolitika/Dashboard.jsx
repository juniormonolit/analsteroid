function DashboardScreen(){
const [range,setRange]=React.useState(null);
return <div style={{display:'flex',flexDirection:'column',gap:16}}>
<div style={{display:'flex',alignItems:'flex-end',justifyContent:'space-between',gap:16,flexWrap:'wrap'}}>
<div>
<h1 style={{margin:0,fontSize:24,fontWeight:600,color:'var(--text-on-app)'}}>Обзор продаж</h1>
<div style={{fontSize:13,color:'var(--text-on-app-secondary)',marginTop:2}}>Сводка по компании за выбранный период</div>
</div>
<div style={{display:'flex',gap:10,alignItems:'center'}}>
<DateRangePicker start={new Date(2026,6,1)} end={new Date(2026,6,31)}/>
<Button variant="secondary" icon={<Icon name="download" size={16}/>}>Экспорт</Button>
<Button icon={<Icon name="filter" size={16}/>}>Фильтры</Button>
</div>
</div>
<div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14}}>
<KPICard accent label="Выручка" value="12 480 350 ₽" delta={4.9} footer="Прошлый месяц: 11 897 020 ₽" icon={<Icon name="wallet" size={16}/>}/>
<KPICard label="Отгрузки" value="1 692" delta={-6.0} footer="Прошлый месяц: 1 800" icon={<Icon name="package" size={16}/>}/>
<KPICard label="Новые клиенты" value="110" delta={7.5} footer="Прошлый месяц: 89" icon={<Icon name="users" size={16}/>}/>
<KPICard label="Средний чек" value="73 760 ₽" delta={2.1} footer="Прошлый месяц: 72 240 ₽" icon={<Icon name="chart" size={16}/>}/>
</div>
<div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:14}}>
<CardBox title="Динамика продаж" extra={<Select size="sm" options={['По месяцам','По неделям']} value="По месяцам" style={{width:150}}/>}>
<BarChart height={210} values={[8.4,9.9,7.2,11.8,9.6,10.9,12.5,4.1]} labels={['янв','фев','мар','апр','май','июн','июл','авг']} activeIndex={6} valueFormat={(v)=>v.toFixed(0)+' млн'}/>
</CardBox>
<CardBox title="Выполнение плана">
<div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:8}}>
<Gauge percent={70.8} label="план компании, июль" size={210}/>
<div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,width:'100%',marginTop:6}}>
<div style={{background:'var(--gray-50)',borderRadius:10,padding:'10px 12px'}}>
<div style={{fontSize:12,color:'var(--text-secondary)'}}>План</div>
<div style={{fontSize:18,fontWeight:600,fontVariantNumeric:'tabular-nums'}}>17,6 млн ₽</div>
</div>
<div style={{background:'var(--gray-50)',borderRadius:10,padding:'10px 12px'}}>
<div style={{fontSize:12,color:'var(--text-secondary)'}}>Факт</div>
<div style={{fontSize:18,fontWeight:600,fontVariantNumeric:'tabular-nums'}}>12,5 млн ₽</div>
</div>
</div>
</div>
</CardBox>
</div>
<CardBox title="Последние отгрузки" extra={<Input size="sm" icon={<Icon name="search" size={15}/>} placeholder="Поиск по клиентам…" style={{width:220}}/>}>
<Table zebra={false} columns={[
{key:'name',label:'Клиент'},
{key:'mgr',label:'Менеджер',width:120},
{key:'city',label:'Филиал',width:90},
{key:'fact',label:'Сумма, ₽',align:'right'},
{key:'ship',label:'Позиции',align:'right',width:80},
{key:'st',label:'Статус',width:130,render:(v)=><Badge status={v} dot>{ST_LABEL[v]}</Badge>},
]} rows={REPORT_ROWS.slice(0,6)}/>
</CardBox>
</div>;
}
window.DashboardScreen=DashboardScreen;
