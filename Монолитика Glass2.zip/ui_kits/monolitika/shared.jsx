const {Sidebar,Tabs,FilterChips,Pagination,Button,Input,Select,DateRangePicker,Table,KPICard,ProgressBar,Badge,Avatar,EmptyState,Modal,Toast,Tooltip,LineChart,BarChart,DonutChart,Gauge,MLTCoin,MLTAmount,RewardCard,Icon,BrandLogo}=window.DesignSystem_311945;
const CLIENTS=['ООО «Стройторг»','ГК «Монолит»','ИП Сидоров','АО «БетонПлюс»','ООО «Кирпичный двор»','ТД «Уралстрой»','ООО «СтройАльянс»','ПК «Фундамент»','ООО «МегаСтрой»','ИП Волков','АО «ЖБИ-Профи»','ООО «Арматура-Трейд»','ТД «Панельстрой»','ООО «Цемторг»','ГК «СтройГрад»'];
const MGRS=['Иванов А.','Петрова М.','Крылов Д.','Смирнова О.','Гусев П.'];
const CITIES=['Москва','Казань','Пермь','Уфа'];
function seeded(i){let x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x);}
const fmtR=(n)=>Math.round(n).toLocaleString('ru-RU');
const REPORT_ROWS=Array.from({length:42},(_,i)=>{
const plan=400000+seeded(i)*3200000;
const k=0.35+seeded(i+100)*0.95;
const fact=plan*k;
const pct=Math.round(k*100);
return {id:i,name:CLIENTS[i%CLIENTS.length],mgr:MGRS[i%MGRS.length],city:CITIES[i%CITIES.length],plan:fmtR(plan),fact:fmtR(fact),pct,ship:Math.round(3+seeded(i+200)*40),
st:pct>=100?'success':pct>=70?'info':pct>=45?'warning':'danger'};
});
const ST_LABEL={success:'Выполнен',info:'В работе',warning:'Отстаёт',danger:'Риск срыва'};
function PctCell({pct}){
return <div style={{display:'flex',alignItems:'center',gap:8,minWidth:90}}>
<div style={{flex:1,height:5,background:'var(--gray-100)',borderRadius:999,overflow:'hidden'}}>
<div style={{width:Math.min(pct,100)+'%',height:'100%',borderRadius:999,background:pct>=100?'var(--success)':pct>=70?'var(--interactive)':pct>=45?'var(--warning)':'var(--danger)'}}></div>
</div>
<span style={{fontVariantNumeric:'tabular-nums',fontSize:12,fontWeight:600,width:34,textAlign:'right'}}>{pct}%</span>
</div>;
}
function CardBox({title,extra,children,style}){
return <div style={{background:'var(--surface-card)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',border:'1px solid var(--glass-border)',borderRadius:'var(--radius-xl)',boxShadow:'var(--shadow-card)',padding:20,display:'flex',flexDirection:'column',gap:12,...style}}>
{(title||extra)&&<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:12}}>
<span style={{fontSize:16,fontWeight:600}}>{title}</span>{extra}
</div>}
{children}
</div>;
}
Object.assign(window,{CLIENTS,MGRS,CITIES,REPORT_ROWS,ST_LABEL,PctCell,CardBox,fmtR,
Sidebar,Tabs,FilterChips,Pagination,Button,Input,Select,DateRangePicker,Table,KPICard,ProgressBar,Badge,Avatar,EmptyState,Modal,Toast,Tooltip,LineChart,BarChart,DonutChart,Gauge,MLTCoin,MLTAmount,RewardCard,Icon});
// Страховка от устаревшего _ds_bundle.js без BrandLogo: инлайн-копия того же знака
window.BrandLogo=BrandLogo||function BrandLogoFallback({size=20,withWordmark,style}){
const h=size,w=(size*24)/17;
const svg=React.createElement('svg',{width:w,height:h,viewBox:'0 0 24 17',fill:'none','aria-hidden':true},
React.createElement('rect',{x:0,y:0,width:6,height:17,rx:3,fill:'#3b82f6'}),
React.createElement('rect',{x:9,y:7,width:6,height:10,rx:3,fill:'#ef4444'}),
React.createElement('rect',{x:18,y:0,width:6,height:17,rx:3,fill:'#22c55e'}));
if(!withWordmark)return svg;
return React.createElement('span',{style:{display:'inline-flex',alignItems:'center',gap:Math.round(size*0.45),...style}},svg,
React.createElement('span',{style:{fontFamily:'var(--font-ui)',fontSize:size*0.9,fontWeight:700,color:'var(--text-primary)',letterSpacing:'-0.02em',lineHeight:1}},'Монолитика'));
};
// Страховка от устаревшего бандла без QuestCard: инлайн-копия новой плашки
const QC_TIERS={white:{label:'Обычный',color:'var(--quest-white,#9ca3af)'},green:{label:'Необычный',color:'var(--quest-green,#2f9e44)'},blue:{label:'Редкий',color:'var(--quest-blue,#1c7ed6)'},epic:{label:'Эпический',color:'var(--quest-epic,#9c36b5)'},legendary:{label:'Легендарный',color:'var(--quest-legendary,#e8590c)'}};
window.QuestCardFallback=function QuestCardFallback({tier='blue',slot='Дневной',title,progress=0,target=1,rewardMlt=0,rewardXp=0,status='active',deadline,rerollPrice,onReroll,style}){
const t=QC_TIERS[tier]||QC_TIERS.blue;
const done=status==='done';
const color=done?'var(--quest-green,#2f9e44)':t.color;
const pct=Math.min(100,Math.round(progress/Math.max(target,1)*100));
const f=(v)=>v>=10000?v.toLocaleString('ru-RU'):String(Math.round(v*10)/10);
return <div style={{display:'flex',flexDirection:'column',gap:10,padding:'14px 16px',borderRadius:'var(--radius-lg)',border:`1.5px solid color-mix(in srgb, ${color} 50%, transparent)`,background:`linear-gradient(color-mix(in srgb, ${color} 7%, transparent),color-mix(in srgb, ${color} 7%, transparent)),var(--surface-card)`,backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',boxShadow:'var(--shadow-card)',fontFamily:'var(--font-ui)',minWidth:0,...style}}>
<div style={{display:'flex',alignItems:'center',gap:8,minWidth:0}}>
<span style={{flex:'none',borderRadius:7,padding:'2px 7px',fontSize:10,fontWeight:700,letterSpacing:'.05em',textTransform:'uppercase',color:'#fff',background:t.color,whiteSpace:'nowrap'}}>{t.label}</span>
<span style={{fontSize:11,fontWeight:600,color:'var(--text-secondary)',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',minWidth:0}}>{slot}</span>
<span style={{marginLeft:'auto',flex:'none',fontSize:11,whiteSpace:'nowrap',color:done?'var(--success-text)':status==='failed'?'var(--text-tertiary)':'var(--text-secondary)',fontVariantNumeric:'tabular-nums',fontWeight:done?600:400}}>{done?'✅ выполнен':status==='failed'?'сгорел':deadline}</span>
</div>
<div style={{fontSize:14,fontWeight:700,color:'var(--text-primary)',lineHeight:1.35,overflowWrap:'break-word'}}>{title}</div>
<div style={{display:'flex',flexDirection:'column',gap:6}}>
<div style={{height:8,borderRadius:999,background:'var(--surface-sunken)',overflow:'hidden'}}>
<div style={{height:'100%',width:Math.max(pct,2)+'%',borderRadius:999,background:color}}></div>
</div>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:8,flexWrap:'wrap'}}>
<span style={{fontSize:11,fontVariantNumeric:'tabular-nums',color:'var(--text-secondary)',whiteSpace:'nowrap'}}>{f(progress)} из {f(target)}</span>
<span style={{flex:'none',display:'inline-flex',alignItems:'center',gap:5,background:'var(--surface-selected)',borderRadius:999,padding:'3px 9px',fontSize:11,fontWeight:700,fontVariantNumeric:'tabular-nums',color:'var(--text-brand)',whiteSpace:'nowrap'}}><MLTCoin size={13}/>+{rewardMlt} MLT · +{rewardXp} XP</span>
</div>
</div>
{status==='active'&&rerollPrice!=null&&<button type="button" onClick={onReroll} title="Не подходит квест? Замените его на другой того же тира. Спишется указанная сумма MLT; максимум одна замена."
style={{display:'flex',alignItems:'center',justifyContent:'center',flexWrap:'wrap',gap:'2px 6px',width:'100%',minHeight:30,padding:'4px 8px',appearance:'none',border:'1px solid var(--border-strong)',background:'transparent',borderRadius:9,fontSize:12,fontWeight:600,fontFamily:'inherit',color:'var(--text-primary)',cursor:'pointer'}}>Заменить квест за <span style={{display:'inline-flex',alignItems:'center',gap:4,fontVariantNumeric:'tabular-nums'}}><MLTCoin size={13}/>{rerollPrice} MLT</span></button>}
</div>;
};
