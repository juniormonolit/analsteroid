import React from 'react';
import {Icon} from '../core/Icon.jsx';
const M=['январь','февраль','март','апрель','май','июнь','июль','август','сентябрь','октябрь','ноябрь','декабрь'];
const MG=['янв','фев','мар','апр','мая','июн','июл','авг','сен','окт','ноя','дек'];
const fmt=(d)=>d?`${d.getDate()} ${MG[d.getMonth()]} ${d.getFullYear()}`:'';
export function DateRangePicker({label,start,end,onChange,size='md',style}){
const h={sm:'var(--control-h-sm)',md:'var(--control-h)',lg:'var(--control-h-lg)'}[size];
const [open,setOpen]=React.useState(false);
const [s,setS]=React.useState(start||null);
const [e,setE]=React.useState(end||null);
const [view,setView]=React.useState(()=>new Date((start||new Date()).getFullYear(),(start||new Date()).getMonth(),1));
const ref=React.useRef(null);
React.useEffect(()=>{const f=(ev)=>{if(ref.current&&!ref.current.contains(ev.target))setOpen(false);};document.addEventListener('mousedown',f);return()=>document.removeEventListener('mousedown',f);},[]);
const pick=(d)=>{
if(!s||(s&&e)){setS(d);setE(null);}
else{const a=d<s?d:s,b=d<s?s:d;setS(a);setE(b);onChange&&onChange(a,b);}
};
const preset=(a,b)=>{setS(a);setE(b);onChange&&onChange(a,b);setOpen(false);};
const now=new Date();
const y=view.getFullYear(),m=view.getMonth();
const first=(new Date(y,m,1).getDay()+6)%7;
const days=new Date(y,m+1,0).getDate();
const inR=(d)=>s&&e&&d>s&&d<e;
const same=(a,b)=>a&&b&&a.toDateString()===b.toDateString();
const cell={width:'32px',height:'28px',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'13px',borderRadius:'var(--radius-sm)',cursor:'pointer',fontVariantNumeric:'tabular-nums'};
return <div ref={ref} style={{display:'flex',flexDirection:'column',gap:'6px',fontFamily:'var(--font-ui)',fontSize:'var(--text-sm)',position:'relative',...style}}>
{label&&<span style={{fontWeight:500}}>{label}</span>}
<button type="button" onClick={()=>setOpen(o=>!o)} style={{display:'flex',alignItems:'center',gap:'8px',height:h,padding:'0 12px',background:'var(--surface-card)',border:`1px solid ${open?'var(--border-focus)':'var(--border-strong)'}`,boxShadow:open?'var(--focus-ring)':'none',borderRadius:'var(--radius-md)',font:'inherit',fontSize:'var(--text-base)',color:s?'var(--text-primary)':'var(--text-tertiary)',cursor:'pointer',fontVariantNumeric:'tabular-nums',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>
<Icon name="calendar" size={16} color="var(--text-tertiary)"/>
{s?`${fmt(s)}${e?' — '+fmt(e):' — …'}`:'Выберите период'}
</button>
{open&&<div style={{position:'absolute',top:'100%',left:0,marginTop:'4px',background:'var(--surface-card)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',border:'1px solid var(--glass-border)',borderRadius:'var(--radius-lg)',boxShadow:'var(--shadow-hover)',padding:'12px',zIndex:30,display:'flex',gap:'12px'}}>
<div style={{display:'flex',flexDirection:'column',gap:'4px',borderRight:'1px solid var(--border-default)',paddingRight:'12px'}}>
{[['Этот месяц',new Date(now.getFullYear(),now.getMonth(),1),new Date(now.getFullYear(),now.getMonth()+1,0)],['Прошлый месяц',new Date(now.getFullYear(),now.getMonth()-1,1),new Date(now.getFullYear(),now.getMonth(),0)],['Квартал',new Date(now.getFullYear(),Math.floor(now.getMonth()/3)*3,1),now],['Год',new Date(now.getFullYear(),0,1),now]].map(([l,a,b],i)=>
<div key={i} onClick={()=>preset(a,b)} style={{padding:'6px 10px',fontSize:'13px',borderRadius:'var(--radius-sm)',cursor:'pointer',whiteSpace:'nowrap'}}
onMouseEnter={ev=>ev.currentTarget.style.background='var(--surface-selected)'} onMouseLeave={ev=>ev.currentTarget.style.background='transparent'}>{l}</div>)}
</div>
<div>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'8px'}}>
<span onClick={()=>setView(new Date(y,m-1,1))} style={{cursor:'pointer',display:'flex',padding:'2px'}}><Icon name="chevron-left" size={16}/></span>
<span style={{fontSize:'13px',fontWeight:600}}>{M[m]} {y}</span>
<span onClick={()=>setView(new Date(y,m+1,1))} style={{cursor:'pointer',display:'flex',padding:'2px'}}><Icon name="chevron-right" size={16}/></span>
</div>
<div style={{display:'grid',gridTemplateColumns:'repeat(7,32px)'}}>
{['пн','вт','ср','чт','пт','сб','вс'].map(d=><span key={d} style={{...cell,cursor:'default',color:'var(--text-tertiary)',fontSize:'11px'}}>{d}</span>)}
{Array.from({length:first}).map((_,i)=><span key={'e'+i}></span>)}
{Array.from({length:days}).map((_,i)=>{const d=new Date(y,m,i+1);const isS=same(d,s),isE=same(d,e);
return <span key={i} onClick={()=>pick(d)} style={{...cell,background:isS||isE?'var(--interactive)':inR(d)?'var(--blue-50)':'transparent',color:isS||isE?'#fff':'var(--text-primary)',fontWeight:isS||isE?600:400}}
onMouseEnter={ev=>{if(!isS&&!isE&&!inR(d))ev.currentTarget.style.background='var(--gray-100)';}}
onMouseLeave={ev=>{if(!isS&&!isE)ev.currentTarget.style.background=inR(d)?'var(--blue-50)':'transparent';}}>{i+1}</span>;})}
</div>
</div>
</div>}
</div>;
}
