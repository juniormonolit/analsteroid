import React from 'react';
import {Icon} from '../core/Icon.jsx';
export function Select({label,options=[],value,onChange,placeholder='Выберите…',size='md',disabled,style}){
const h={sm:'var(--control-h-sm)',md:'var(--control-h)',lg:'var(--control-h-lg)'}[size];
const [open,setOpen]=React.useState(false);
const ref=React.useRef(null);
React.useEffect(()=>{
const f=(e)=>{if(ref.current&&!ref.current.contains(e.target))setOpen(false);};
document.addEventListener('mousedown',f);return()=>document.removeEventListener('mousedown',f);
},[]);
const sel=options.find(o=>(o.value??o)===value);
return <div ref={ref} style={{display:'flex',flexDirection:'column',gap:'6px',fontFamily:'var(--font-ui)',fontSize:'var(--text-sm)',position:'relative',...style}}>
{label&&<span style={{fontWeight:500}}>{label}</span>}
<button type="button" disabled={disabled} onClick={()=>setOpen(o=>!o)}
style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:'8px',height:h,padding:'0 10px 0 12px',background:disabled?'var(--surface-sunken)':'var(--surface-card)',border:`1px solid ${open?'var(--border-focus)':'var(--border-strong)'}`,boxShadow:open?'var(--focus-ring)':'none',borderRadius:'var(--radius-md)',font:'inherit',fontSize:'var(--text-base)',color:sel?'var(--text-primary)':'var(--text-tertiary)',cursor:disabled?'not-allowed':'pointer',transition:'border-color var(--transition-fast)'}}>
<span style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{sel?(sel.label??sel):placeholder}</span>
<Icon name="chevron-down" size={16} color="var(--text-tertiary)" style={{transform:open?'rotate(180deg)':'none',transition:'transform var(--transition-fast)'}}/>
</button>
{open&&<div style={{position:'absolute',top:'100%',left:0,right:0,marginTop:'4px',background:'var(--surface-card)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',border:'1px solid var(--glass-border)',borderRadius:'var(--radius-md)',boxShadow:'var(--shadow-hover)',padding:'4px',zIndex:30,maxHeight:'240px',overflowY:'auto'}}>
{options.map((o,i)=>{const v=o.value??o,l=o.label??o,act=v===value;
return <div key={i} onClick={()=>{onChange&&onChange(v);setOpen(false);}}
style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'7px 8px',borderRadius:'var(--radius-sm)',fontSize:'var(--text-base)',cursor:'pointer',background:act?'var(--surface-selected)':'transparent',color:act?'var(--text-brand)':'var(--text-primary)',fontWeight:act?500:400}}
onMouseEnter={e=>{if(!act)e.currentTarget.style.background='var(--gray-50)';}}
onMouseLeave={e=>{if(!act)e.currentTarget.style.background='transparent';}}>
{l}{act&&<Icon name="check" size={14}/>}
</div>;})}
</div>}
</div>;
}
