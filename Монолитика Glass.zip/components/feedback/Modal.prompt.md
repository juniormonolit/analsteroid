Модалка подтверждений и форм.

```jsx
<Modal open={open} title="Удалить отчёт?" onClose={close}
 footer={<><Button variant="secondary" onClick={close}>Отмена</Button><Button variant="danger">Удалить</Button></>}>
 Действие нельзя отменить.
</Modal>
```
