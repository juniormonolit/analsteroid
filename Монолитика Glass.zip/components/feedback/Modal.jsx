import React from 'react';
import {Icon} from '../core/Icon.jsx';
export function Modal({open,title,children,footer,onClose,width=440,style}){
if(!open)return null;
return <div onClick={onClose} style={{position:'fixed',inset:0,background:'rgba(2,18,38,.5)',backdropFilter:'blur(6px)',WebkitBackdropFilter:'blur(6px)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:100,fontFamily:'var(--font-ui)'}}>
<div onClick={e=>e.stopPropagation()} style={{width,maxWidth:'calc(100vw - 48px)',maxHeight:'calc(100vh - 48px)',display:'flex',flexDirection:'column',background:'var(--surface-card)',backdropFilter:'var(--glass-blur)',WebkitBackdropFilter:'var(--glass-blur)',border:'1px solid var(--glass-border)',borderRadius:'var(--radius-xl)',boxShadow:'var(--shadow-modal)',...style}}>
<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:'12px',padding:'16px 20px',borderBottom:'1px solid var(--border-default)'}}>
<span style={{fontSize:'var(--text-md)',fontWeight:600,lineHeight:'24px'}}>{title}</span>
<span onClick={onClose} style={{cursor:'pointer',color:'var(--text-tertiary)',width:'28px',height:'28px',flex:'none',display:'flex',alignItems:'center',justifyContent:'center',borderRadius:'var(--radius-sm)',transition:'background var(--transition-fast)'}}
onMouseEnter={e=>e.currentTarget.style.background='var(--gray-100)'} onMouseLeave={e=>e.currentTarget.style.background='transparent'}><Icon name="x" size={18}/></span>
</div>
<div style={{padding:'20px',overflowY:'auto',fontSize:'var(--text-base)',color:'var(--text-primary)'}}>{children}</div>
{footer&&<div style={{display:'flex',justifyContent:'flex-end',gap:'10px',padding:'14px 20px',borderTop:'1px solid var(--border-default)'}}>{footer}</div>}
</div>
</div>;
}
