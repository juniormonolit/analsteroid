/** Модальное окно: затемнение, карточка 12px с shadow-modal, шапка с крестиком, футер с действиями. */
export interface ModalProps {
  open: boolean;
  title: string;
  onClose?: () => void;
  /** Кнопки: secondary слева, primary справа */
  footer?: React.ReactNode;
  width?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
