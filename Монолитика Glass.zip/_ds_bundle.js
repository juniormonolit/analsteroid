/* @ds-bundle: {"format":4,"namespace":"DesignSystem_311945","components":[{"name":"BarChart","sourcePath":"components/charts/BarChart.jsx"},{"name":"DonutChart","sourcePath":"components/charts/DonutChart.jsx"},{"name":"Gauge","sourcePath":"components/charts/Gauge.jsx"},{"name":"LineChart","sourcePath":"components/charts/LineChart.jsx"},{"name":"BrandLogo","sourcePath":"components/core/BrandLogo.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"ICON_NAMES","sourcePath":"components/core/Icon.jsx"},{"name":"FormatNum","sourcePath":"components/core/Num.jsx"},{"name":"Num","sourcePath":"components/core/Num.jsx"},{"name":"Avatar","sourcePath":"components/data/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data/Badge.jsx"},{"name":"EmptyState","sourcePath":"components/data/EmptyState.jsx"},{"name":"KPICard","sourcePath":"components/data/KPICard.jsx"},{"name":"ProgressBar","sourcePath":"components/data/ProgressBar.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"TrendBadge","sourcePath":"components/data/TrendBadge.jsx"},{"name":"Modal","sourcePath":"components/feedback/Modal.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"DateRangePicker","sourcePath":"components/forms/DateRangePicker.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"MLTAmount","sourcePath":"components/gamification/MLTAmount.jsx"},{"name":"MLTCoin","sourcePath":"components/gamification/MLTCoin.jsx"},{"name":"QuestCard","sourcePath":"components/gamification/QuestCard.jsx"},{"name":"RewardCard","sourcePath":"components/gamification/RewardCard.jsx"},{"name":"FilterChips","sourcePath":"components/navigation/FilterChips.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"},{"name":"Sidebar","sourcePath":"components/navigation/Sidebar.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/charts/BarChart.jsx":"e78c4fcd52c0","components/charts/DonutChart.jsx":"a1986be47ced","components/charts/Gauge.jsx":"5dca620544ec","components/charts/LineChart.jsx":"b91c13a4a681","components/core/BrandLogo.jsx":"385531d64d3d","components/core/Icon.jsx":"b6b9c28b7f9f","components/core/Num.jsx":"295cfe4ec127","components/data/Avatar.jsx":"7c2a8e343b80","components/data/Badge.jsx":"6ce96bdb78e7","components/data/EmptyState.jsx":"13e5158cd40a","components/data/KPICard.jsx":"10e546456754","components/data/ProgressBar.jsx":"ba34d5825cf3","components/data/Table.jsx":"c4a5eb60b2c7","components/data/TrendBadge.jsx":"fd2295876d2e","components/feedback/Modal.jsx":"1f5752c78788","components/feedback/Toast.jsx":"c80a6ba9e03f","components/feedback/Tooltip.jsx":"6b45335bf655","components/forms/Button.jsx":"5c25b0dcfaf3","components/forms/DateRangePicker.jsx":"a675366ec6d8","components/forms/Input.jsx":"ab580b360678","components/forms/Select.jsx":"e988eb6bc5ff","components/gamification/MLTAmount.jsx":"68113f9ec68b","components/gamification/MLTCoin.jsx":"27b6f3b59c01","components/gamification/QuestCard.jsx":"779a3c930998","components/gamification/RewardCard.jsx":"4071d9933adf","components/navigation/FilterChips.jsx":"f2cb5f89f1e5","components/navigation/Pagination.jsx":"35195d45ebf4","components/navigation/Sidebar.jsx":"9da9c5092d66","components/navigation/Tabs.jsx":"ee76024f0eae","ui_kits/monolitika/Dashboard.jsx":"5a816e803fa0","ui_kits/monolitika/Gamification.jsx":"b5eff685214b","ui_kits/monolitika/Manager.jsx":"b6a1b32f5176","ui_kits/monolitika/Report.jsx":"f2a9e71c8364","ui_kits/monolitika/shared.jsx":"eac257e0328d"},"inlinedExternals":[],"unexposedExports":[{"name":"mixHex","sourcePath":"components/data/Table.jsx"}]} */

(() => {

const __ds_ns = (window.DesignSystem_311945 = window.DesignSystem_311945 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/charts/BarChart.jsx
try { (() => {
function BarChart({
  values = [],
  labels = [],
  height = 220,
  activeIndex,
  color = 'var(--interactive)',
  mutedColor = 'var(--gray-100)',
  valueFormat,
  onBarClick,
  style
}) {
  const W = 600,
    H = height,
    padL = valueFormat ? 44 : 8,
    padB = labels.length ? 22 : 8,
    padT = 10,
    padR = 8;
  const max = Math.max(...values, 1);
  const iw = W - padL - padR,
    ih = H - padT - padB;
  const bw = Math.min(48, iw / values.length * 0.62);
  const ticks = [0, .5, 1];
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${W} ${H}`,
    style: {
      width: '100%',
      height: 'auto',
      display: 'block',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, valueFormat && ticks.map((t, i) => {
    const y = padT + ih - t * ih;
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("line", {
      x1: padL,
      x2: W - padR,
      y1: y,
      y2: y,
      stroke: "var(--gray-200)",
      strokeDasharray: "3 4",
      strokeWidth: "1"
    }), /*#__PURE__*/React.createElement("text", {
      x: padL - 8,
      y: y + 3.5,
      textAnchor: "end",
      fontSize: "10",
      fill: "var(--gray-400)",
      style: {
        fontVariantNumeric: 'tabular-nums'
      }
    }, valueFormat(t * max)));
  }), values.map((v, i) => {
    const x = padL + i * (iw / values.length) + (iw / values.length - bw) / 2;
    const bh = v / max * ih;
    const act = activeIndex == null || activeIndex === i;
    return /*#__PURE__*/React.createElement("g", {
      key: i,
      onClick: onBarClick ? () => onBarClick(i) : undefined,
      style: {
        cursor: onBarClick ? 'pointer' : 'default'
      }
    }, /*#__PURE__*/React.createElement("rect", {
      x: x,
      y: padT + ih - bh,
      width: bw,
      height: bh,
      rx: "6",
      fill: act ? color : mutedColor
    }), labels[i] != null && /*#__PURE__*/React.createElement("text", {
      x: x + bw / 2,
      y: H - 6,
      textAnchor: "middle",
      fontSize: "10",
      fill: activeIndex === i ? 'var(--gray-700)' : 'var(--gray-400)',
      fontWeight: activeIndex === i ? 600 : 400
    }, labels[i]));
  }));
}
Object.assign(__ds_scope, { BarChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/BarChart.jsx", error: String((e && e.message) || e) }); }

// components/charts/DonutChart.jsx
try { (() => {
const DEF = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)', 'var(--chart-5)', 'var(--chart-6)'];
function DonutChart({
  segments = [],
  size = 180,
  thickness = 22,
  centerValue,
  centerLabel,
  showLegend = true,
  style
}) {
  const total = segments.reduce((a, s) => a + s.value, 0) || 1;
  const r = (size - thickness) / 2,
    c = size / 2,
    circ = 2 * Math.PI * r;
  let acc = 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '20px',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: size,
      height: size,
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    style: {
      transform: 'rotate(-90deg)'
    }
  }, segments.map((s, i) => {
    const frac = s.value / total,
      off = acc;
    acc += frac;
    return /*#__PURE__*/React.createElement("circle", {
      key: i,
      cx: c,
      cy: c,
      r: r,
      fill: "none",
      stroke: s.color || DEF[i % DEF.length],
      strokeWidth: thickness,
      strokeDasharray: `${Math.max(frac * circ - 2, 0.01)} ${circ}`,
      strokeDashoffset: -off * circ,
      strokeLinecap: "butt"
    });
  })), (centerValue || centerLabel) && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: size * 0.16,
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1.1
    }
  }, centerValue), centerLabel && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-secondary)'
    }
  }, centerLabel))), showLegend && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px'
    }
  }, segments.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      fontSize: 'var(--text-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: '8px',
      height: '8px',
      borderRadius: '50%',
      background: s.color || DEF[i % DEF.length],
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)'
    }
  }, s.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums',
      marginLeft: 'auto',
      paddingLeft: '12px'
    }
  }, Math.round(s.value / total * 100), "%")))));
}
Object.assign(__ds_scope, { DonutChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/DonutChart.jsx", error: String((e && e.message) || e) }); }

// components/charts/Gauge.jsx
try { (() => {
function Gauge({
  percent = 0,
  label,
  size = 220,
  segments = 24,
  style
}) {
  const W = size,
    H = size * 0.62,
    cx = W / 2,
    cy = H * 0.94,
    R = W / 2 - 10,
    inner = R * 0.62;
  const n = segments,
    fill = Math.round(percent / 100 * n);
  const bars = Array.from({
    length: n
  }, (_, i) => {
    const a = Math.PI - (i + 0.5) * (Math.PI / n);
    const x1 = cx + Math.cos(a) * inner,
      y1 = cy - Math.sin(a) * inner;
    const x2 = cx + Math.cos(a) * R,
      y2 = cy - Math.sin(a) * R;
    const on = i < fill;
    const t = n <= 1 ? 0 : i / (n - 1);
    const col = on ? t < 0.5 ? 'var(--blue-600)' : 'var(--blue-500)' : 'var(--blue-100)';
    return /*#__PURE__*/React.createElement("line", {
      key: i,
      x1: x1,
      y1: y1,
      x2: x2,
      y2: y2,
      stroke: col,
      strokeWidth: Math.max(5, size * 0.038),
      strokeLinecap: "round"
    });
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      width: W,
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: W,
    height: H,
    style: {
      display: 'block'
    }
  }, bars), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: size * 0.13,
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1
    }
  }, percent.toLocaleString('ru-RU'), "%"), label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-secondary)',
      marginTop: '3px'
    }
  }, label)));
}
Object.assign(__ds_scope, { Gauge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/Gauge.jsx", error: String((e && e.message) || e) }); }

// components/core/BrandLogo.jsx
try { (() => {
// Знак «Монолитика» — «М-барчарт» из кодовой базы (components/ui/BrandLogo.tsx, 1:1):
// три pill-столбика в цветах стадий сделок: продажи (синий) / отказы (красный) / отгрузки (зелёный).
function BrandLogo({
  size = 20,
  withWordmark = false,
  style
}) {
  const h = size,
    w = size * 24 / 17;
  const svg = /*#__PURE__*/React.createElement("svg", {
    width: w,
    height: h,
    viewBox: "0 0 24 17",
    fill: "none",
    "aria-hidden": "true",
    style: withWordmark ? undefined : style
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "0",
    width: "6",
    height: "17",
    rx: "3",
    fill: "var(--entity-sales,#3b82f6)"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9",
    y: "7",
    width: "6",
    height: "10",
    rx: "3",
    fill: "var(--entity-refusals,#ef4444)"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "18",
    y: "0",
    width: "6",
    height: "17",
    rx: "3",
    fill: "var(--entity-shipments,#22c55e)"
  }));
  if (!withWordmark) return svg;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: Math.round(size * 0.45),
      ...style
    }
  }, svg, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: size * 0.9,
      fontWeight: 700,
      color: 'var(--text-primary)',
      letterSpacing: '-0.02em',
      lineHeight: 1
    }
  }, "\u041C\u043E\u043D\u043E\u043B\u0438\u0442\u0438\u043A\u0430"));
}
Object.assign(__ds_scope, { BrandLogo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/BrandLogo.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
const I = {
  home: [['path', {
    d: 'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'
  }], ['polyline', {
    points: '9 22 9 12 15 12 15 22'
  }]],
  dashboard: [['rect', {
    x: 3,
    y: 3,
    width: 7,
    height: 9,
    rx: 1
  }], ['rect', {
    x: 14,
    y: 3,
    width: 7,
    height: 5,
    rx: 1
  }], ['rect', {
    x: 14,
    y: 12,
    width: 7,
    height: 9,
    rx: 1
  }], ['rect', {
    x: 3,
    y: 16,
    width: 7,
    height: 5,
    rx: 1
  }]],
  chart: [['path', {
    d: 'M3 3v18h18'
  }], ['path', {
    d: 'M18 17V9'
  }], ['path', {
    d: 'M13 17V5'
  }], ['path', {
    d: 'M8 17v-3'
  }]],
  users: [['path', {
    d: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2'
  }], ['circle', {
    cx: 9,
    cy: 7,
    r: 4
  }], ['path', {
    d: 'M22 21v-2a4 4 0 0 0-3-3.87'
  }], ['path', {
    d: 'M16 3.13a4 4 0 0 1 0 7.75'
  }]],
  settings: [['path', {
    d: 'M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z'
  }], ['circle', {
    cx: 12,
    cy: 12,
    r: 3
  }]],
  bell: [['path', {
    d: 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9'
  }], ['path', {
    d: 'M10.3 21a1.94 1.94 0 0 0 3.4 0'
  }]],
  search: [['circle', {
    cx: 11,
    cy: 11,
    r: 8
  }], ['path', {
    d: 'm21 21-4.3-4.3'
  }]],
  'chevron-down': [['path', {
    d: 'm6 9 6 6 6-6'
  }]],
  'chevron-up': [['path', {
    d: 'm18 15-6-6-6 6'
  }]],
  'chevron-right': [['path', {
    d: 'm9 18 6-6-6-6'
  }]],
  'chevron-left': [['path', {
    d: 'm15 18-6-6 6-6'
  }]],
  calendar: [['rect', {
    x: 3,
    y: 4,
    width: 18,
    height: 18,
    rx: 2
  }], ['path', {
    d: 'M16 2v4'
  }], ['path', {
    d: 'M8 2v4'
  }], ['path', {
    d: 'M3 10h18'
  }]],
  x: [['path', {
    d: 'M18 6 6 18'
  }], ['path', {
    d: 'm6 6 12 12'
  }]],
  check: [['path', {
    d: 'M20 6 9 17l-5-5'
  }]],
  plus: [['path', {
    d: 'M5 12h14'
  }], ['path', {
    d: 'M12 5v14'
  }]],
  filter: [['path', {
    d: 'M22 3H2l8 9.46V19l4 2v-8.54z'
  }]],
  download: [['path', {
    d: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'
  }], ['polyline', {
    points: '7 10 12 15 17 10'
  }], ['path', {
    d: 'M12 15V3'
  }]],
  wallet: [['path', {
    d: 'M21 12V7H5a2 2 0 0 1 0-4h14v4'
  }], ['path', {
    d: 'M3 5v14a2 2 0 0 0 2 2h16v-5'
  }], ['path', {
    d: 'M18 12a2 2 0 0 0 0 4h4v-4z'
  }]],
  gift: [['rect', {
    x: 3,
    y: 8,
    width: 18,
    height: 4,
    rx: 1
  }], ['path', {
    d: 'M12 8v13'
  }], ['path', {
    d: 'M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7'
  }], ['path', {
    d: 'M7.5 8a2.5 2.5 0 0 1 0-5A4.8 4.8 0 0 1 12 8a4.8 4.8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5'
  }]],
  trophy: [['path', {
    d: 'M6 9H4.5a2.5 2.5 0 0 1 0-5H6'
  }], ['path', {
    d: 'M18 9h1.5a2.5 2.5 0 0 0 0-5H18'
  }], ['path', {
    d: 'M4 22h16'
  }], ['path', {
    d: 'M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22'
  }], ['path', {
    d: 'M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22'
  }], ['path', {
    d: 'M18 2H6v7a6 6 0 0 0 12 0V2Z'
  }]],
  bag: [['path', {
    d: 'M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z'
  }], ['path', {
    d: 'M3 6h18'
  }], ['path', {
    d: 'M16 10a4 4 0 0 1-8 0'
  }]],
  package: [['path', {
    d: 'M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z'
  }], ['path', {
    d: 'm3.3 7 8.7 5 8.7-5'
  }], ['path', {
    d: 'M12 22V12'
  }]],
  file: [['path', {
    d: 'M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z'
  }], ['path', {
    d: 'M14 2v4a2 2 0 0 0 2 2h4'
  }], ['path', {
    d: 'M16 13H8'
  }], ['path', {
    d: 'M16 17H8'
  }]],
  alert: [['circle', {
    cx: 12,
    cy: 12,
    r: 10
  }], ['path', {
    d: 'M12 8v4'
  }], ['path', {
    d: 'M12 16h.01'
  }]],
  info: [['circle', {
    cx: 12,
    cy: 12,
    r: 10
  }], ['path', {
    d: 'M12 16v-4'
  }], ['path', {
    d: 'M12 8h.01'
  }]],
  'trend-up': [['polyline', {
    points: '22 7 13.5 15.5 8.5 10.5 2 17'
  }], ['polyline', {
    points: '16 7 22 7 22 13'
  }]],
  'trend-down': [['polyline', {
    points: '22 17 13.5 8.5 8.5 13.5 2 7'
  }], ['polyline', {
    points: '16 17 22 17 22 11'
  }]],
  more: [['circle', {
    cx: 12,
    cy: 12,
    r: 1
  }], ['circle', {
    cx: 19,
    cy: 12,
    r: 1
  }], ['circle', {
    cx: 5,
    cy: 12,
    r: 1
  }]],
  inbox: [['polyline', {
    points: '22 12 16 12 14 15 10 15 8 12 2 12'
  }], ['path', {
    d: 'M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z'
  }]],
  'arrow-up-right': [['path', {
    d: 'M7 7h10v10'
  }], ['path', {
    d: 'M7 17 17 7'
  }]],
  sparkles: [['path', {
    d: 'M12 3l1.9 5.8a2 2 0 0 0 1.3 1.3L21 12l-5.8 1.9a2 2 0 0 0-1.3 1.3L12 21l-1.9-5.8a2 2 0 0 0-1.3-1.3L3 12l5.8-1.9a2 2 0 0 0 1.3-1.3z'
  }]],
  logout: [['path', {
    d: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'
  }], ['polyline', {
    points: '16 17 21 12 16 7'
  }], ['path', {
    d: 'M21 12H9'
  }]],
  sun: [['circle', {
    cx: 12,
    cy: 12,
    r: 4
  }], ['path', {
    d: 'M12 2v2'
  }], ['path', {
    d: 'M12 20v2'
  }], ['path', {
    d: 'm4.93 4.93 1.41 1.41'
  }], ['path', {
    d: 'm17.66 17.66 1.41 1.41'
  }], ['path', {
    d: 'M2 12h2'
  }], ['path', {
    d: 'M20 12h2'
  }], ['path', {
    d: 'm6.34 17.66-1.41 1.41'
  }], ['path', {
    d: 'm19.07 4.93-1.41 1.41'
  }]],
  moon: [['path', {
    d: 'M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z'
  }]]
};
function Icon({
  name,
  size = 16,
  color = 'currentColor',
  strokeWidth = 2,
  style
}) {
  const def = I[name];
  if (!def) return null;
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flex: 'none',
      ...style
    },
    "aria-hidden": "true"
  }, def.map(([t, a], i) => React.createElement(t, {
    key: i,
    ...a
  })));
}
const ICON_NAMES = Object.keys(I);
Object.assign(__ds_scope, { Icon, ICON_NAMES });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Num.jsx
try { (() => {
const trim = (x, d) => x.toLocaleString('ru-RU', {
  maximumFractionDigits: d
});
function FormatNum(v, {
  unit = '',
  compact = true,
  digits = 1
} = {}) {
  if (v == null || isNaN(v)) return '—';
  const neg = v < 0,
    a = Math.abs(v);
  let s;
  if (compact && a >= 1e9) s = trim(a / 1e9, digits) + ' млрд';else if (compact && a >= 1e6) s = trim(a / 1e6, digits) + ' млн';else if (compact && a >= 1e4) s = trim(a / 1e3, digits) + ' тыс';else s = trim(a, a < 10 ? digits : 0);
  return (neg ? '−' : '') + s + (unit ? ' ' + unit : '');
}
function Num({
  value,
  unit = '',
  money = false,
  compact = true,
  digits = 1,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "tnum",
    style: {
      fontVariantNumeric: 'tabular-nums',
      ...style
    }
  }, FormatNum(value, {
    unit: money ? '₽' : unit,
    compact,
    digits
  }));
}
Object.assign(__ds_scope, { FormatNum, Num });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Num.jsx", error: String((e && e.message) || e) }); }

// components/charts/LineChart.jsx
try { (() => {
const fmt = v => __ds_scope.FormatNum(v);
function LineChart({
  values = [],
  labels = [],
  height = 220,
  area = true,
  smooth = true,
  showDots = false,
  color = 'var(--interactive)',
  valueFormat = fmt,
  style
}) {
  const W = 600,
    H = height,
    padL = 44,
    padB = labels.length ? 22 : 8,
    padT = 10,
    padR = 8;
  const max = Math.max(...values, 1),
    min = 0;
  const iw = W - padL - padR,
    ih = H - padT - padB;
  const pt = (v, i) => [padL + (values.length < 2 ? iw / 2 : i * (iw / (values.length - 1))), padT + ih - (v - min) / (max - min) * ih];
  const pts = values.map(pt);
  let d = '';
  if (smooth && pts.length > 2) {
    d = `M ${pts[0][0]} ${pts[0][1]}`;
    for (let i = 1; i < pts.length; i++) {
      const [x0, y0] = pts[i - 1],
        [x1, y1] = pts[i];
      const cx = (x0 + x1) / 2;
      d += ` C ${cx} ${y0}, ${cx} ${y1}, ${x1} ${y1}`;
    }
  } else d = 'M ' + pts.map(p => p.join(' ')).join(' L ');
  const ticks = [0, .25, .5, .75, 1];
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${W} ${H}`,
    style: {
      width: '100%',
      height: 'auto',
      display: 'block',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, ticks.map((t, i) => {
    const y = padT + ih - t * ih;
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("line", {
      x1: padL,
      x2: W - padR,
      y1: y,
      y2: y,
      stroke: "var(--gray-200)",
      strokeDasharray: "3 4",
      strokeWidth: "1"
    }), /*#__PURE__*/React.createElement("text", {
      x: padL - 8,
      y: y + 3.5,
      textAnchor: "end",
      fontSize: "10",
      fill: "var(--gray-400)",
      style: {
        fontVariantNumeric: 'tabular-nums'
      }
    }, valueFormat(min + t * (max - min))));
  }), area && /*#__PURE__*/React.createElement("path", {
    d: d + ` L ${pts[pts.length - 1][0]} ${padT + ih} L ${pts[0][0]} ${padT + ih} Z`,
    fill: color,
    opacity: ".1"
  }), /*#__PURE__*/React.createElement("path", {
    d: d,
    fill: "none",
    stroke: color,
    strokeWidth: "2",
    strokeLinecap: "round"
  }), showDots && pts.map((p, i) => /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: p[0],
    cy: p[1],
    r: "3",
    fill: "#fff",
    stroke: color,
    strokeWidth: "2"
  })), labels.map((l, i) => {
    const x = pt(0, i)[0];
    return /*#__PURE__*/React.createElement("text", {
      key: i,
      x: x,
      y: H - 6,
      textAnchor: "middle",
      fontSize: "10",
      fill: "var(--gray-400)"
    }, l);
  }));
}
Object.assign(__ds_scope, { LineChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/LineChart.jsx", error: String((e && e.message) || e) }); }

// components/data/Avatar.jsx
try { (() => {
const COLORS = ['var(--blue-500)', 'var(--blue-700)', 'var(--info)', 'var(--gray-500)', 'var(--blue-400)'];
function Avatar({
  name = '',
  src,
  size = 32,
  style
}) {
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('');
  const hue = name.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      flex: 'none',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      background: src ? 'var(--gray-100)' : COLORS[hue % COLORS.length],
      color: '#fff',
      fontSize: size * 0.38,
      fontWeight: 600,
      fontFamily: 'var(--font-ui)',
      letterSpacing: '.02em',
      ...style
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials || '?');
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data/Badge.jsx
try { (() => {
function Badge({
  status = 'info',
  children,
  dot = false,
  style
}) {
  const map = {
    success: {
      bg: 'var(--success-bg)',
      fg: 'var(--success-text)',
      d: 'var(--success)'
    },
    danger: {
      bg: 'var(--danger-bg)',
      fg: 'var(--danger-text)',
      d: 'var(--danger)'
    },
    warning: {
      bg: 'var(--warning-bg)',
      fg: 'var(--warning-text)',
      d: 'var(--warning)'
    },
    info: {
      bg: 'var(--info-bg)',
      fg: 'var(--info-text)',
      d: 'var(--info)'
    },
    neutral: {
      bg: 'var(--gray-100)',
      fg: 'var(--gray-600)',
      d: 'var(--gray-400)'
    },
    brand: {
      bg: 'var(--blue-50)',
      fg: 'var(--blue-700)',
      d: 'var(--blue-500)'
    }
  };
  const c = map[status] || map.info;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '2px 9px',
      borderRadius: 'var(--radius-full)',
      background: c.bg,
      color: c.fg,
      fontSize: 'var(--text-xs)',
      fontWeight: 500,
      fontFamily: 'var(--font-ui)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '6px',
      height: '6px',
      borderRadius: '50%',
      background: c.d
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data/EmptyState.jsx
try { (() => {
function EmptyState({
  icon = 'inbox',
  title = 'Нет данных',
  description,
  action,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '8px',
      padding: 'var(--sp-10) var(--sp-6)',
      textAlign: 'center',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: '48px',
      height: '48px',
      borderRadius: '50%',
      background: 'var(--gray-100)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 22
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-md)',
      fontWeight: 600,
      color: 'var(--text-primary)'
    }
  }, title), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      maxWidth: '360px'
    }
  }, description), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '8px'
    }
  }, action));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/data/KPICard.jsx
try { (() => {
function KPICard({
  label,
  value,
  delta,
  deltaLabel,
  icon,
  accent = false,
  footer,
  style
}) {
  const up = delta != null && delta >= 0;
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      background: accent ? 'var(--grad-brand)' : 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      color: accent ? '#fff' : 'var(--text-primary)',
      border: `1px solid ${accent ? 'rgba(255,255,255,.3)' : 'var(--glass-border)'}`,
      borderRadius: 'var(--radius-xl)',
      padding: 'var(--sp-5)',
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-ui)',
      boxShadow: hov ? 'var(--shadow-hover)' : 'var(--shadow-card)',
      transition: 'box-shadow var(--transition-normal)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 500,
      color: accent ? 'rgba(255,255,255,.85)' : 'var(--text-secondary)'
    }
  }, label), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '34px',
      height: '34px',
      borderRadius: '999px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: accent ? 'rgba(255,255,255,.18)' : 'var(--blue-50)',
      color: accent ? '#fff' : 'var(--brand)'
    }
  }, icon)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '10px',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "tnum",
    style: {
      fontSize: 'var(--kpi-size)',
      fontWeight: 'var(--kpi-weight)',
      lineHeight: 1.1,
      fontVariantNumeric: 'tabular-nums',
      whiteSpace: 'nowrap'
    }
  }, value), delta != null && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '3px',
      fontSize: 'var(--text-xs)',
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums',
      padding: '2px 7px',
      borderRadius: '999px',
      background: accent ? 'rgba(255,255,255,.18)' : up ? 'var(--success-bg)' : 'var(--danger-bg)',
      color: accent ? '#fff' : up ? 'var(--success-text)' : 'var(--danger-text)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: up ? 'trend-up' : 'trend-down',
    size: 11
  }), up ? '+' : '−', Math.abs(delta).toLocaleString('ru-RU'), "%")), (footer || deltaLabel) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: accent ? 'rgba(255,255,255,.75)' : 'var(--text-tertiary)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, footer || deltaLabel));
}
Object.assign(__ds_scope, { KPICard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/KPICard.jsx", error: String((e && e.message) || e) }); }

// components/data/ProgressBar.jsx
try { (() => {
function ProgressBar({
  value = 0,
  max = 100,
  label,
  caption,
  color = 'var(--interactive)',
  track = 'var(--gray-100)',
  height = 8,
  showValue = false,
  style
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, (label || showValue) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      fontSize: 'var(--text-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)',
      fontWeight: 500
    }
  }, label), showValue && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums'
    }
  }, value.toLocaleString('ru-RU'), " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      fontWeight: 400
    }
  }, "\u0438\u0437 ", max.toLocaleString('ru-RU')))), /*#__PURE__*/React.createElement("div", {
    style: {
      height,
      background: track,
      borderRadius: '999px',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: pct + '%',
      height: '100%',
      background: color,
      borderRadius: '999px',
      transition: 'width var(--transition-normal)'
    }
  })), caption && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, caption));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
// Паттерны перенесены из ReportTable.tsx кодовой базы: тепловая карта по СРЕДНЕМУ РАНГУ
// значения (не по min/max), пастельные опорные цвета GS (red→yellow→green, tint 0.8),
// ин-селл бары, ховер всей строки + акцентная полоска слева у первой ячейки.
function mixHex(hex, toHex, t) {
  const a = parseInt(hex.slice(1), 16),
    b = parseInt(toHex.slice(1), 16);
  const ar = a >> 16 & 255,
    ag = a >> 8 & 255,
    ab = a & 255,
    br = b >> 16 & 255,
    bg = b >> 8 & 255,
    bb = b & 255;
  return '#' + [Math.round(ar + (br - ar) * t), Math.round(ag + (bg - ag) * t), Math.round(ab + (bb - ab) * t)].map(v => v.toString(16).padStart(2, '0')).join('');
}
const HEAT_RED = '#ffcccc',
  HEAT_YELLOW = '#ffffcc',
  HEAT_GREEN = '#ccffcc';
const heatMix = t => t <= 0.5 ? mixHex(HEAT_RED, HEAT_YELLOW, t / 0.5) : mixHex(HEAT_YELLOW, HEAT_GREEN, (t - 0.5) / 0.5);
// Тёмная тема: доля подмеса меньше (как --color-highlight-pct 68%→32% в макете) —
// пастель подмешивается к тёмной карточке, текст остаётся светлым
const isDark = () => typeof document !== 'undefined' && document.documentElement.getAttribute('data-theme') === 'dark';
// Подписка на смену data-theme — heat-цвета пересчитываются синхронно с темой,
// а не «на рендер позади» (тема ставится в useEffect хоста после рендера)
function useThemeDark() {
  const [dark, setDark] = React.useState(isDark);
  React.useEffect(() => {
    const mo = new MutationObserver(() => setDark(isDark()));
    mo.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['data-theme']
    });
    setDark(isDark());
    return () => mo.disconnect();
  }, []);
  return dark;
}
const heatBg = (t, dark) => dark ? mixHex('#16233A', heatMix(t), 0.35) : heatMix(t);
const heatFg = dark => dark ? '#e6e8ec' : '#1A202C';
const toNum = v => {
  if (typeof v === 'number') return v;
  if (v == null) return null;
  const n = parseFloat(String(v).replace(/[\s\u00A0\u202F]/g, '').replace(',', '.').replace(/[^0-9.\-]/g, ''));
  return isNaN(n) ? null : n;
};
// Средний ранг значения в отсортированном массиве колонки (0..1) — как heatRankT в коде
function rankT(vals, value) {
  if (value == null || vals.length === 0) return undefined;
  if (vals.length === 1 || vals[0] === vals[vals.length - 1]) return 0.5;
  let lo = 0;
  while (lo < vals.length && vals[lo] < value) lo++;
  let hi = lo;
  while (hi < vals.length && vals[hi] <= value) hi++;
  return (lo + (hi - lo - 1) / 2) / (vals.length - 1);
}
function Table({
  columns = [],
  rows = [],
  totals,
  zebra = true,
  maxHeight,
  onRowClick,
  style
}) {
  const [hoverIdx, setHoverIdx] = React.useState(null);
  const dark = useThemeDark();
  // Предрасчёт рангов для heatmap/bar-колонок
  const stats = React.useMemo(() => {
    const s = {};
    for (const c of columns) {
      if (!c.heatmap && !c.bar) continue;
      s[c.key] = rows.map(r => toNum(r[c.key])).filter(v => v != null).sort((a, b) => a - b);
    }
    return s;
  }, [columns, rows]);
  const cell = c => ({
    padding: '0 var(--table-cell-px)',
    textAlign: c.align || 'left',
    fontVariantNumeric: 'tabular-nums',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    maxWidth: c.width,
    width: c.width
  });
  const cellDecor = (c, r) => {
    const out = {};
    if (c.accent) {
      out.fontWeight = 600;
      out.background = 'var(--surface-selected)';
    }
    if (c.heatmap) {
      let t = rankT(stats[c.key] || [], toNum(r[c.key]));
      if (t !== undefined) {
        if (c.invert) t = 1 - t;
        out.background = heatBg(t, dark);
        out.color = heatFg(dark);
        out._heat = true;
      }
    }
    return out;
  };
  const barSpan = (c, r, content) => {
    if (!c.bar) return content;
    const vals = stats[c.key] || [];
    const v = toNum(r[c.key]),
      max = vals.length ? vals[vals.length - 1] : null;
    const w = v != null && max ? Math.max(2, Math.round(v / max * 100)) : 0;
    return /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative',
        display: 'inline-block',
        minWidth: '70%'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        inset: '-3px 0',
        [c.align === 'right' ? 'right' : 'left']: '-4px',
        width: w + '%',
        background: 'var(--blue-100)',
        borderRadius: '4px',
        opacity: .55
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative'
      }
    }, content));
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      fontFamily: 'var(--font-ui)',
      background: 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight,
      overflowY: maxHeight ? 'auto' : 'visible'
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 'var(--text-sm)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map((c, i) => /*#__PURE__*/React.createElement("th", {
    key: i,
    style: {
      ...cell(c),
      position: 'sticky',
      top: 0,
      zIndex: 2,
      height: '36px',
      background: 'var(--gray-50)',
      borderBottom: '1px solid var(--border-default)',
      boxShadow: '0 1px 0 0 var(--gray-50)',
      fontSize: 'var(--text-xs)',
      fontWeight: 600,
      color: c.accent ? 'var(--text-brand)' : 'var(--text-secondary)'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, ri) => {
    const hov = hoverIdx === ri;
    const base = zebra && ri % 2 ? 'var(--gray-50)' : 'var(--surface-card)';
    return /*#__PURE__*/React.createElement("tr", {
      key: ri,
      onClick: onRowClick ? () => onRowClick(r, ri) : undefined,
      onMouseEnter: () => setHoverIdx(ri),
      onMouseLeave: () => setHoverIdx(null),
      style: {
        height: 'var(--table-row-h)',
        cursor: onRowClick ? 'pointer' : 'default',
        borderBottom: zebra ? 'none' : '1px solid var(--gray-100)'
      }
    }, columns.map((c, ci) => {
      const decor = cellDecor(c, r);
      return /*#__PURE__*/React.createElement("td", {
        key: ci,
        style: {
          ...cell(c),
          color: 'var(--text-primary)',
          ...decor,
          ...(hov ? {
            background: 'var(--blue-50)',
            color: decor._heat ? heatFg(dark) : 'var(--text-primary)',
            ...(decor._heat ? {
              background: decor.background
            } : {})
          } : decor.background ? {} : {
            background: base
          }),
          ...(hov && ci === 0 ? {
            boxShadow: 'inset 3px 0 0 0 var(--interactive)'
          } : {})
        }
      }, barSpan(c, r, c.render ? c.render(r[c.key], r, ri) : r[c.key]));
    }));
  })), totals && /*#__PURE__*/React.createElement("tfoot", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      height: '36px',
      position: 'sticky',
      bottom: 0
    }
  }, columns.map((c, i) => /*#__PURE__*/React.createElement("td", {
    key: i,
    style: {
      ...cell(c),
      background: 'var(--blue-100)',
      borderTop: '1px solid var(--blue-200)',
      fontWeight: 600,
      color: 'var(--text-brand)'
    }
  }, totals[c.key] ?? (i === 0 ? 'Итого' : ''))))))));
}
Object.assign(__ds_scope, { mixHex, Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/data/TrendBadge.jsx
try { (() => {
// Компактный бейдж сравнения из ReportTable: значение + стрелка тренда, тултип
// «пред. X · +Δ / +Δ%». Порог нейтральности «~» — threshold (по умолчанию 0).
const fmt = (v, dp = 0) => v == null ? '—' : v.toLocaleString('ru-RU', {
  minimumFractionDigits: dp,
  maximumFractionDigits: dp
});
function TrendBadge({
  value,
  prev,
  unit = '',
  decimals = 0,
  threshold = 0,
  style
}) {
  const delta = value != null && prev != null ? value - prev : null;
  const deltaPct = delta != null && prev ? delta / prev * 100 : null;
  const dir = deltaPct == null ? null : deltaPct > threshold ? 'up' : deltaPct < -threshold ? 'down' : 'flat';
  const tip = deltaPct == null ? undefined : `пред. ${fmt(prev, decimals)}${unit ? ' ' + unit : ''} · ${delta > 0 ? '+' : ''}${fmt(delta, decimals)} / ${deltaPct > 0 ? '+' : ''}${fmt(deltaPct, 1)}%`;
  return /*#__PURE__*/React.createElement("span", {
    title: tip,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '4px',
      fontVariantNumeric: 'tabular-nums',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, fmt(value, decimals), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)'
    }
  }, unit), dir === 'up' && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "trend-up",
    size: 12,
    color: "var(--success)"
  }), dir === 'down' && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "trend-down",
    size: 12,
    color: "var(--danger)"
  }), dir === 'flat' && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '10px',
      color: 'var(--text-tertiary)'
    }
  }, "~"));
}
Object.assign(__ds_scope, { TrendBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/TrendBadge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Modal.jsx
try { (() => {
function Modal({
  open,
  title,
  children,
  footer,
  onClose,
  width = 440,
  style
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(2,18,38,.5)',
      backdropFilter: 'blur(6px)',
      WebkitBackdropFilter: 'blur(6px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 100,
      fontFamily: 'var(--font-ui)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width,
      maxWidth: 'calc(100vw - 48px)',
      maxHeight: 'calc(100vh - 48px)',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-modal)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '12px',
      padding: '16px 20px',
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-md)',
      fontWeight: 600,
      lineHeight: '24px'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    onClick: onClose,
    style: {
      cursor: 'pointer',
      color: 'var(--text-tertiary)',
      width: '28px',
      height: '28px',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-sm)',
      transition: 'background var(--transition-fast)'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'var(--gray-100)',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent'
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px',
      overflowY: 'auto',
      fontSize: 'var(--text-base)',
      color: 'var(--text-primary)'
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: '10px',
      padding: '14px 20px',
      borderTop: '1px solid var(--border-default)'
    }
  }, footer)));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Modal.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast({
  status = 'info',
  title,
  description,
  onClose,
  style
}) {
  const map = {
    success: {
      i: 'check',
      c: 'var(--success)'
    },
    danger: {
      i: 'alert',
      c: 'var(--danger)'
    },
    warning: {
      i: 'alert',
      c: 'var(--warning)'
    },
    info: {
      i: 'info',
      c: 'var(--info)'
    }
  };
  const m = map[status] || map.info;
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '10px',
      width: '340px',
      padding: '12px 10px 12px 14px',
      background: 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-toast)',
      fontFamily: 'var(--font-ui)',
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: '20px',
      height: '20px',
      borderRadius: '50%',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: m.c,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: m.i,
    size: 12,
    strokeWidth: 3
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-base)',
      fontWeight: 600,
      lineHeight: '20px'
    }
  }, title), description && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      lineHeight: '18px',
      marginTop: '2px'
    }
  }, description)), onClose && /*#__PURE__*/React.createElement("span", {
    onClick: onClose,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      width: '20px',
      height: '20px',
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      color: hov ? 'var(--text-primary)' : 'var(--text-tertiary)',
      background: hov ? 'var(--gray-100)' : 'transparent',
      borderRadius: 'var(--radius-sm)',
      transition: 'all var(--transition-fast)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 13
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  content,
  side = 'top',
  children,
  style
}) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translate(-50%,-6px)'
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translate(-50%,6px)'
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translate(-6px,-50%)'
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translate(6px,-50%)'
    }
  }[side];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      ...pos,
      background: 'var(--gray-900)',
      color: '#fff',
      fontSize: 'var(--text-xs)',
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      padding: '5px 9px',
      borderRadius: 'var(--radius-sm)',
      whiteSpace: 'nowrap',
      zIndex: 60,
      pointerEvents: 'none'
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = 'primary',
  size = 'md',
  icon,
  iconRight,
  children,
  disabled,
  fullWidth,
  style,
  onClick,
  ...rest
}) {
  const h = {
    sm: 'var(--control-h-sm)',
    md: 'var(--control-h)',
    lg: 'var(--control-h-lg)'
  }[size];
  const fs = {
    sm: 'var(--text-sm)',
    md: 'var(--text-base)',
    lg: 'var(--text-md)'
  }[size];
  const px = {
    sm: '10px',
    md: '14px',
    lg: '18px'
  }[size];
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const v = {
    primary: {
      background: 'var(--grad-brand)',
      filter: press ? 'brightness(.88)' : hover ? 'brightness(1.1)' : 'none',
      color: '#fff',
      border: '1px solid rgba(255,255,255,.28)',
      boxShadow: '0 4px 14px rgba(0,92,169,.35)'
    },
    secondary: {
      background: hover ? 'var(--gray-50)' : 'var(--surface-card)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border-strong)'
    },
    ghost: {
      background: hover ? 'var(--gray-100)' : 'transparent',
      color: 'var(--text-primary)',
      border: '1px solid transparent'
    },
    danger: {
      background: press ? '#A61B1B' : hover ? '#C42020' : 'var(--danger)',
      color: '#fff',
      border: '1px solid transparent'
    }
  }[variant];
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '8px',
      height: h,
      padding: `0 ${px}`,
      borderRadius: 'var(--radius-md)',
      fontFamily: 'var(--font-ui)',
      fontSize: fs,
      fontWeight: 500,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      transition: 'background var(--transition-fast), filter var(--transition-fast)',
      width: fullWidth ? '100%' : undefined,
      ...v,
      ...style
    }
  }, rest), icon, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/DateRangePicker.jsx
try { (() => {
const M = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'];
const MG = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const fmt = d => d ? `${d.getDate()} ${MG[d.getMonth()]} ${d.getFullYear()}` : '';
function DateRangePicker({
  label,
  start,
  end,
  onChange,
  size = 'md',
  style
}) {
  const h = {
    sm: 'var(--control-h-sm)',
    md: 'var(--control-h)',
    lg: 'var(--control-h-lg)'
  }[size];
  const [open, setOpen] = React.useState(false);
  const [s, setS] = React.useState(start || null);
  const [e, setE] = React.useState(end || null);
  const [view, setView] = React.useState(() => new Date((start || new Date()).getFullYear(), (start || new Date()).getMonth(), 1));
  const ref = React.useRef(null);
  React.useEffect(() => {
    const f = ev => {
      if (ref.current && !ref.current.contains(ev.target)) setOpen(false);
    };
    document.addEventListener('mousedown', f);
    return () => document.removeEventListener('mousedown', f);
  }, []);
  const pick = d => {
    if (!s || s && e) {
      setS(d);
      setE(null);
    } else {
      const a = d < s ? d : s,
        b = d < s ? s : d;
      setS(a);
      setE(b);
      onChange && onChange(a, b);
    }
  };
  const preset = (a, b) => {
    setS(a);
    setE(b);
    onChange && onChange(a, b);
    setOpen(false);
  };
  const now = new Date();
  const y = view.getFullYear(),
    m = view.getMonth();
  const first = (new Date(y, m, 1).getDay() + 6) % 7;
  const days = new Date(y, m + 1, 0).getDate();
  const inR = d => s && e && d > s && d < e;
  const same = (a, b) => a && b && a.toDateString() === b.toDateString();
  const cell = {
    width: '32px',
    height: '28px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '13px',
    borderRadius: 'var(--radius-sm)',
    cursor: 'pointer',
    fontVariantNumeric: 'tabular-nums'
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--text-sm)',
      position: 'relative',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 500
    }
  }, label), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      height: h,
      padding: '0 12px',
      background: 'var(--surface-card)',
      border: `1px solid ${open ? 'var(--border-focus)' : 'var(--border-strong)'}`,
      boxShadow: open ? 'var(--focus-ring)' : 'none',
      borderRadius: 'var(--radius-md)',
      font: 'inherit',
      fontSize: 'var(--text-base)',
      color: s ? 'var(--text-primary)' : 'var(--text-tertiary)',
      cursor: 'pointer',
      fontVariantNumeric: 'tabular-nums',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "calendar",
    size: 16,
    color: "var(--text-tertiary)"
  }), s ? `${fmt(s)}${e ? ' — ' + fmt(e) : ' — …'}` : 'Выберите период'), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      marginTop: '4px',
      background: 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-hover)',
      padding: '12px',
      zIndex: 30,
      display: 'flex',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '4px',
      borderRight: '1px solid var(--border-default)',
      paddingRight: '12px'
    }
  }, [['Этот месяц', new Date(now.getFullYear(), now.getMonth(), 1), new Date(now.getFullYear(), now.getMonth() + 1, 0)], ['Прошлый месяц', new Date(now.getFullYear(), now.getMonth() - 1, 1), new Date(now.getFullYear(), now.getMonth(), 0)], ['Квартал', new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1), now], ['Год', new Date(now.getFullYear(), 0, 1), now]].map(([l, a, b], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    onClick: () => preset(a, b),
    style: {
      padding: '6px 10px',
      fontSize: '13px',
      borderRadius: 'var(--radius-sm)',
      cursor: 'pointer',
      whiteSpace: 'nowrap'
    },
    onMouseEnter: ev => ev.currentTarget.style.background = 'var(--surface-selected)',
    onMouseLeave: ev => ev.currentTarget.style.background = 'transparent'
  }, l))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '8px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => setView(new Date(y, m - 1, 1)),
    style: {
      cursor: 'pointer',
      display: 'flex',
      padding: '2px'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-left",
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      fontWeight: 600
    }
  }, M[m], " ", y), /*#__PURE__*/React.createElement("span", {
    onClick: () => setView(new Date(y, m + 1, 1)),
    style: {
      cursor: 'pointer',
      display: 'flex',
      padding: '2px'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7,32px)'
    }
  }, ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'].map(d => /*#__PURE__*/React.createElement("span", {
    key: d,
    style: {
      ...cell,
      cursor: 'default',
      color: 'var(--text-tertiary)',
      fontSize: '11px'
    }
  }, d)), Array.from({
    length: first
  }).map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: 'e' + i
  })), Array.from({
    length: days
  }).map((_, i) => {
    const d = new Date(y, m, i + 1);
    const isS = same(d, s),
      isE = same(d, e);
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      onClick: () => pick(d),
      style: {
        ...cell,
        background: isS || isE ? 'var(--interactive)' : inR(d) ? 'var(--blue-50)' : 'transparent',
        color: isS || isE ? '#fff' : 'var(--text-primary)',
        fontWeight: isS || isE ? 600 : 400
      },
      onMouseEnter: ev => {
        if (!isS && !isE && !inR(d)) ev.currentTarget.style.background = 'var(--gray-100)';
      },
      onMouseLeave: ev => {
        if (!isS && !isE) ev.currentTarget.style.background = inR(d) ? 'var(--blue-50)' : 'transparent';
      }
    }, i + 1);
  })))));
}
Object.assign(__ds_scope, { DateRangePicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/DateRangePicker.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  icon,
  size = 'md',
  type = 'text',
  value,
  defaultValue,
  onChange,
  placeholder,
  disabled,
  style,
  ...rest
}) {
  const h = {
    sm: 'var(--control-h-sm)',
    md: 'var(--control-h)',
    lg: 'var(--control-h-lg)'
  }[size];
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-primary)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 500
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      height: h,
      padding: '0 12px',
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: `1px solid ${error ? 'var(--danger)' : focus ? 'var(--border-focus)' : 'var(--border-strong)'}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      transition: 'border-color var(--transition-fast), box-shadow var(--transition-fast)'
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      display: 'flex'
    }
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      font: 'inherit',
      fontSize: 'var(--text-base)',
      color: 'inherit',
      minWidth: 0
    }
  }, rest))), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--danger-text)',
      fontSize: 'var(--text-xs)'
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-xs)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  options = [],
  value,
  onChange,
  placeholder = 'Выберите…',
  size = 'md',
  disabled,
  style
}) {
  const h = {
    sm: 'var(--control-h-sm)',
    md: 'var(--control-h)',
    lg: 'var(--control-h-lg)'
  }[size];
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const f = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', f);
    return () => document.removeEventListener('mousedown', f);
  }, []);
  const sel = options.find(o => (o.value ?? o) === value);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--text-sm)',
      position: 'relative',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 500
    }
  }, label), /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: () => setOpen(o => !o),
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '8px',
      height: h,
      padding: '0 10px 0 12px',
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: `1px solid ${open ? 'var(--border-focus)' : 'var(--border-strong)'}`,
      boxShadow: open ? 'var(--focus-ring)' : 'none',
      borderRadius: 'var(--radius-md)',
      font: 'inherit',
      fontSize: 'var(--text-base)',
      color: sel ? 'var(--text-primary)' : 'var(--text-tertiary)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'border-color var(--transition-fast)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, sel ? sel.label ?? sel : placeholder), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16,
    color: "var(--text-tertiary)",
    style: {
      transform: open ? 'rotate(180deg)' : 'none',
      transition: 'transform var(--transition-fast)'
    }
  })), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      right: 0,
      marginTop: '4px',
      background: 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-hover)',
      padding: '4px',
      zIndex: 30,
      maxHeight: '240px',
      overflowY: 'auto'
    }
  }, options.map((o, i) => {
    const v = o.value ?? o,
      l = o.label ?? o,
      act = v === value;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      onClick: () => {
        onChange && onChange(v);
        setOpen(false);
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '7px 8px',
        borderRadius: 'var(--radius-sm)',
        fontSize: 'var(--text-base)',
        cursor: 'pointer',
        background: act ? 'var(--surface-selected)' : 'transparent',
        color: act ? 'var(--text-brand)' : 'var(--text-primary)',
        fontWeight: act ? 500 : 400
      },
      onMouseEnter: e => {
        if (!act) e.currentTarget.style.background = 'var(--gray-50)';
      },
      onMouseLeave: e => {
        if (!act) e.currentTarget.style.background = 'transparent';
      }
    }, l, act && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "check",
      size: 14
    }));
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/gamification/MLTCoin.jsx
try { (() => {
function MLTCoin({
  size = 20,
  detailed,
  style
}) {
  const full = detailed ?? size >= 48;
  if (!full) {
    return /*#__PURE__*/React.createElement("svg", {
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      style: {
        flex: 'none',
        ...style
      },
      "aria-label": "MLT"
    }, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "12",
      fill: "#005CA9"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "10.2",
      fill: "#1B7FD4"
    }), size >= 20 && /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "10.2",
      fill: "none",
      stroke: "#7FB9E8",
      strokeWidth: ".8",
      strokeOpacity: ".7"
    }), /*#__PURE__*/React.createElement("text", {
      x: "12",
      y: "16.6",
      fontFamily: "var(--font-coin,Georgia,serif)",
      fontSize: "13",
      fontWeight: "700",
      fill: "#FFFFFF",
      textAnchor: "middle"
    }, "M"));
  }
  const uid = React.useId().replace(/:/g, '');
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 96 96",
    style: {
      flex: 'none',
      ...style
    },
    "aria-label": "MLT"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: 'r' + uid,
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#7FB9E8"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: ".5",
    stopColor: "#1B7FD4"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#004A8A"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: 'f' + uid,
    cx: ".5",
    cy: ".35",
    r: ".8"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#4A9CDE"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: ".6",
    stopColor: "#1B7FD4"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#005CA9"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: 'm' + uid,
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#FFFFFF"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#D7E9F8"
  }))), /*#__PURE__*/React.createElement("circle", {
    cx: "48",
    cy: "48",
    r: "47",
    fill: `url(#r${uid})`
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "48",
    cy: "48",
    r: "45.2",
    fill: "none",
    stroke: "#D7E9F8",
    strokeOpacity: ".55",
    strokeWidth: "2.6",
    strokeDasharray: "1.2 2.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "48",
    cy: "48",
    r: "41",
    fill: `url(#f${uid})`
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "48",
    cy: "48",
    r: "41",
    fill: "none",
    stroke: "#003563",
    strokeOpacity: ".3"
  }), /*#__PURE__*/React.createElement("path", {
    id: 'a' + uid,
    d: "M 48 12.5 a 35.5 35.5 0 1 1 -0.02 0",
    fill: "none"
  }), /*#__PURE__*/React.createElement("text", {
    fontFamily: "var(--font-coin,Georgia,serif)",
    fontSize: "5.4",
    fontWeight: "700",
    fill: "#fff",
    fillOpacity: ".75",
    letterSpacing: "1.6"
  }, /*#__PURE__*/React.createElement("textPath", {
    href: `#a${uid}`
  }, "MLT \xB7 MLT \xB7 MLT \xB7 MLT \xB7 MLT \xB7 MLT \xB7 MLT \xB7 MLT \xB7 MLT \xB7 MLT \xB7 MLT \xB7 MLT")), /*#__PURE__*/React.createElement("path", {
    d: "M 22.5 48 l 3.2 -3.2 3.2 3.2 -3.2 3.2 z",
    fill: "#fff",
    fillOpacity: ".9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M 67.1 48 l 3.2 -3.2 3.2 3.2 -3.2 3.2 z",
    fill: "#fff",
    fillOpacity: ".9"
  }), /*#__PURE__*/React.createElement("text", {
    x: "48",
    y: "63.5",
    fontFamily: "var(--font-coin,Georgia,serif)",
    fontSize: "40",
    fontWeight: "700",
    fill: `url(#m${uid})`,
    textAnchor: "middle"
  }, "M"));
}
Object.assign(__ds_scope, { MLTCoin });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/gamification/MLTCoin.jsx", error: String((e && e.message) || e) }); }

// components/gamification/MLTAmount.jsx
try { (() => {
function MLTAmount({
  value,
  delta = false,
  size = 'md',
  showUnit = true,
  style
}) {
  const s = {
    sm: {
      coin: 14,
      fs: 'var(--text-sm)'
    },
    md: {
      coin: 16,
      fs: 'var(--text-base)'
    },
    lg: {
      coin: 20,
      fs: 'var(--text-md)'
    }
  }[size];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      fontFamily: 'var(--font-ui)',
      fontSize: s.fs,
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--text-primary)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.MLTCoin, {
    size: s.coin
  }), delta && value >= 0 ? '+' : '', value.toLocaleString('ru-RU'), showUnit && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)',
      fontWeight: 500,
      fontSize: '0.85em'
    }
  }, "MLT"));
}
Object.assign(__ds_scope, { MLTAmount });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/gamification/MLTAmount.jsx", error: String((e && e.message) || e) }); }

// components/gamification/QuestCard.jsx
try { (() => {
// Плашка квеста (паттерн QuestsTab кодовой базы), переработана: таймер и шапка не
// ломаются на узких колонках, награда — чип с монетой, реролл — понятная кнопка
// «Заменить квест за N MLT» (что меняем, сколько стоит, в какой валюте).
const TIERS = {
  white: {
    label: 'Обычный',
    color: 'var(--quest-white,#9ca3af)'
  },
  green: {
    label: 'Необычный',
    color: 'var(--quest-green,#2f9e44)'
  },
  blue: {
    label: 'Редкий',
    color: 'var(--quest-blue,#1c7ed6)'
  },
  epic: {
    label: 'Эпический',
    color: 'var(--quest-epic,#9c36b5)'
  },
  legendary: {
    label: 'Легендарный',
    color: 'var(--quest-legendary,#e8590c)'
  }
};
const fmtN = v => v >= 10000 ? v.toLocaleString('ru-RU') : String(Math.round(v * 10) / 10);
function QuestCard({
  tier = 'blue',
  slot = 'Дневной',
  title,
  progress = 0,
  target = 1,
  rewardMlt = 0,
  rewardXp = 0,
  status = 'active',
  deadline,
  rerollPrice,
  onReroll,
  format = fmtN,
  style
}) {
  const t = TIERS[tier] || TIERS.blue;
  const done = status === 'done';
  const color = done ? 'var(--quest-green,#2f9e44)' : t.color;
  const pct = Math.min(100, Math.round(progress / Math.max(target, 1) * 100));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      padding: '14px 16px',
      borderRadius: 'var(--radius-lg)',
      border: `1.5px solid color-mix(in srgb, ${color} 50%, transparent)`,
      background: `linear-gradient(color-mix(in srgb, ${color} 7%, transparent),color-mix(in srgb, ${color} 7%, transparent)),var(--surface-card)`,
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      boxShadow: 'var(--shadow-card)',
      fontFamily: 'var(--font-ui)',
      minWidth: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      borderRadius: 7,
      padding: '2px 7px',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '.05em',
      textTransform: 'uppercase',
      color: '#fff',
      background: t.color,
      whiteSpace: 'nowrap'
    }
  }, t.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: 'var(--text-secondary)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      minWidth: 0
    }
  }, slot), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      flex: 'none',
      fontSize: 11,
      whiteSpace: 'nowrap',
      color: done ? 'var(--success-text)' : status === 'failed' ? 'var(--text-tertiary)' : 'var(--text-secondary)',
      fontVariantNumeric: 'tabular-nums',
      fontWeight: done ? 600 : 400
    }
  }, done ? '✅ выполнен' : status === 'failed' ? 'сгорел' : deadline)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--text-primary)',
      lineHeight: 1.35,
      overflowWrap: 'break-word'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8,
      borderRadius: 999,
      background: 'var(--surface-sunken)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: Math.max(pct, 2) + '%',
      borderRadius: 999,
      background: color,
      transition: 'width var(--transition-normal)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--text-secondary)',
      whiteSpace: 'nowrap'
    }
  }, format(progress), " \u0438\u0437 ", format(target)), /*#__PURE__*/React.createElement("span", {
    title: `Награда за выполнение: ${rewardMlt} MLT и ${rewardXp} XP`,
    style: {
      flex: 'none',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      background: 'var(--surface-selected)',
      borderRadius: 999,
      padding: '3px 9px',
      fontSize: 11,
      fontWeight: 700,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--text-brand)',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.MLTCoin, {
    size: 13
  }), "+", rewardMlt, " MLT \xB7 +", rewardXp, " XP"))), status === 'active' && rerollPrice != null && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onReroll,
    title: "\u041D\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u043A\u0432\u0435\u0441\u0442? \u0417\u0430\u043C\u0435\u043D\u0438\u0442\u0435 \u0435\u0433\u043E \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u0439 \u0442\u043E\u0433\u043E \u0436\u0435 \u0442\u0438\u0440\u0430. \u0421\u043F\u0438\u0448\u0435\u0442\u0441\u044F \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 MLT; \u043C\u0430\u043A\u0441\u0438\u043C\u0443\u043C \u043E\u0434\u043D\u0430 \u0437\u0430\u043C\u0435\u043D\u0430.",
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexWrap: 'wrap',
      gap: '2px 6px',
      width: '100%',
      minHeight: 30,
      padding: '4px 8px',
      appearance: 'none',
      border: '1px solid var(--border-strong)',
      background: 'transparent',
      borderRadius: 9,
      fontSize: 12,
      fontWeight: 600,
      fontFamily: 'inherit',
      color: 'var(--text-primary)',
      cursor: 'pointer'
    }
  }, "\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u0432\u0435\u0441\u0442 \u0437\u0430 ", /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      fontVariantNumeric: 'tabular-nums'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.MLTCoin, {
    size: 13
  }), rerollPrice, " MLT")));
}
Object.assign(__ds_scope, { QuestCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/gamification/QuestCard.jsx", error: String((e && e.message) || e) }); }

// components/gamification/RewardCard.jsx
try { (() => {
const TIERS = {
  bronze: {
    label: 'Бронза',
    bg: 'var(--tier-bronze)',
    grad: 'linear-gradient(135deg,#C9A76C 0%,#B08D57 60%,#8C6E3F 100%)',
    glow: 'none'
  },
  silver: {
    label: 'Серебро',
    bg: 'var(--tier-silver)',
    grad: 'linear-gradient(135deg,#C3CCD6 0%,#9AA5B1 60%,#78848F 100%)',
    glow: 'none'
  },
  gold: {
    label: 'Золото',
    bg: 'var(--tier-gold)',
    grad: 'var(--grad-gold)',
    glow: 'var(--glow-gold)'
  },
  platinum: {
    label: 'Платина',
    bg: 'var(--tier-platinum)',
    grad: 'var(--grad-platinum)',
    glow: 'var(--glow-rare)'
  }
};
function RewardCard({
  tier = 'bronze',
  title,
  description,
  price,
  image,
  action,
  style
}) {
  const t = TIERS[tier] || TIERS.bronze;
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      width: '220px',
      background: 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      fontFamily: 'var(--font-ui)',
      boxShadow: hov ? `var(--shadow-hover)${t.glow !== 'none' ? ', ' + t.glow : ''}` : t.glow !== 'none' ? t.glow : 'var(--shadow-card)',
      transition: 'box-shadow var(--transition-normal), transform var(--transition-normal)',
      transform: hov ? 'translateY(-2px)' : 'none',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '110px',
      background: t.grad,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative'
    }
  }, image, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '8px',
      left: '8px',
      fontSize: '11px',
      fontWeight: 600,
      color: '#fff',
      background: 'rgba(0,0,0,.22)',
      padding: '2px 8px',
      borderRadius: '999px',
      letterSpacing: '.02em'
    }
  }, t.label)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 14px',
      display: 'flex',
      flexDirection: 'column',
      gap: '6px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-base)',
      fontWeight: 600
    }
  }, title), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-secondary)'
    }
  }, description), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: '4px'
    }
  }, price != null ? /*#__PURE__*/React.createElement(__ds_scope.MLTAmount, {
    value: price
  }) : /*#__PURE__*/React.createElement("span", null), action)));
}
Object.assign(__ds_scope, { RewardCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/gamification/RewardCard.jsx", error: String((e && e.message) || e) }); }

// components/navigation/FilterChips.jsx
try { (() => {
function FilterChips({
  items = [],
  value,
  values,
  onChange,
  multi = false,
  style
}) {
  const sel = multi ? values || [] : [value];
  const click = v => {
    if (!onChange) return;
    if (multi) {
      const n = sel.includes(v) ? sel.filter(x => x !== v) : [...sel, v];
      onChange(n);
    } else onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px',
      flexWrap: 'wrap',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, items.map((it, i) => {
    const v = it.value ?? it,
      l = it.label ?? it,
      act = sel.includes(v);
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      onClick: () => click(v),
      style: {
        appearance: 'none',
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px',
        height: '28px',
        padding: '0 12px',
        borderRadius: 'var(--radius-full)',
        border: `1px solid ${act ? 'var(--interactive)' : 'var(--border-strong)'}`,
        background: act ? 'var(--surface-selected)' : 'var(--surface-card)',
        color: act ? 'var(--text-brand)' : 'var(--text-primary)',
        fontSize: 'var(--text-sm)',
        fontFamily: 'inherit',
        fontWeight: act ? 500 : 400,
        cursor: 'pointer',
        transition: 'all var(--transition-fast)'
      },
      onMouseEnter: e => {
        if (!act) e.currentTarget.style.background = 'var(--gray-50)';
      },
      onMouseLeave: e => {
        if (!act) e.currentTarget.style.background = 'var(--surface-card)';
      }
    }, l, act && multi && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "x",
      size: 12
    }));
  }));
}
Object.assign(__ds_scope, { FilterChips });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/FilterChips.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
function Pagination({
  page = 1,
  pageCount = 1,
  onChange,
  total,
  pageSize,
  style
}) {
  const btn = (act, dis) => ({
    minWidth: '28px',
    height: '28px',
    padding: '0 6px',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid ' + (act ? 'var(--interactive)' : 'transparent'),
    background: act ? 'var(--surface-selected)' : 'transparent',
    color: dis ? 'var(--text-tertiary)' : act ? 'var(--text-brand)' : 'var(--text-primary)',
    fontSize: 'var(--text-sm)',
    fontWeight: act ? 600 : 400,
    fontVariantNumeric: 'tabular-nums',
    cursor: dis ? 'default' : 'pointer',
    fontFamily: 'inherit'
  });
  const pages = [];
  const push = p => pages.push(p);
  if (pageCount <= 7) {
    for (let i = 1; i <= pageCount; i++) push(i);
  } else {
    push(1);
    if (page > 3) push('…');
    for (let i = Math.max(2, page - 1); i <= Math.min(pageCount - 1, page + 1); i++) push(i);
    if (page < pageCount - 2) push('…');
    push(pageCount);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, total != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      marginRight: '8px',
      fontVariantNumeric: 'tabular-nums'
    }
  }, (page - 1) * pageSize + 1, "\u2013", Math.min(page * pageSize, total), " \u0438\u0437 ", total), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: btn(false, page <= 1),
    disabled: page <= 1,
    onClick: () => onChange && onChange(page - 1)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-left",
    size: 15
  })), pages.map((p, i) => p === '…' ? /*#__PURE__*/React.createElement("span", {
    key: 'd' + i,
    style: {
      ...btn(false, true),
      border: 'none'
    }
  }, "\u2026") : /*#__PURE__*/React.createElement("button", {
    key: p,
    type: "button",
    style: btn(p === page, false),
    onClick: () => onChange && onChange(p)
  }, p)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: btn(false, page >= pageCount),
    disabled: page >= pageCount,
    onClick: () => onChange && onChange(page + 1)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 15
  })));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Sidebar.jsx
try { (() => {
function Sidebar({
  sections = [],
  activeId,
  onSelect,
  header,
  footer,
  width = 232,
  style
}) {
  const [openIds, setOpen] = React.useState(() => new Set(sections.flatMap(s => s.items.filter(i => i.children && i.children.some(c => c.id === activeId)).map(i => i.id))));
  const toggle = id => setOpen(p => {
    const n = new Set(p);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });
  const Item = ({
    it,
    depth = 0
  }) => {
    const hasKids = it.children && it.children.length > 0;
    const open = openIds.has(it.id);
    const active = it.id === activeId;
    const [hov, setHov] = React.useState(false);
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      onClick: () => hasKids ? toggle(it.id) : onSelect && onSelect(it.id),
      onMouseEnter: () => setHov(true),
      onMouseLeave: () => setHov(false),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        height: '34px',
        padding: `0 10px 0 ${10 + depth * 24}px`,
        margin: '1px 8px',
        borderRadius: 'var(--radius-md)',
        cursor: 'pointer',
        fontSize: 'var(--text-base)',
        fontWeight: active ? 500 : 400,
        color: active ? 'var(--text-brand)' : 'var(--text-primary)',
        background: active ? 'var(--surface-selected)' : hov ? 'var(--gray-100)' : 'transparent',
        transition: 'background var(--transition-fast)'
      }
    }, it.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 17,
      color: active ? 'var(--brand)' : 'var(--text-secondary)'
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, it.label), it.badge != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '11px',
        fontWeight: 600,
        fontVariantNumeric: 'tabular-nums',
        background: active ? 'var(--blue-100)' : 'var(--gray-100)',
        color: active ? 'var(--blue-700)' : 'var(--text-secondary)',
        borderRadius: '999px',
        padding: '1px 7px'
      }
    }, it.badge), hasKids && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "chevron-down",
      size: 14,
      color: "var(--text-tertiary)",
      style: {
        transform: open ? 'none' : 'rotate(-90deg)',
        transition: 'transform var(--transition-fast)'
      }
    })), hasKids && open && it.children.map(c => /*#__PURE__*/React.createElement(Item, {
      key: c.id,
      it: c,
      depth: depth + 1
    })));
  };
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      width,
      flex: 'none',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--glass-side)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      borderRight: '1px solid var(--glass-border)',
      fontFamily: 'var(--font-ui)',
      height: '100%',
      overflowY: 'auto',
      ...style
    }
  }, header && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 18px 12px'
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      paddingBottom: '8px'
    }
  }, sections.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, s.title && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 18px 4px',
      fontSize: '11px',
      fontWeight: 600,
      letterSpacing: '.04em',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    }
  }, s.title), s.items.map(it => /*#__PURE__*/React.createElement(Item, {
    key: it.id,
    it: it
  }))))), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-default)',
      padding: '12px 16px'
    }
  }, footer));
}
Object.assign(__ds_scope, { Sidebar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Sidebar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  size = 'md',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '2px',
      borderBottom: '1px solid var(--border-default)',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, items.map((it, i) => {
    const v = it.value ?? it,
      l = it.label ?? it,
      act = v === value;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      onClick: () => onChange && onChange(v),
      style: {
        appearance: 'none',
        background: 'transparent',
        border: 'none',
        borderBottom: `2px solid ${act ? 'var(--interactive)' : 'transparent'}`,
        marginBottom: '-1px',
        padding: size === 'sm' ? '8px 10px' : '10px 14px',
        fontSize: size === 'sm' ? 'var(--text-sm)' : 'var(--text-base)',
        fontFamily: 'inherit',
        fontWeight: act ? 600 : 400,
        color: act ? 'var(--text-brand)' : 'var(--text-secondary)',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        transition: 'color var(--transition-fast)'
      },
      onMouseEnter: e => {
        if (!act) e.currentTarget.style.color = 'var(--text-primary)';
      },
      onMouseLeave: e => {
        if (!act) e.currentTarget.style.color = 'var(--text-secondary)';
      }
    }, l, it.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '11px',
        fontWeight: 600,
        fontVariantNumeric: 'tabular-nums',
        background: act ? 'var(--blue-50)' : 'var(--gray-100)',
        color: act ? 'var(--blue-700)' : 'var(--text-secondary)',
        borderRadius: '999px',
        padding: '1px 7px'
      }
    }, it.count));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/monolitika/Dashboard.jsx
try { (() => {
function DashboardScreen() {
  const [range, setRange] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 24,
      fontWeight: 600,
      color: 'var(--text-on-app)'
    }
  }, "\u041E\u0431\u0437\u043E\u0440 \u043F\u0440\u043E\u0434\u0430\u0436"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-on-app-secondary)',
      marginTop: 2
    }
  }, "\u0421\u0432\u043E\u0434\u043A\u0430 \u043F\u043E \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438 \u0437\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u043F\u0435\u0440\u0438\u043E\u0434")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(DateRangePicker, {
    start: new Date(2026, 6, 1),
    end: new Date(2026, 6, 31)
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 16
    })
  }, "\u042D\u043A\u0441\u043F\u043E\u0440\u0442"), /*#__PURE__*/React.createElement(Button, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "filter",
      size: 16
    })
  }, "\u0424\u0438\u043B\u044C\u0442\u0440\u044B"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(KPICard, {
    accent: true,
    label: "\u0412\u044B\u0440\u0443\u0447\u043A\u0430",
    value: "12 480 350 \u20BD",
    delta: 4.9,
    footer: "\u041F\u0440\u043E\u0448\u043B\u044B\u0439 \u043C\u0435\u0441\u044F\u0446: 11 897 020 \u20BD",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "wallet",
      size: 16
    })
  }), /*#__PURE__*/React.createElement(KPICard, {
    label: "\u041E\u0442\u0433\u0440\u0443\u0437\u043A\u0438",
    value: "1 692",
    delta: -6.0,
    footer: "\u041F\u0440\u043E\u0448\u043B\u044B\u0439 \u043C\u0435\u0441\u044F\u0446: 1 800",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "package",
      size: 16
    })
  }), /*#__PURE__*/React.createElement(KPICard, {
    label: "\u041D\u043E\u0432\u044B\u0435 \u043A\u043B\u0438\u0435\u043D\u0442\u044B",
    value: "110",
    delta: 7.5,
    footer: "\u041F\u0440\u043E\u0448\u043B\u044B\u0439 \u043C\u0435\u0441\u044F\u0446: 89",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "users",
      size: 16
    })
  }), /*#__PURE__*/React.createElement(KPICard, {
    label: "\u0421\u0440\u0435\u0434\u043D\u0438\u0439 \u0447\u0435\u043A",
    value: "73 760 \u20BD",
    delta: 2.1,
    footer: "\u041F\u0440\u043E\u0448\u043B\u044B\u0439 \u043C\u0435\u0441\u044F\u0446: 72 240 \u20BD",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "chart",
      size: 16
    })
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(CardBox, {
    title: "\u0414\u0438\u043D\u0430\u043C\u0438\u043A\u0430 \u043F\u0440\u043E\u0434\u0430\u0436",
    extra: /*#__PURE__*/React.createElement(Select, {
      size: "sm",
      options: ['По месяцам', 'По неделям'],
      value: "\u041F\u043E \u043C\u0435\u0441\u044F\u0446\u0430\u043C",
      style: {
        width: 150
      }
    })
  }, /*#__PURE__*/React.createElement(BarChart, {
    height: 210,
    values: [8.4, 9.9, 7.2, 11.8, 9.6, 10.9, 12.5, 4.1],
    labels: ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг'],
    activeIndex: 6,
    valueFormat: v => v.toFixed(0) + ' млн'
  })), /*#__PURE__*/React.createElement(CardBox, {
    title: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043B\u0430\u043D\u0430"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Gauge, {
    percent: 70.8,
    label: "\u043F\u043B\u0430\u043D \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438, \u0438\u044E\u043B\u044C",
    size: 210
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10,
      width: '100%',
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--gray-50)',
      borderRadius: 10,
      padding: '10px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-secondary)'
    }
  }, "\u041F\u043B\u0430\u043D"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums'
    }
  }, "17,6 \u043C\u043B\u043D \u20BD")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--gray-50)',
      borderRadius: 10,
      padding: '10px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-secondary)'
    }
  }, "\u0424\u0430\u043A\u0442"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums'
    }
  }, "12,5 \u043C\u043B\u043D \u20BD")))))), /*#__PURE__*/React.createElement(CardBox, {
    title: "\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 \u043E\u0442\u0433\u0440\u0443\u0437\u043A\u0438",
    extra: /*#__PURE__*/React.createElement(Input, {
      size: "sm",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "search",
        size: 15
      }),
      placeholder: "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043A\u043B\u0438\u0435\u043D\u0442\u0430\u043C\u2026",
      style: {
        width: 220
      }
    })
  }, /*#__PURE__*/React.createElement(Table, {
    zebra: false,
    columns: [{
      key: 'name',
      label: 'Клиент'
    }, {
      key: 'mgr',
      label: 'Менеджер',
      width: 120
    }, {
      key: 'city',
      label: 'Филиал',
      width: 90
    }, {
      key: 'fact',
      label: 'Сумма, ₽',
      align: 'right'
    }, {
      key: 'ship',
      label: 'Позиции',
      align: 'right',
      width: 80
    }, {
      key: 'st',
      label: 'Статус',
      width: 130,
      render: v => /*#__PURE__*/React.createElement(Badge, {
        status: v,
        dot: true
      }, ST_LABEL[v])
    }],
    rows: REPORT_ROWS.slice(0, 6)
  })));
}
window.DashboardScreen = DashboardScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/monolitika/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/monolitika/Gamification.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function GamificationScreen() {
  const QuestCard = window.DesignSystem_311945.QuestCard || window.QuestCardFallback;
  const [tab, setTab] = React.useState('quests');
  const [spin, setSpin] = React.useState(false);
  const [prize, setPrize] = React.useState(null);
  const BALANCE = 1250;
  // Квесты — слоты и тиры как в движке: 1 дневной + 2 недельных + 1 месячный; награда = база(5/15/60) × множитель тира (0.4/0.7/1/2/4), XP = 5 × MLT
  const quests = [{
    tier: 'blue',
    slot: 'Дневной',
    title: 'Сделать 3 продажи сегодня',
    progress: 2,
    target: 3,
    rewardMlt: 5,
    rewardXp: 25,
    deadline: 'до конца дня',
    rerollPrice: 10
  }, {
    tier: 'epic',
    slot: 'Недельный',
    title: 'Продать бетон 5 новым клиентам',
    progress: 2,
    target: 5,
    rewardMlt: 30,
    rewardXp: 150,
    deadline: 'ещё 3 дн.',
    rerollPrice: 20
  }, {
    tier: 'green',
    slot: 'Недельный',
    title: '7 повторных продаж за неделю',
    progress: 7,
    target: 7,
    rewardMlt: 10,
    rewardXp: 50,
    status: 'done'
  }, {
    tier: 'legendary',
    slot: 'Месячный',
    title: 'Выручка 4 200 000 ₽ за август',
    progress: 2941000,
    target: 4200000,
    rewardMlt: 240,
    rewardXp: 1200,
    deadline: 'ещё 27 дн.',
    rerollPrice: 50,
    format: v => window.DesignSystem_311945.FormatNum(v)
  }];
  const contractsMine = [{
    tier: 'blue',
    title: 'Оживить 5 «спящих» клиентов',
    progress: 3,
    target: 5,
    deposit: 15,
    rewardMlt: 40,
    deadline: 'ещё 9 дн.'
  }];
  const contractsOpen = [{
    tier: 'green',
    title: 'Собрать 4 отзыва клиентов',
    deposit: 10,
    rewardMlt: 25,
    days: 14
  }, {
    tier: 'epic',
    title: 'Продать 3 позиции новой товарной группы',
    deposit: 30,
    rewardMlt: 90,
    days: 30
  }];
  // Магазин — реальный каталог (миграция 118); эмодзи разрешены в геймификации
  const shop = {
    'Нематериальные': [{
      e: '👑',
      t: 'Титул / кастомная рамка бейджа',
      d: 'Заметный титул рядом с именем на месяц',
      p: 50
    }, {
      e: '🕙',
      t: 'Поздний старт +2 часа',
      d: 'Прийти на 2 часа позже в согласованный день',
      p: 100
    }, {
      e: '🧹',
      t: 'Сброс мёртвых сделок',
      d: 'До 10 сделок из воронки без штрафа по метрикам',
      p: 150
    }, {
      e: '⚡',
      t: 'Приоритет лидов на 1 день',
      d: 'Первым в очереди распределения лидов',
      p: 250
    }, {
      e: '🏖️',
      t: 'Отгул',
      d: 'Полный оплачиваемый день отдыха',
      p: 500
    }],
    'Командные': [{
      e: '🍕',
      t: 'Пицца-день отдела',
      d: 'Купон руководителю на пиццу для всех',
      p: 800
    }, {
      e: '⏰',
      t: 'Поздний старт всего отдела',
      d: '+1 час всем, согласование с РОПом',
      p: 1500
    }, {
      e: '🚌',
      t: 'Тимбилдинг / выезд отдела',
      d: 'Крупный командный приз, одобрение сверху',
      p: 5000
    }],
    'Материальные': [{
      e: '☕',
      t: 'Кофе за счёт компании',
      d: 'Купон — показать руководителю',
      p: 25
    }, {
      e: '🎁',
      t: 'Фирменный мерч-бокс',
      d: 'Набор фирменного мерча',
      p: 300
    }, {
      e: '📱',
      t: 'iPhone (актуальный)',
      d: 'Флагман — топ-приз, остался 1 шт.',
      p: 15000
    }]
  };
  // Пул гачи — миграция 120 (сумма шансов = 100%), джекпот 0,006% + гарант
  const pool = [{
    e: '🪙',
    t: '+2 MLT',
    c: '39,49%'
  }, {
    e: '💰',
    t: '+5 MLT',
    c: '25%'
  }, {
    e: '🍀',
    t: '+10 MLT — крутка отбилась',
    c: '15%'
  }, {
    e: '☕',
    t: 'Кофе за счёт компании',
    c: '8%'
  }, {
    e: '🕙',
    t: 'Поздний старт +2 часа',
    c: '8%'
  }, {
    e: '🧹',
    t: 'Сброс мёртвых сделок',
    c: '4%'
  }, {
    e: '🏖️',
    t: 'Отгул',
    c: '0,25%',
    r: 'rare'
  }, {
    e: '🎁',
    t: 'Фирменный мерч-бокс',
    c: '0,25%',
    r: 'rare'
  }, {
    e: '📱',
    t: 'ДЖЕКПОТ: iPhone',
    c: '0,006%',
    r: 'jackpot'
  }];
  const doSpin = () => {
    setSpin(true);
    setPrize(null);
    setTimeout(() => {
      setSpin(false);
      setPrize({
        e: '☕',
        t: 'Кофе за счёт компании'
      });
    }, 1200);
  };
  const H3 = ({
    children,
    extra
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 10,
      margin: '4px 2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      color: 'var(--text-on-app)'
    }
  }, children), extra && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--text-on-app-secondary)'
    }
  }, extra));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 24,
      fontWeight: 600,
      color: 'var(--text-on-app)'
    }
  }, "\u041C\u043E\u0438 \u043D\u0430\u0433\u0440\u0430\u0434\u044B"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-on-app-secondary)',
      marginTop: 2
    }
  }, "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0439\u0442\u0435 \u043A\u0432\u0435\u0441\u0442\u044B, \u043A\u043E\u043F\u0438\u0442\u0435 MLT, \u043E\u0431\u043C\u0435\u043D\u0438\u0432\u0430\u0439\u0442\u0435 \u043D\u0430 \u043F\u0440\u0438\u0437\u044B")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      background: 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      border: '1px solid var(--glass-border)',
      boxShadow: 'var(--shadow-card)',
      borderRadius: 999,
      padding: '8px 16px'
    }
  }, /*#__PURE__*/React.createElement(MLTAmount, {
    value: BALANCE,
    size: "lg"
  }))), /*#__PURE__*/React.createElement(Tabs, {
    items: [{
      value: 'quests',
      label: 'Квесты',
      count: 4
    }, {
      value: 'shop',
      label: 'Магазин'
    }, {
      value: 'gacha',
      label: 'Гача'
    }, {
      value: 'inv',
      label: 'Инвентарь',
      count: 2
    }],
    value: tab,
    onChange: setTab
  }), tab === 'quests' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-on-app-secondary)',
      margin: '-6px 2px 0'
    }
  }, "\u041B\u0438\u0447\u043D\u044B\u0435 \u043C\u0438\u0441\u0441\u0438\u0438: \u0446\u0435\u043B\u0438 \u2014 \u043E\u0442 \u0432\u0430\u0448\u0435\u0439 \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u043F\u0440\u043E\u0434\u0430\u0436 (120% \u043C\u0435\u0434\u0438\u0430\u043D\u044B), \u0442\u0438\u0440 \u2014 \u0441\u043B\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043C\u0435\u0434\u0438\u0430\u043D\u043D\u043E\u0433\u043E \u043C\u0435\u043D\u0435\u0434\u0436\u0435\u0440\u0430 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438. \u041F\u0440\u043E\u0432\u0430\u043B\u0438\u043B \u2014 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0442\u0435\u0440\u044F\u0435\u0448\u044C, \u043A\u0432\u0435\u0441\u0442 \u0441\u0433\u043E\u0440\u0430\u0435\u0442. \u0417\u0430\u043C\u0435\u043D\u0430 \u0438 \u0434\u043E\u043F. \u043A\u0432\u0435\u0441\u0442 \u2014 \u0437\u0430 MLT."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))',
      gap: 14
    }
  }, quests.map((q, i) => /*#__PURE__*/React.createElement(QuestCard, _extends({
    key: i
  }, q)))), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    style: {
      alignSelf: 'flex-start'
    },
    title: "\u0414\u043D\u0435\u0432\u043D\u043E\u0439 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D \u2014 \u043C\u043E\u0436\u043D\u043E \u0434\u043E\u043A\u0443\u043F\u0438\u0442\u044C \u0435\u0449\u0451 \u043E\u0434\u0438\u043D \u043A\u0432\u0435\u0441\u0442 \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F",
    icon: /*#__PURE__*/React.createElement(MLTCoin, {
      size: 14
    })
  }, "\u041A\u0443\u043F\u0438\u0442\u044C \u0434\u043E\u043F. \u043A\u0432\u0435\u0441\u0442 \u0437\u0430 30 MLT"), /*#__PURE__*/React.createElement(CardBox, {
    title: "\uD83D\uDCDC \u0414\u043E\u0441\u043A\u0430 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u043E\u0432",
    extra: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: 'var(--text-secondary)'
      }
    }, "\u043E\u0431\u0449\u0438\u0439 \u043F\u0443\u043B: \u0431\u0435\u0440\u0438 \u043B\u044E\u0431\u043E\u0439 \u0442\u0438\u0440 \u0434\u043E\u0431\u0440\u043E\u0432\u043E\u043B\u044C\u043D\u043E; \u0434\u0435\u043F\u043E\u0437\u0438\u0442 \u0437\u0430\u043C\u043E\u0440\u0430\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u2014 \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B: \u0434\u0435\u043F\u043E\u0437\u0438\u0442 \u043D\u0430\u0437\u0430\u0434 + \u043D\u0430\u0433\u0440\u0430\u0434\u0430, \u043F\u0440\u043E\u0432\u0430\u043B\u0438\u043B \u2014 \u0441\u0433\u043E\u0440\u0430\u0435\u0442")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, contractsMine.map((c, i) => /*#__PURE__*/React.createElement(QuestCard, {
    key: 'm' + i,
    tier: c.tier,
    slot: "\u041C\u043E\u0439 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442",
    title: c.title,
    progress: c.progress,
    target: c.target,
    rewardMlt: c.rewardMlt,
    rewardXp: c.rewardMlt * 5,
    deadline: c.deadline
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10
    }
  }, contractsOpen.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 12px',
      borderRadius: 12,
      border: '1px solid var(--border-strong)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 999,
      background: `var(--quest-${c.tier})`,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontWeight: 600
    }
  }, c.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-secondary)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, c.days, " \u0434\u043D. \xB7 +", c.rewardMlt, " MLT"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary",
    title: `Депозит ${c.deposit} MLT замораживается: выполнил — вернётся с наградой, провалил — сгорит`
  }, "\u0412\u0437\u044F\u0442\u044C \xB7 \u0434\u0435\u043F\u043E\u0437\u0438\u0442 ", c.deposit, " MLT"))))))), tab === 'shop' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, Object.entries(shop).map(([cat, items]) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: cat
  }, /*#__PURE__*/React.createElement(H3, {
    extra: cat === 'Нематериальные' ? 'привилегии — самое ценное в каталоге' : cat === 'Командные' ? 'покупает любой, активирует руководитель' : 'выдача через руководителя'
  }, cat), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 14
    }
  }, items.map((s, i) => /*#__PURE__*/React.createElement(CardBox, {
    key: i,
    style: {
      padding: 16,
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 46,
      height: 46,
      borderRadius: 14,
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 26,
      background: 'var(--surface-selected)'
    }
  }, s.e), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      lineHeight: 1.25
    }
  }, s.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, s.d))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(MLTAmount, {
    value: s.p
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: s.p <= BALANCE ? 'primary' : 'secondary',
    disabled: s.p > BALANCE
  }, s.p <= BALANCE ? 'Купить' : 'Не хватает')))))))), tab === 'gacha' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '340px 1fr',
      gap: 14,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-xl)',
      background: 'var(--grad-gacha)',
      color: '#fff',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 14,
      boxShadow: 'var(--glow-rare)',
      border: '1px solid rgba(255,255,255,.25)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      animation: spin ? 'coin-spin 0.5s linear infinite' : 'none'
    }
  }, /*#__PURE__*/React.createElement(MLTCoin, {
    size: 96
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 600
    }
  }, "\u0413\u0430\u0447\u0430"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      opacity: .85,
      textAlign: 'center'
    }
  }, "\u0421\u0435\u0440\u0432\u0435\u0440\u043D\u044B\u0439 RNG. \u041A\u0430\u0436\u0434\u0430\u044F 100-\u044F \u043A\u0440\u0443\u0442\u043A\u0430 \u0431\u0435\u0437 \u0440\u0435\u0434\u043A\u043E\u0433\u043E \u043F\u0440\u0438\u0437\u0430 \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0440\u0443\u0435\u0442 \u0440\u0435\u0434\u043A\u0438\u0439 (\u0433\u0430\u0440\u0430\u043D\u0442-\u0441\u0447\u0451\u0442\u0447\u0438\u043A \u0432\u0438\u0434\u0435\u043D \u0432\u0441\u0435\u043C)"), prize && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 14px',
      borderRadius: 12,
      background: 'rgba(255,255,255,.16)',
      border: '1px solid rgba(255,255,255,.3)',
      fontWeight: 600,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22
    }
  }, prize.e), "\u0412\u044B\u043F\u0430\u043B\u043E: ", prize.t), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: doSpin,
    disabled: spin,
    style: {
      width: '100%'
    }
  }, spin ? 'Крутим…' : 'Крутить за 10 MLT'), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      opacity: .7,
      fontVariantNumeric: 'tabular-nums'
    }
  }, "\u0414\u043E \u0433\u0430\u0440\u0430\u043D\u0442\u0430: 37 \u043A\u0440\u0443\u0442\u043E\u043A")), /*#__PURE__*/React.createElement(CardBox, {
    title: "\u041F\u0440\u0438\u0437\u043E\u0432\u043E\u0439 \u043F\u0443\u043B \u0438 \u0448\u0430\u043D\u0441\u044B",
    extra: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: 'var(--text-secondary)'
      }
    }, "\u0432\u0441\u0451 \u0438\u0437 \u0433\u0430\u0447\u0438 \u043C\u043E\u0436\u043D\u043E \u043A\u0443\u043F\u0438\u0442\u044C \u0432 \u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0435 \u043D\u0430\u043F\u0440\u044F\u043C\u0443\u044E")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, pool.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '8px 4px',
      borderBottom: i < pool.length - 1 ? '1px solid var(--border-default)' : 'none',
      fontSize: 13,
      background: p.r === 'jackpot' ? 'linear-gradient(90deg,rgba(212,160,23,.12),transparent)' : 'transparent',
      borderRadius: p.r === 'jackpot' ? 8 : 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 20,
      width: 28,
      textAlign: 'center'
    }
  }, p.e), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontWeight: p.r ? 700 : 400
    }
  }, p.t), p.r && /*#__PURE__*/React.createElement(Badge, {
    status: p.r === 'jackpot' ? 'warning' : 'brand'
  }, p.r === 'jackpot' ? 'джекпот' : 'редкий'), /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: 'tabular-nums',
      fontWeight: 600,
      width: 64,
      textAlign: 'right'
    }
  }, p.c)))))), tab === 'inv' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 14
    }
  }, [{
    e: '🕙',
    t: 'Поздний старт +2 часа',
    d: 'Куплен 1 августа · действует до 1 ноября',
    st: /*#__PURE__*/React.createElement(Badge, {
      status: "info",
      dot: true
    }, "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u0430\u0446\u0438\u0438")
  }, {
    e: '☕',
    t: 'Кофе за счёт компании',
    d: 'Из гачи · 28 июля',
    st: /*#__PURE__*/React.createElement(Badge, {
      status: "success",
      dot: true
    }, "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D")
  }].map((it, i) => /*#__PURE__*/React.createElement(CardBox, {
    key: i,
    style: {
      padding: 16,
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 46,
      height: 46,
      borderRadius: 14,
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 26,
      background: 'var(--surface-selected)'
    }
  }, it.e), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700
    }
  }, it.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, it.d))), it.st))));
}
window.GamificationScreen = GamificationScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/monolitika/Gamification.jsx", error: String((e && e.message) || e) }); }

// ui_kits/monolitika/Manager.jsx
try { (() => {
function ManagerScreen() {
  const tasks = [{
    t: 'Согласовать спецификацию — ГК «Монолит»',
    time: '10:30',
    done: true
  }, {
    t: 'Звонок: ООО «Кирпичный двор»',
    time: '12:00',
    done: true
  }, {
    t: 'Отгрузка АО «БетонПлюс» — проверить документы',
    time: '14:15',
    done: false
  }, {
    t: 'Подготовить КП для ТД «Уралстрой»',
    time: '16:00',
    done: false
  }, {
    t: 'Обновить статусы сделок',
    time: '17:30',
    done: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 24,
      fontWeight: 600,
      color: 'var(--text-on-app)'
    }
  }, "\u0414\u043E\u0431\u0440\u044B\u0439 \u0434\u0435\u043D\u044C, \u0410\u043B\u0435\u043A\u0441\u0435\u0439"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-on-app-secondary)',
      marginTop: 2
    }
  }, "\u041F\u043E\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u0438\u043A, 3 \u0430\u0432\u0433\u0443\u0441\u0442\u0430 \xB7 \u0434\u043E \u043A\u043E\u043D\u0446\u0430 \u043C\u0435\u0441\u044F\u0446\u0430 20 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0434\u043D\u0435\u0439")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 999,
      padding: '7px 14px'
    }
  }, /*#__PURE__*/React.createElement(MLTAmount, {
    value: 1250
  })), /*#__PURE__*/React.createElement(Avatar, {
    name: "\u0410\u043B\u0435\u043A\u0441\u0435\u0439 \u0418\u0432\u0430\u043D\u043E\u0432",
    size: 38
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(CardBox, null, /*#__PURE__*/React.createElement(ProgressBar, {
    label: "\u041E\u0442\u0433\u0440\u0443\u0437\u043A\u0438 \u0441\u0435\u0433\u043E\u0434\u043D\u044F",
    value: 8,
    max: 17,
    showValue: true,
    caption: "48% \u0434\u043D\u0435\u0432\u043D\u043E\u0433\u043E \u043F\u043B\u0430\u043D\u0430",
    height: 10
  })), /*#__PURE__*/React.createElement(CardBox, null, /*#__PURE__*/React.createElement(ProgressBar, {
    label: "\u041B\u0438\u0447\u043D\u044B\u0439 \u043F\u043B\u0430\u043D \u043C\u0435\u0441\u044F\u0446\u0430",
    value: 2412300,
    max: 3400000,
    showValue: false,
    caption: "2 412 300 \u20BD \u0438\u0437 3 400 000 \u20BD \xB7 71%",
    color: "var(--success)",
    height: 10
  })), /*#__PURE__*/React.createElement(CardBox, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-secondary)',
      fontWeight: 500
    }
  }, "\u041C\u0435\u0441\u0442\u043E \u0432 \u0440\u0435\u0439\u0442\u0438\u043D\u0433\u0435"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 28,
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1.2
    }
  }, "3 ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-tertiary)',
      fontWeight: 400
    }
  }, "\u0438\u0437 24"))), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 999,
      background: 'var(--blue-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--brand)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "trophy",
    size: 19
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(CardBox, {
    title: "\u041C\u043E\u044F \u0432\u044B\u0440\u0443\u0447\u043A\u0430, \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 8 \u043D\u0435\u0434\u0435\u043B\u044C",
    extra: /*#__PURE__*/React.createElement(Badge, {
      status: "success",
      dot: true
    }, "+12% \u043A \u043F\u0440\u043E\u0448\u043B\u043E\u043C\u0443 \u043F\u0435\u0440\u0438\u043E\u0434\u0443")
  }, /*#__PURE__*/React.createElement(LineChart, {
    height: 190,
    values: [420, 510, 470, 630, 580, 690, 720, 810],
    labels: ['нед 24', 'нед 25', 'нед 26', 'нед 27', 'нед 28', 'нед 29', 'нед 30', 'нед 31'],
    valueFormat: v => Math.round(v) + ' тыс'
  })), /*#__PURE__*/React.createElement(CardBox, {
    title: "\u0417\u0430\u0434\u0430\u0447\u0438 \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F",
    extra: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: 'var(--text-secondary)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, "2 \u0438\u0437 5")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, tasks.map((t, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 6px',
      borderRadius: 8,
      background: 'transparent'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flex: 'none',
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: t.done ? 'var(--interactive)' : 'var(--surface-card)',
      border: t.done ? '1px solid var(--interactive)' : '1px solid var(--border-strong)',
      color: '#fff'
    }
  }, t.done && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 11,
    strokeWidth: 3
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 13,
      color: t.done ? 'var(--text-tertiary)' : 'var(--text-primary)',
      textDecoration: t.done ? 'line-through' : 'none'
    }
  }, t.t), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-tertiary)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, t.time)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(CardBox, {
    title: "\u041C\u043E\u0438 \u043A\u043B\u0438\u0435\u043D\u0442\u044B \u2014 \u0440\u0438\u0441\u043A\u0438"
  }, /*#__PURE__*/React.createElement(Table, {
    zebra: false,
    columns: [{
      key: 'name',
      label: 'Клиент'
    }, {
      key: 'plan',
      label: 'План, ₽',
      align: 'right'
    }, {
      key: 'pct',
      label: 'Выполнение',
      width: 150,
      render: v => /*#__PURE__*/React.createElement(PctCell, {
        pct: v
      })
    }, {
      key: 'st',
      label: 'Статус',
      width: 120,
      render: v => /*#__PURE__*/React.createElement(Badge, {
        status: v,
        dot: true
      }, ST_LABEL[v])
    }],
    rows: REPORT_ROWS.filter(r => r.st === 'danger' || r.st === 'warning').slice(0, 4)
  })), /*#__PURE__*/React.createElement(CardBox, {
    title: "\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043C\u043E\u0438\u0445 \u043F\u0440\u043E\u0434\u0430\u0436"
  }, /*#__PURE__*/React.createElement(DonutChart, {
    size: 160,
    thickness: 20,
    centerValue: "46%",
    centerLabel: "\u041A\u0438\u0440\u043F\u0438\u0447",
    segments: [{
      value: 46,
      label: 'Кирпич'
    }, {
      value: 27,
      label: 'Бетон и ЖБИ'
    }, {
      value: 17,
      label: 'Сухие смеси'
    }, {
      value: 10,
      label: 'Прочее'
    }]
  }))));
}
window.ManagerScreen = ManagerScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/monolitika/Manager.jsx", error: String((e && e.message) || e) }); }

// ui_kits/monolitika/Report.jsx
try { (() => {
function ReportScreen() {
  const [page, setPage] = React.useState(1);
  const [chip, setChip] = React.useState('Все');
  const [mgr, setMgr] = React.useState('Все менеджеры');
  const filtered = REPORT_ROWS.filter(r => {
    if (chip === 'Выполняют план') return r.pct >= 100;
    if (chip === 'Отстают') return r.pct >= 45 && r.pct < 100;
    if (chip === 'Риск срыва') return r.pct < 45;
    return true;
  }).filter(r => mgr === 'Все менеджеры' || r.mgr === mgr);
  const PS = 15;
  const pageRows = filtered.slice((page - 1) * PS, page * PS);
  const sum = k => fmtR(filtered.reduce((a, r) => a + parseInt(String(r[k]).replace(/\s/g, '')), 0));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 24,
      fontWeight: 600,
      color: 'var(--text-on-app)'
    }
  }, "\u041F\u043B\u0430\u043D/\u0444\u0430\u043A\u0442 \u043F\u043E \u043A\u043B\u0438\u0435\u043D\u0442\u0430\u043C"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-on-app-secondary)',
      marginTop: 2
    }
  }, "\u0418\u044E\u043B\u044C 2026 \xB7 ", filtered.length, " \u0441\u0442\u0440\u043E\u043A")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    options: ['Все менеджеры', ...MGRS],
    value: mgr,
    onChange: v => {
      setMgr(v);
      setPage(1);
    },
    style: {
      width: 170
    }
  }), /*#__PURE__*/React.createElement(DateRangePicker, {
    size: "sm",
    start: new Date(2026, 6, 1),
    end: new Date(2026, 6, 31)
  }), /*#__PURE__*/React.createElement(Tooltip, {
    content: "\u0412\u044B\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0432 Excel"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 15
    })
  }, "\u042D\u043A\u0441\u043F\u043E\u0440\u0442")))), /*#__PURE__*/React.createElement(FilterChips, {
    items: ['Все', 'Выполняют план', 'Отстают', 'Риск срыва'],
    value: chip,
    onChange: v => {
      setChip(v);
      setPage(1);
    }
  }), filtered.length === 0 ? /*#__PURE__*/React.createElement(CardBox, null, /*#__PURE__*/React.createElement(EmptyState, {
    title: "\u041D\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0445 \u0437\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u043F\u0435\u0440\u0438\u043E\u0434",
    description: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u0435 \u0444\u0438\u043B\u044C\u0442\u0440\u044B \u0438\u043B\u0438 \u043F\u0435\u0440\u0438\u043E\u0434 \u043E\u0442\u0447\u0451\u0442\u0430",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      onClick: () => {
        setChip('Все');
        setMgr('Все менеджеры');
      }
    }, "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0444\u0438\u043B\u044C\u0442\u0440\u044B")
  })) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Table, {
    maxHeight: 520,
    columns: [{
      key: 'name',
      label: 'Клиент'
    }, {
      key: 'mgr',
      label: 'Менеджер',
      width: 110
    }, {
      key: 'city',
      label: 'Филиал',
      width: 80
    }, {
      key: 'plan',
      label: 'План, ₽',
      align: 'right'
    }, {
      key: 'fact',
      label: 'Факт, ₽',
      align: 'right',
      bar: true
    }, {
      key: 'pct',
      label: 'Выполнение',
      width: 150,
      heatmap: true,
      render: v => /*#__PURE__*/React.createElement(PctCell, {
        pct: v
      })
    }, {
      key: 'ship',
      label: 'Отгрузки',
      align: 'right',
      width: 80
    }, {
      key: 'st',
      label: 'Статус',
      width: 125,
      render: v => /*#__PURE__*/React.createElement(Badge, {
        status: v,
        dot: true
      }, ST_LABEL[v])
    }],
    rows: pageRows,
    totals: {
      plan: sum('plan'),
      fact: sum('fact')
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(Pagination, {
    page: page,
    pageCount: Math.max(1, Math.ceil(filtered.length / PS)),
    total: filtered.length,
    pageSize: PS,
    onChange: setPage
  }))));
}
window.ReportScreen = ReportScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/monolitika/Report.jsx", error: String((e && e.message) || e) }); }

// ui_kits/monolitika/shared.jsx
try { (() => {
const {
  Sidebar,
  Tabs,
  FilterChips,
  Pagination,
  Button,
  Input,
  Select,
  DateRangePicker,
  Table,
  KPICard,
  ProgressBar,
  Badge,
  Avatar,
  EmptyState,
  Modal,
  Toast,
  Tooltip,
  LineChart,
  BarChart,
  DonutChart,
  Gauge,
  MLTCoin,
  MLTAmount,
  RewardCard,
  Icon,
  BrandLogo
} = window.DesignSystem_311945;
const CLIENTS = ['ООО «Стройторг»', 'ГК «Монолит»', 'ИП Сидоров', 'АО «БетонПлюс»', 'ООО «Кирпичный двор»', 'ТД «Уралстрой»', 'ООО «СтройАльянс»', 'ПК «Фундамент»', 'ООО «МегаСтрой»', 'ИП Волков', 'АО «ЖБИ-Профи»', 'ООО «Арматура-Трейд»', 'ТД «Панельстрой»', 'ООО «Цемторг»', 'ГК «СтройГрад»'];
const MGRS = ['Иванов А.', 'Петрова М.', 'Крылов Д.', 'Смирнова О.', 'Гусев П.'];
const CITIES = ['Москва', 'Казань', 'Пермь', 'Уфа'];
function seeded(i) {
  let x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}
const fmtR = n => Math.round(n).toLocaleString('ru-RU');
const REPORT_ROWS = Array.from({
  length: 42
}, (_, i) => {
  const plan = 400000 + seeded(i) * 3200000;
  const k = 0.35 + seeded(i + 100) * 0.95;
  const fact = plan * k;
  const pct = Math.round(k * 100);
  return {
    id: i,
    name: CLIENTS[i % CLIENTS.length],
    mgr: MGRS[i % MGRS.length],
    city: CITIES[i % CITIES.length],
    plan: fmtR(plan),
    fact: fmtR(fact),
    pct,
    ship: Math.round(3 + seeded(i + 200) * 40),
    st: pct >= 100 ? 'success' : pct >= 70 ? 'info' : pct >= 45 ? 'warning' : 'danger'
  };
});
const ST_LABEL = {
  success: 'Выполнен',
  info: 'В работе',
  warning: 'Отстаёт',
  danger: 'Риск срыва'
};
function PctCell({
  pct
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      minWidth: 90
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 5,
      background: 'var(--gray-100)',
      borderRadius: 999,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: Math.min(pct, 100) + '%',
      height: '100%',
      borderRadius: 999,
      background: pct >= 100 ? 'var(--success)' : pct >= 70 ? 'var(--interactive)' : pct >= 45 ? 'var(--warning)' : 'var(--danger)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: 'tabular-nums',
      fontSize: 12,
      fontWeight: 600,
      width: 34,
      textAlign: 'right'
    }
  }, pct, "%"));
}
function CardBox({
  title,
  extra,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-card)',
      padding: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      ...style
    }
  }, (title || extra) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 600
    }
  }, title), extra), children);
}
Object.assign(window, {
  CLIENTS,
  MGRS,
  CITIES,
  REPORT_ROWS,
  ST_LABEL,
  PctCell,
  CardBox,
  fmtR,
  Sidebar,
  Tabs,
  FilterChips,
  Pagination,
  Button,
  Input,
  Select,
  DateRangePicker,
  Table,
  KPICard,
  ProgressBar,
  Badge,
  Avatar,
  EmptyState,
  Modal,
  Toast,
  Tooltip,
  LineChart,
  BarChart,
  DonutChart,
  Gauge,
  MLTCoin,
  MLTAmount,
  RewardCard,
  Icon
});
// Страховка от устаревшего _ds_bundle.js без BrandLogo: инлайн-копия того же знака
window.BrandLogo = BrandLogo || function BrandLogoFallback({
  size = 20,
  withWordmark,
  style
}) {
  const h = size,
    w = size * 24 / 17;
  const svg = React.createElement('svg', {
    width: w,
    height: h,
    viewBox: '0 0 24 17',
    fill: 'none',
    'aria-hidden': true
  }, React.createElement('rect', {
    x: 0,
    y: 0,
    width: 6,
    height: 17,
    rx: 3,
    fill: '#3b82f6'
  }), React.createElement('rect', {
    x: 9,
    y: 7,
    width: 6,
    height: 10,
    rx: 3,
    fill: '#ef4444'
  }), React.createElement('rect', {
    x: 18,
    y: 0,
    width: 6,
    height: 17,
    rx: 3,
    fill: '#22c55e'
  }));
  if (!withWordmark) return svg;
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: Math.round(size * 0.45),
      ...style
    }
  }, svg, React.createElement('span', {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: size * 0.9,
      fontWeight: 700,
      color: 'var(--text-primary)',
      letterSpacing: '-0.02em',
      lineHeight: 1
    }
  }, 'Монолитика'));
};
// Страховка от устаревшего бандла без QuestCard: инлайн-копия новой плашки
const QC_TIERS = {
  white: {
    label: 'Обычный',
    color: 'var(--quest-white,#9ca3af)'
  },
  green: {
    label: 'Необычный',
    color: 'var(--quest-green,#2f9e44)'
  },
  blue: {
    label: 'Редкий',
    color: 'var(--quest-blue,#1c7ed6)'
  },
  epic: {
    label: 'Эпический',
    color: 'var(--quest-epic,#9c36b5)'
  },
  legendary: {
    label: 'Легендарный',
    color: 'var(--quest-legendary,#e8590c)'
  }
};
window.QuestCardFallback = function QuestCardFallback({
  tier = 'blue',
  slot = 'Дневной',
  title,
  progress = 0,
  target = 1,
  rewardMlt = 0,
  rewardXp = 0,
  status = 'active',
  deadline,
  rerollPrice,
  onReroll,
  style
}) {
  const t = QC_TIERS[tier] || QC_TIERS.blue;
  const done = status === 'done';
  const color = done ? 'var(--quest-green,#2f9e44)' : t.color;
  const pct = Math.min(100, Math.round(progress / Math.max(target, 1) * 100));
  const f = v => v >= 10000 ? v.toLocaleString('ru-RU') : String(Math.round(v * 10) / 10);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      padding: '14px 16px',
      borderRadius: 'var(--radius-lg)',
      border: `1.5px solid color-mix(in srgb, ${color} 50%, transparent)`,
      background: `linear-gradient(color-mix(in srgb, ${color} 7%, transparent),color-mix(in srgb, ${color} 7%, transparent)),var(--surface-card)`,
      backdropFilter: 'var(--glass-blur)',
      WebkitBackdropFilter: 'var(--glass-blur)',
      boxShadow: 'var(--shadow-card)',
      fontFamily: 'var(--font-ui)',
      minWidth: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      borderRadius: 7,
      padding: '2px 7px',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '.05em',
      textTransform: 'uppercase',
      color: '#fff',
      background: t.color,
      whiteSpace: 'nowrap'
    }
  }, t.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: 'var(--text-secondary)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      minWidth: 0
    }
  }, slot), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      flex: 'none',
      fontSize: 11,
      whiteSpace: 'nowrap',
      color: done ? 'var(--success-text)' : status === 'failed' ? 'var(--text-tertiary)' : 'var(--text-secondary)',
      fontVariantNumeric: 'tabular-nums',
      fontWeight: done ? 600 : 400
    }
  }, done ? '✅ выполнен' : status === 'failed' ? 'сгорел' : deadline)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--text-primary)',
      lineHeight: 1.35,
      overflowWrap: 'break-word'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8,
      borderRadius: 999,
      background: 'var(--surface-sunken)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: Math.max(pct, 2) + '%',
      borderRadius: 999,
      background: color
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--text-secondary)',
      whiteSpace: 'nowrap'
    }
  }, f(progress), " \u0438\u0437 ", f(target)), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      background: 'var(--surface-selected)',
      borderRadius: 999,
      padding: '3px 9px',
      fontSize: 11,
      fontWeight: 700,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--text-brand)',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(MLTCoin, {
    size: 13
  }), "+", rewardMlt, " MLT \xB7 +", rewardXp, " XP"))), status === 'active' && rerollPrice != null && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onReroll,
    title: "\u041D\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u043A\u0432\u0435\u0441\u0442? \u0417\u0430\u043C\u0435\u043D\u0438\u0442\u0435 \u0435\u0433\u043E \u043D\u0430 \u0434\u0440\u0443\u0433\u043E\u0439 \u0442\u043E\u0433\u043E \u0436\u0435 \u0442\u0438\u0440\u0430. \u0421\u043F\u0438\u0448\u0435\u0442\u0441\u044F \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u0430\u044F \u0441\u0443\u043C\u043C\u0430 MLT; \u043C\u0430\u043A\u0441\u0438\u043C\u0443\u043C \u043E\u0434\u043D\u0430 \u0437\u0430\u043C\u0435\u043D\u0430.",
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexWrap: 'wrap',
      gap: '2px 6px',
      width: '100%',
      minHeight: 30,
      padding: '4px 8px',
      appearance: 'none',
      border: '1px solid var(--border-strong)',
      background: 'transparent',
      borderRadius: 9,
      fontSize: 12,
      fontWeight: 600,
      fontFamily: 'inherit',
      color: 'var(--text-primary)',
      cursor: 'pointer'
    }
  }, "\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u0432\u0435\u0441\u0442 \u0437\u0430 ", /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      fontVariantNumeric: 'tabular-nums'
    }
  }, /*#__PURE__*/React.createElement(MLTCoin, {
    size: 13
  }), rerollPrice, " MLT")));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/monolitika/shared.jsx", error: String((e && e.message) || e) }); }

__ds_ns.BarChart = __ds_scope.BarChart;

__ds_ns.DonutChart = __ds_scope.DonutChart;

__ds_ns.Gauge = __ds_scope.Gauge;

__ds_ns.LineChart = __ds_scope.LineChart;

__ds_ns.BrandLogo = __ds_scope.BrandLogo;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.ICON_NAMES = __ds_scope.ICON_NAMES;

__ds_ns.FormatNum = __ds_scope.FormatNum;

__ds_ns.Num = __ds_scope.Num;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.KPICard = __ds_scope.KPICard;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.TrendBadge = __ds_scope.TrendBadge;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.DateRangePicker = __ds_scope.DateRangePicker;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.MLTAmount = __ds_scope.MLTAmount;

__ds_ns.MLTCoin = __ds_scope.MLTCoin;

__ds_ns.QuestCard = __ds_scope.QuestCard;

__ds_ns.RewardCard = __ds_scope.RewardCard;

__ds_ns.FilterChips = __ds_scope.FilterChips;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.Sidebar = __ds_scope.Sidebar;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
